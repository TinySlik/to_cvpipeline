﻿#version 330

#if 0
uniform float time;
uniform vec2 resolution;

out vec4 fragColor;

vec2 hash(vec2 p) {
	mat2 m = mat2(13.85, 47.77,
	              99.41, 88.48);
	return fract(sin(m*p) * 46738.29);
}

float voronoi(vec2 p) {
	vec2 g = floor(p);
	vec2 f = fract(p);

	float distanceToClosestFeaturePoint = 1.0;
	for(int y = -1; y <= 1; y++) {
		for(int x = -1; x <= 1; x++) {
		vec2 latticePoint = vec2(x,y);
		float currentDistance = distance(latticePoint + hash(g+latticePoint), f);
		distanceToClosestFeaturePoint = min(distanceToClosestFeaturePoint, currentDistance);
		}
	}
	return distanceToClosestFeaturePoint;
}

void main( void )
{
	vec2 uv = (gl_FragCoord.xy / resolution.xy) * 2.0 - 1.0;
	uv.x *= resolution.x / resolution.y;
	float offset = voronoi(uv*10.0 + vec2(time));
	float t = 1.0 / abs(((uv.x + sin(uv.y + time)) + offset ) * 30.0);

	float r = voronoi(uv* 1.0) * 10.0;
	vec3 finalColor = vec3 (10.0 * uv.y, 2.0, 1.0 * r) * t;

	fragColor = vec4(finalColor, 1.0);
}

#elif 0

#define SPEED 0.5
#define HUESPEED 0.02
#define SATURATION 0.5
#define DIVISIONS 27.
#define INNER 0.5
#define OUTER 0.8
#define SIZE 0.05
#define BOKEH 0.01

uniform float time;
uniform vec2 resolution;

out vec4 fragColor;

//sdSegment by iq
//https://www.iquilezles.org/www/articles/distfunctions2d/distfunctions2d.htm
float sdSegment(vec2 p,vec2 a,vec2 b){
 vec2 pa=p-a,ba=b-a;
 float h=clamp(dot(pa,ba)/dot(ba,ba),0.,1.);
 return length(pa-ba*h);
}

mat2 rot(float a){float s=sin(a),c=cos(a);return mat2(c,s,-s,c);}
vec3 hsv(float h,float s,float v){return ((clamp(abs(fract(h+vec3(0.,.666,.333))*6.-3.)-1.,0.,1.)-1.)*s+1.)*v;}

void main( void ) {
	vec2 p=(gl_FragCoord.xy*2.-resolution.xy)/min(resolution.x,resolution.y);

	//slice a pie
	const float idiv=1./DIVISIONS;
	float a=floor(atan(p.x,p.y)*DIVISIONS/6.283+.5);

	//segment sdf
	vec2 vSeg=vec2(0,1)*rot(a*6.283*idiv);
	float d=sdSegment(p,vSeg*INNER,vSeg*OUTER);

	//make a capsule from segment sdf
	float v=smoothstep(SIZE,SIZE-BOKEH,d);

	//color
	float t=floor(DIVISIONS-fract(time*SPEED)*DIVISIONS);
	v*=fract((t+a)*idiv);
	float h=fract(time*HUESPEED+a*idiv);
	fragColor = vec4(hsv(h,SATURATION,v),1);
}

#elif 0

// glslsandbox uniforms
uniform float time;
uniform vec2 resolution;

// shadertoy emulation
#define iTime time
#define iResolution resolution

out vec4 fragColor;

// --------[ Original ShaderToy begins here ]---------- //
const float zoom = 3.;
const float lineWeight = 4.3;
const bool invertColors = true;
const float sharpness = 0.2;

const float StarRotationSpeed = -.5;
const float StarSize = 1.8;
const int StarPoints = 3;
const float StarWeight = 3.4;

const float waveSpacing = .3;
const float waveAmp = .4;
const float waveFreq = 25.;
const float phaseSpeed = .33;


const float waveAmpOffset = .01; // just a little tweaky correction

mat2 rot2D(float r){
    return mat2(cos(r), sin(r), -sin(r), cos(r));
}

// signed distance to a n-star polygon with external angle en
float sdStar(in vec2 p, in float r, in int n, in float m) // m=[2,n]
{
    // these 4 lines can be precomputed for a given shape
    float an = 3.141593/float(n);
    float en = 3.141593/m;
    vec2  acs = vec2(cos(an),sin(an));
    vec2  ecs = vec2(cos(en),sin(en)); // ecs=vec2(0,1) and simplify, for regular polygon,

    // reduce to first sector
    float bn = mod(atan(p.x,p.y),2.0*an) - an;
    p = length(p)*vec2(cos(bn),abs(sin(bn)));

    // line sdf
    p -= r*acs;
    p += ecs*clamp( -dot(p,ecs), 0.0, r*acs.y/ecs.y);
    return length(p)*sign(p.x);
}
float sdShape(vec2 uv) {
    uv *= rot2D(-iTime*StarRotationSpeed);
    return sdStar(uv, StarSize, StarPoints, StarWeight);
}

// https://www.shadertoy.com/view/3t23WG
// Distance to y(x) = a + b*cos(cx+d)
float udCos( in vec2 p, in float a, in float b, in float c, in float d )
{
    // convert all data to a primitive cosine wave
    p = c*(p-vec2(d,a));
    
    // reduce to principal half cycle
    const float TPI = 6.28318530718;
    p.x = mod( p.x, TPI); if( p.x>(0.5*TPI) ) p.x = TPI - p.x;

    // find zero of derivative (minimize distance)
    float xa = 0.0, xb = TPI;
    for( int i=0; i<7; i++ ) // bisection, 7 bits more or less
    {
        float x = 0.5*(xa+xb);
        float si = sin(x);
        float co = cos(x);
        float y = x-p.x+b*c*si*(p.y-b*c*co);
        if( y<0.0 ) xa = x; else xb = x;
    }
    float x = 0.5*(xa+xb);
    for( int i=0; i<4; i++ ) // newtown-raphson, 28 bits more or less
    {
        float si = sin(x);
        float co = cos(x);
        float  f = x - p.x + b*c*(p.y*si - b*c*si*co);
        float df = 1.0     + b*c*(p.y*co - b*c*(2.0*co*co-1.0));
        x = x - f/df;
    }
    
    // compute distance    
    vec2 q = vec2(x,b*c*cos(x));
    return length(p-q)/c;
}

vec3 dtoa(float d, in vec3 amount){
    return 1. / clamp(d*amount, amount/amount, amount);
}

// 4 out, 1 in...
vec4 hash41(float p)
{
 vec4 p4 = fract(vec4(p) * vec4(.1031, .1030, .0973, .1099));
    p4 += dot(p4, p4.wzxy+33.33);
    return fract((p4.xxyz+p4.yzzw)*p4.zywx);
}
void mainImage( out vec4 o, vec2 C)
{
    vec2 R = iResolution.xy;
    vec2 N2 = C/R;
    vec2 N = C/R-.5;
    vec2 uv = N;
    uv.x *= R.x/R.y;
    float t = iTime * phaseSpeed;
    
    uv *= zoom;

    float a2 = 1e5;
    vec2 uvsq = uv;
    float a = sdShape(uvsq);
    vec2 uv2 = uv;

    uv.y = mod(uv.y, waveSpacing) - waveSpacing*.5;
    
    for (float i = -3.; i <= 3.; ++ i) { // necessary to handle overlapping lines. if your lines don't overlap, may not be necessary.
     vec2 uvwave = vec2(uv2.x, uv.y + i * waveSpacing);
        float b = (smoothstep(1., -1.,a)*waveAmp)+ waveAmpOffset;
        float c = waveFreq;
     a2 = min(a2, udCos(uvwave, 0., b, c, t));// a + b*cos(cx+d)
    }
    
 vec3 tint = vec3(1.,.5,.4);
    float sh = mix(100., 1000., sharpness);
    o.rgb = dtoa(mix(a2, a-lineWeight + 4., .03), sh*tint);
    if (!invertColors)
     o = 1.-o;
    o *= 1.-dot(N,N*2.);
    o = clamp(o,vec4(0),vec4(1));
}
// --------[ Original ShaderToy ends here ]---------- //

void main(void)
{
    mainImage(fragColor, gl_FragCoord.xy);
    fragColor.a = 1.;
}

#elif 1

uniform float time;
uniform vec2 resolution;

out vec4 fragColor;

// shadertoy emulation
#define iTime time
#define iResolution resolution

// --------[ Original ShaderToy begins here ]---------- //
// Created by David Bargo - davidbargo/2016
// License Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.


float circle(vec2 pos, float radius, float width)
{
    return abs(length(pos)-radius)-width;   
}

//-----------------------------------------------------------------
// From Maarten
float circleFill(vec2 pos, float radius)
{
    return length(pos)-radius;   
}

float smoothMerge(float d1, float d2, float k)
{
    float h = clamp(0.5 + 0.5*(d2 - d1)/k, 0.0, 1.0);
    return mix(d2, d1, h) - k * h * (1.0-h);
}

float line(vec2 p, vec2 start, vec2 end, float width)
{
 vec2 dir = start - end;
 float lngth = length(dir);
 dir /= lngth;
 vec2 proj = max(0.0, min(lngth, dot((start - p), dir)))*dir;
 return length( (start - p) - proj ) - (width / 2.0);
}

float fillMask(float dist)
{
 return clamp(-(dist+0.01)*100.0, 0.0, 1.0);
}

float innerBorderMask(float dist, float width)
{
 float alpha1 = clamp(dist + width, 0.0, 1.0);
 float alpha2 = clamp(dist, 0.0, 1.0);
 return alpha1 - alpha2;
}
//-----------------------------------------------------------------

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
 vec2 uv = fragCoord.xy /iResolution.xy;
    vec2 p = -1. + 2.*uv;
    p.x *= iResolution.x / iResolution.y;
    
    // animation
    float time = mod(iTime, 11.5);
    float heyes = smoothstep(0.1, 0.9, time);
    heyes = mix(heyes, -1.12, smoothstep(1.2, 2.6, time));
    heyes *= 1. - smoothstep(3.16, 3.7, time);
    float veyes = -0.2*smoothstep(0.2, 0.9, time);
    veyes = mix(veyes, -0.1, smoothstep(1.2, 1.9, time));
    veyes = mix(veyes, -0.2, smoothstep(1.9, 2.6, time));
    veyes = mix(veyes, 1., smoothstep(2.7, 3.7, time));
    veyes *= 1. - smoothstep(4.3, 5.3, time);
    float smile = smoothstep(5.1, 6.7, time);
    smile *= 1. - smoothstep(9., 11., time);
    
    // bg
    uv -= vec2(0.5, 0.55);
    uv *= 1.6;
    float f = length(uv);
    vec3 col = mix(vec3(0.65,0.5, 0.6), vec3(0.1,0.15,0.2), f);
    
    p *= 200.;
    vec2 p2 = p;
    p2.x = abs(p2.x);
    
    // eyes
    float d = circleFill((p2 + vec2(-125, -58))+50.*dot(uv, uv), 38.);
    
    // mouth
    float d2 = circleFill(p+vec2(0., -230.+smile*65.), 250.);  
    d2 = max(d2, circleFill(p2+vec2(28.*smile, 868.-smile*28.), 850.));   
 d = min(d, d2);
    col = mix(col, vec3(1, 1, 0.97), fillMask(d));
 col = mix(col, vec3(0.1), innerBorderMask(d, 2.));
    
    // pupils
    d = circleFill(vec2(abs(p.x + 13.*heyes)-121.,p.y -50.-18.*veyes), 15.);
    
    // teeth
    float td = 8.;
    float d3 = circle(vec2(abs(p.x + td)+368.,p.y+34.), 400., 0.5);
    d3 = min(d3, circle(vec2(abs(p.x + td)+152.,p.y+36.), 240., 0.5));
    d3 = min(d3, circle(vec2(abs(p.x + td)-56.,p.y+30.), 80., 0.5));
    d2 = max(d2, d3);
    d = min(d, d2);
    
    // whiskers
    d = min(d, line(p2, vec2(135.+smile*40.,  -5.+smile*10.), vec2(230.+smile*40., smile*40.), 1.));
    d = min(d, line(p2, vec2(140.+smile*50.,-20.+smile*10.), vec2(245.+smile*50.,-35.+smile*40.), 1.));
    d = min(d, line(p2, vec2(140.+smile*60.,-35.+smile*10.), vec2(250.+smile*50.,-70.+smile*30.), 1.));
    
    // nose
    d2 = circleFill(p*vec2(1.0, 4.0+0.004*p2.x) + vec2(0, -120. -smile*4.*10.), 40.);
    d3 = circleFill(p + vec2(0, -24.-smile*10.), 12.);   
    d2 = smoothMerge(d2, d3, 20.);
    d = min(d, d2);
    col = mix(col, vec3(0.1), fillMask(d));
    col = mix(col, vec3(0.1), innerBorderMask(d, 2.));
    
    // eye reflections
    d = circleFill(vec2(abs(p.x + 6. + 11.*heyes)-121.,p.y -56.- 16.*veyes), 4.5);
    d = min(d, circleFill(vec2(abs(p.x + 5.5 + 11.*heyes)-121.,p.y -49.- 16.*veyes),3.));   
	col = mix(col, vec3(1), fillMask(d));
	col = mix(col, vec3(0.1), innerBorderMask(d, 2.));
    
    fragColor = vec4(col, 1.0);
}
// --------[ Original ShaderToy ends here ]---------- //

void main(void)
{
    vec2 in_cord = vec2(gl_FragCoord.x, 480.0-gl_FragCoord.y);
    mainImage(fragColor, in_cord.xy);
}

#else 

// glslsandbox uniforms
uniform float time;
uniform vec2 resolution;

out vec4 fragColor;

void main(void)
{
    fragColor = vec4(0, 0, 0, 1.0);
}

#endif
