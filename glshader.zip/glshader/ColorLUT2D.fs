﻿#version 330

uniform sampler1D colorLUT;

in vec4 TexCoord;
out vec4 fragColor;

void main( void )
{
   vec3 cValue = texture(colorLUT, TexCoord.t).rgb;
   fragColor = vec4(cValue, 1.0);
}


