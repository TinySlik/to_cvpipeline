﻿#version 330 core

uniform usampler2D   uImage;
uniform sampler1D    imageLUT;
uniform vec4         color_front;

uniform float minThreshold;
uniform float maxThreshold;

//blur things

uniform float blurRadius;
uniform float sampleNum;

uniform float aspect_ratio;
uniform float bilateral_thre;

in vec4 TexCoord;
out vec4 fragColor;

float blur(vec2 p)
{
   if (blurRadius > 0.0 && sampleNum > 1.0)
   {
      float col = 0;
      float r_h = blurRadius;
      float r_v = blurRadius * aspect_ratio;
      float sampleStep_h = r_h / sampleNum;
      float sampleStep_v = r_v / sampleNum;

      float count = 0.0;
      float origin_intensity = float(texture(uImage, p).r);

      for(float x = -r_h; x < r_h; x += sampleStep_h) {
         for(float y = -r_v; y < r_v; y += sampleStep_v) {
            float intensity = float(texture(uImage, p + vec2(x, y)).r);
            float range_weight = exp(-0.5 * pow(abs(origin_intensity - intensity) / bilateral_thre, 2.0f));
            float weight = (r_h - abs(x)) * (r_v - abs(y)) * range_weight; 
            col += intensity * weight;
            count += weight;
         }
      }
      return col / count;
   }
   float intensity = float(texture(uImage, TexCoord.st).r);
   return intensity;
}

void main( void )
{
   float col = blur(TexCoord.st);
   vec3 tex_res;
   if (col < minThreshold) {
      tex_res = vec3(0,0,0);
   } else if (col > maxThreshold) {
      tex_res = vec3(maxThreshold, maxThreshold, maxThreshold);
   } else {
      vec3 res_value = texture(imageLUT, col / 255.0).rgb;
      tex_res= vec3(res_value.r * color_front.r,
                    res_value.g * color_front.g,
                    res_value.b * color_front.b);
   }
   //fragColor = vec4(tex_res, color_front.a);
   fragColor = vec4(1.0,1.0,1.0,1.0);
}

