﻿#version 330

uniform usampler2D   uImage;
uniform sampler1D    imageLUT;
uniform float minThreshold;
uniform float maxThreshold;

uniform bool mode_pdi;
uniform bool mode_reverse;

in vec4 TexCoord;
out vec4 fragColor;

//blur things

uniform float blurRadius;
uniform float sampleNum;

uniform float bilateral_thre;
// uniform float guss_thre;

float blur(vec2 p)
{
   if (blurRadius > 0.0 && sampleNum > 1.0)
   {
      float col = 0;
      float r = blurRadius;
      float sampleStep = r / sampleNum;

      float count = 0.0;
      float origin_intensity = float(texture(uImage, p).r);

      for(float x = -r; x < r; x += sampleStep) {
         for(float y = -r; y < r; y += sampleStep) {
            float intensity = float(texture(uImage, p + vec2(x, y)).r);
            // float guss_weight = exp(-0.5 * pow(sqrt(abs((r - abs(x)) * (r - abs(y)))) / guss_thre, 2.0f));
            float guss_weight = abs((r - abs(x)) * (r - abs(y)));
            float range_weight = exp(-0.5 * pow(abs(origin_intensity - intensity) / bilateral_thre, 2.0f));
            float weight = guss_weight * range_weight;
            col += intensity * weight;
            count += weight;
         }
      }
      return col / count;
   }
   float intensity = float(texture(uImage, TexCoord.st).r);
   return intensity;
}
void main( void ){
   float fColorData = blur(TexCoord.st);
   float tmp = fColorData;
   if (!mode_pdi) {
      if (mode_reverse) {
         if (fColorData < 128) tmp = fColorData + 128;
         else tmp = fColorData - 128;
      } else {
         if (fColorData < 128) tmp = 127.f - fColorData;
         else tmp = 255 - fColorData + 128;
      }
   }
   vec3 cValue = texture(imageLUT, tmp / 255.0).rgb;
   if(fColorData > maxThreshold || fColorData < minThreshold){
       fragColor = vec4(0, 0, 0, 0);
       return;
   }
   fragColor = vec4(cValue, 1.0);
}


