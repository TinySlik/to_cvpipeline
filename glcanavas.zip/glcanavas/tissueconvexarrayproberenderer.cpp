/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include "tissueconvexarrayproberenderer.h"
#include <QGLFunctions>
#include <QtOpenGL>
#include <QGLShaderProgram>
#include <QGLShader>
#include "tissuebasearrayproberenderer.h"
#include "ParameterServer/parameterserver.h"
#include "func/utils.h"
#include "renderutil.h"

//const int POSITION = 0;
//const int TEXCOORD = 4;
const double PI = 3.1415926f;

bool TissueConvexArrayProbeRenderer::initShadersTissue() {
  QFile inputFile(g_backendResource_path() + "glshader/Texture.vs");
  bool bSuccess = inputFile.open(QIODevice::ReadOnly);

  QTextStream tStream(&inputFile);
  QString vsCode = tStream.readAll();
  inputFile.close();

  QFile inputFile2(g_backendResource_path() + "glshader/TissueImage.fs");
  bSuccess &= inputFile2.open(QIODevice::ReadOnly);

  QTextStream tStream2(&inputFile2);
  QString fsCode = tStream2.readAll();
  inputFile2.close();

  m_ProgramTissue->addCacheableShaderFromSourceCode(QOpenGLShader::Vertex, vsCode);
  m_ProgramTissue->addCacheableShaderFromSourceCode(QOpenGLShader::Fragment, fsCode);
  bSuccess &= m_ProgramTissue->link();
  return bSuccess;
}

void TissueConvexArrayProbeRenderer::RenderImage() {
  if (_updateVBOTag) {
    updateVBO();
  }
//  glPushAttrib(GL_CURRENT_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, m_MainRenderer->m_TextureTissue);

  SetTexture2DWrapMode(GL_CLAMP, GL_CLAMP);

//  glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
  glDepthFunc(GL_ALWAYS);
  glEnable(GL_MULTISAMPLE);
  GLuint ProgramName = m_ProgramTissue->programId();
  if (!m_ProgramTissue->bind())
    return;
  glm::mat4 mv = TransformImage();
  glm::mat4 mvp = m_Proj * mv;
  mvp = glm::translate(mvp, m_translate_);
  mvp = glm::rotate(mvp, m_angle_, m_rotate_);
  mvp = glm::scale(mvp, m_scale_);
  const GLfloat* pMVP = glm::value_ptr(mvp);

  m_ProgramTissue->setUniformValue("uImage", 0);

  glEnable(GL_TEXTURE_1D);
  glActiveTexture(GL_TEXTURE1);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glBindTexture(GL_TEXTURE_1D, m_MainRenderer->m_TextureLUT);
  glUniform1i(glGetUniformLocation(ProgramName, "imageLUT"), 1);

  m_ProgramTissue->setUniformValue("blurRadius", m_blurRadius);
  m_ProgramTissue->setUniformValue("sampleNum", m_sampleNum);
  m_ProgramTissue->setUniformValue("bilateral_thre", m_bilateralThreshold);
  m_ProgramTissue->setUniformValue("aspect_ratio", m_filterAspectRatio);
  m_ProgramTissue->setUniformValue("minThreshold", m_minFilter);
  m_ProgramTissue->setUniformValue("maxThreshold", m_magFilter);

  auto color = color_format_int_to_glm(m_color);
  m_ProgramTissue->setUniformValue("color_front",
                                   (GLfloat)(color.r),
                                   (GLfloat)(color.g),
                                   (GLfloat)(color.b),
                                   (GLfloat)(color.a));

  GLint UniformMVP = glGetUniformLocation(ProgramName, "MVPMatrix");
  glUniformMatrix4fv(UniformMVP, 1, GL_FALSE, pMVP);

//  glBindVertexArray(m_VA);
  m_ProgramTissue->enableAttributeArray(_qgl_in_Tex_Position);
  m_ProgramTissue->enableAttributeArray(_qgl_in_Tex_TexcoordIn);
  glDrawArrays(GL_TRIANGLE_STRIP, 0, nAngles+1);
  m_ProgramTissue->disableAttributeArray(_qgl_in_Tex_Position);
  m_ProgramTissue->disableAttributeArray(_qgl_in_Tex_TexcoordIn);
//  glBindVertexArray(0);

  glActiveTexture(GL_TEXTURE0);
  glDisable(GL_TEXTURE_2D);
  glBindTexture(GL_TEXTURE_2D, 0);
  glDisable(GL_MULTISAMPLE);
  glUseProgram(0);
//  glPopAttrib();
}

bool TissueConvexArrayProbeRenderer::initRenderer() {
  QFile inputFile(g_backendResource_path() + "glshader/Texture.vs");
  bool bSuccess = inputFile.open(QIODevice::ReadOnly);

  QTextStream tStream(&inputFile);
  QString vsCode = tStream.readAll();
  inputFile.close();

  QFile inputFile2(g_backendResource_path() + "glshader/TissueImage.fs");
  bSuccess &= inputFile2.open(QIODevice::ReadOnly);

  QTextStream tStream2(&inputFile2);
  QString fsCode = tStream2.readAll();
  inputFile2.close();

  m_ProgramTissue->addCacheableShaderFromSourceCode(QOpenGLShader::Vertex, vsCode);
  m_ProgramTissue->addCacheableShaderFromSourceCode(QOpenGLShader::Fragment, fsCode);
  bSuccess &= m_ProgramTissue->link();

  if (!bSuccess)
    return bSuccess;

  CreateVBO();

  _qgl_in_Tex_Position = m_ProgramTissue->attributeLocation("Position");
  m_ProgramTissue->enableAttributeArray(_qgl_in_Tex_Position);
  glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
  glVertexAttribPointer(_qgl_in_Tex_Position, 3, GL_FLOAT, GL_FALSE, 0, 0);
  m_ProgramTissue->disableAttributeArray(_qgl_in_Tex_Position);

  _qgl_in_Tex_TexcoordIn = m_ProgramTissue->attributeLocation("TexcoordIn");
  m_ProgramTissue->enableAttributeArray(_qgl_in_Tex_TexcoordIn);
  glBindBuffer(GL_ARRAY_BUFFER, m_VBOTexture);
  glVertexAttribPointer(_qgl_in_Tex_TexcoordIn, 3, GL_FLOAT, GL_FALSE, 0, 0);
  m_ProgramTissue->disableAttributeArray(_qgl_in_Tex_TexcoordIn);

  return bSuccess;
}

glm::mat4 TissueConvexArrayProbeRenderer::TransformImage() {
  glm::mat4 View = glm::translate(glm::mat4(1.0f),glm::vec3(0.0f, 0.0f, 0.0f));
  glm::mat4 Modelscale = glm::scale(glm::mat4(1.0f),	glm::vec3(1.0f, 1.0f, 1.0f));
  Modelscale = glm::scale(Modelscale,	glm::vec3(480.f, 480.f, 1.0f));
  glm::mat4 Model = glm::translate(Modelscale,glm::vec3(0.0f, 0.0f, 0.0f));
  glm::mat4 VM = View * Model;
  return VM;
}

bool TissueConvexArrayProbeRenderer::InitResources(GLubyte* Tess, GLubyte*) {
  bool bSuccess = true;
  //Frame data
  m_frameData.ImageFrame_Tissue = (GLubyte*)Tess;
  // Tissue display
  {
    int nWidth = m_frameData.Max_display_cols;
    int nHeight = m_frameData.Max_display_rows;
    m_MainRenderer->m_PBOUS = m_MainRenderer->CreateBufferObject();
    glBindBuffer(GL_PIXEL_PACK_BUFFER, m_MainRenderer->m_PBOUS);
    glBufferData(GL_PIXEL_PACK_BUFFER, nWidth*nHeight * sizeof(GLubyte), 0,GL_DYNAMIC_COPY);
    glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
    m_MainRenderer->m_TextureTissue = m_MainRenderer->CreateTextureObject2D();
    bSuccess &= m_MainRenderer->InitTextureUI(m_frameData.NumDisplayRows_Tissue, m_frameData.NumDisplayCols_Tissue);
  }

  m_MainRenderer->m_bInitialized = true;
  m_MainRenderer->m_bVelocityMode = true;
  return bSuccess;
}

bool TissueConvexArrayProbeRenderer::initParams() {
  m_xOffset = 0.67f;
  m_yOffset = 0.f;
  m_scale_radius = 1.f;
  m_Rparer = 0.0001f;
  m_cAngle = PI * (59.5f/180.f);
  m_deflection_angle_radius = 0.f;

  m_rotate_.x = 0;
  m_rotate_.y = 1;
  m_angle_ = PI;
  m_translate_.x = 1.34;

  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = m_MainRenderer->getClassIndex();
  cfg_ctrl.judge_with_create_key(c_name.c_str()).judge_with_create_key("curved_param") = {
    {"m_Rparer", m_Rparer},
    {"m_cAngle", m_cAngle},
    {"m_xOffset", m_xOffset},
    {"m_yOffset", m_yOffset},
    {"m_scale_radius", m_scale_radius},
    {"m_deflection_angle_radius", m_deflection_angle_radius},
    {
      "m_translate", {
         {"x", m_translate_.x},
         {"y", m_translate_.y},
         {"z", m_translate_.z},
      }
    },
    {
      "m_rotate", {
         {"x", m_rotate_.x},
         {"y", m_rotate_.y},
         {"z", m_rotate_.z},
      }
    },
    {"m_angle",  (float)m_angle_},
    {
      "m_scale", {
         {"x", m_scale_.x},
         {"y", m_scale_.y},
         {"z", m_scale_.z},
      }
    },
    {"blurRadius", m_blurRadius},
    {"sampleNum", m_sampleNum},
    {"bilateral_threshold", m_bilateralThreshold},
    {"filter_aspect_ratio", m_filterAspectRatio},
    {"mini_filter", m_minFilter},
    {"max_filter", m_magFilter}
  };
  cfg_ctrl[c_name.c_str()]["curved_param"]["filter_aspect_ratio"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_filterAspectRatio = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["curved_param"]["mini_filter"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_minFilter = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["curved_param"]["max_filter"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_magFilter = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["curved_param"]["bilateral_threshold"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_bilateralThreshold = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["curved_param"]["blurRadius"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_blurRadius = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["curved_param"]["sampleNum"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_sampleNum = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["curved_param"]["m_Rparer"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_Rparer = (float)src;
     _updateVBOTag = true;
     return true;
  });
  cfg_ctrl[c_name.c_str()]["curved_param"]["m_cAngle"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_cAngle = (float)src;
     _updateVBOTag = true;
     return true;
  });
  cfg_ctrl[c_name.c_str()]["curved_param"]["m_xOffset"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_xOffset = (float)src;
     _updateVBOTag = true;
     return true;
  });
  cfg_ctrl[c_name.c_str()]["curved_param"]["m_yOffset"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_yOffset = (float)src;
     _updateVBOTag = true;
     return true;
  });
  cfg_ctrl[c_name.c_str()]["curved_param"]["m_scale_radius"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_scale_radius = (float)src;
     _updateVBOTag = true;
     return true;
  });
  cfg_ctrl[c_name.c_str()]["curved_param"]["m_deflection_angle_radius"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_deflection_angle_radius = (float)src;
     _updateVBOTag = true;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["curved_param"]["m_translate"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_translate_.x = (float)src["x"];
     m_translate_.y = (float)src["y"];
     m_translate_.z = (float)src["z"];
     return true;
  });
  cfg_ctrl[c_name.c_str()]["curved_param"]["m_rotate"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_rotate_.x = (float)src["x"];
     m_rotate_.y = (float)src["y"];
     m_rotate_.z = (float)src["z"];
     return true;
  });
  cfg_ctrl[c_name.c_str()]["curved_param"]["m_angle"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_angle_ = (float)src;
     return true;
  });
  cfg_ctrl[c_name.c_str()]["curved_param"]["m_scale"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_scale_.x = (float)src["x"];
     m_scale_.y = (float)src["y"];
     m_scale_.z = (float)src["z"];
     return true;
  });

  m_winWidth = m_MainRenderer->m_iWidth;
  m_winHeight = m_MainRenderer->m_iHeight;
  initProj();

  m_frameData.NumDisplayCols_Tissue = 256;      //real cols in frame data
  m_frameData.NumDisplayRows_Tissue = 512;      //real rows in frame data

  m_frameData.Max_display_cols = 640 * 2;       //max cols in frame data
  m_frameData.Max_display_rows = 480 * 2;       //max row in frame data

  auto covert_prob_info_to_cfg_ = [](
      configuru::Config &_cAngle,
      configuru::Config &_Rparer,
      configuru::Config &_translate,
      configuru::Config &_scale,
      configuru::Config &_xOffset,
      configuru::Config &_yOffset,
      configuru::Config &_scale_radius,
      const float &probe_angle,
      const float &probe_inner_radius,
      const float &depth,
      const float &deflection_angle,
      const float &dirty_scale_tex_y) -> bool {
    auto c_angle = probe_angle / 180.f * PI;
    auto scale = dirty_scale_tex_y * (probe_inner_radius + depth) / ((1 - cos(c_angle / 2.f)) * probe_inner_radius + depth);
    auto rparer = probe_inner_radius / (depth + probe_inner_radius);
    _cAngle << c_angle;
    _Rparer << rparer;
    _scale_radius << scale;
    _yOffset << 0 - rparer * (cos(c_angle / 2.f)) * scale;
    float deflection_angle_ = 15.f;
    return true;
  };

  if (cfg_ctrl.has_key("dev_sync_tag") &&
      cfg_ctrl["dev_sync_tag"].has_key("probe_angle") &&
      cfg_ctrl["dev_sync_tag"].has_key("probe_inner_radius") &&
      cfg_ctrl.has_key("fpga_table") &&
      cfg_ctrl["fpga_table"].has_key("ARGS_LINEAR_DEFLECTION_ANGLE") &&
      cfg_ctrl["fpga_table"].has_key("ARGS_B_FACTOR")
      ) {
    auto cur_operate_parm = cfg_ctrl[c_name.c_str()]["curved_param"];
    covert_prob_info_to_cfg_(
          cur_operate_parm["m_cAngle"],
          cur_operate_parm["m_Rparer"],
          cur_operate_parm["m_translate"],
          cur_operate_parm["m_scale"],
          cur_operate_parm["m_xOffset"],
          cur_operate_parm["m_yOffset"],
          cur_operate_parm["m_scale_radius"],
          float(cfg_ctrl["dev_sync_tag"]["probe_angle"]),
          float(cfg_ctrl["dev_sync_tag"]["probe_inner_radius"]),
          float(cfg_ctrl["fpga_table"]["ARGS_B_FACTOR"]),
          float(cfg_ctrl["fpga_table"]["ARGS_LINEAR_DEFLECTION_ANGLE"]) - 16,
          512.f/506.f
        );

    cfg_ctrl["fpga_table"]["ARGS_LINEAR_DEFLECTION_ANGLE"].add_callback(
        [c_name](configuru::Config &, const configuru::Config &b)->bool{
        auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
        auto cur_operate_parm = cfg_ctrl[c_name.c_str()]["curved_param"];
        float angle =16 - int(b);
        cur_operate_parm["m_deflection_angle_radius"] << angle;
        return true;
    });

    cfg_ctrl["dev_sync_tag"]["probe_angle"].add_callback(
        [covert_prob_info_to_cfg_, c_name](configuru::Config &, const configuru::Config &b)->bool{
        auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
        auto cur_operate_parm = cfg_ctrl[c_name.c_str()]["curved_param"];
        float angle = int(cfg_ctrl["fpga_table"]["ARGS_LINEAR_DEFLECTION_ANGLE"]) - 16;
        float depth = (float)(cfg_ctrl["fpga_table"]["ARGS_B_FACTOR"]);
        float probe_angle = float(b);
        float probe_inner_radius = float(cfg_ctrl["dev_sync_tag"]["probe_inner_radius"]);
        covert_prob_info_to_cfg_(
              cur_operate_parm["m_cAngle"],
              cur_operate_parm["m_Rparer"],
              cur_operate_parm["m_translate"],
              cur_operate_parm["m_scale"],
              cur_operate_parm["m_xOffset"],
              cur_operate_parm["m_yOffset"],
              cur_operate_parm["m_scale_radius"],
              probe_angle,
              probe_inner_radius,
              depth,
              angle,
              512.f/506.f
            );
        return true;
    });

    cfg_ctrl["dev_sync_tag"]["probe_inner_radius"].add_callback(
        [covert_prob_info_to_cfg_, c_name](configuru::Config &, const configuru::Config &b)->bool{
        auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
        auto cur_operate_parm = cfg_ctrl[c_name.c_str()]["curved_param"];
        float angle = int(cfg_ctrl["fpga_table"]["ARGS_LINEAR_DEFLECTION_ANGLE"]) - 16;
        float depth = (float)(cfg_ctrl["fpga_table"]["ARGS_B_FACTOR"]);
        float probe_angle = float(cfg_ctrl["dev_sync_tag"]["probe_angle"]);
        float probe_inner_radius = float(b);
        covert_prob_info_to_cfg_(
              cur_operate_parm["m_cAngle"],
              cur_operate_parm["m_Rparer"],
              cur_operate_parm["m_translate"],
              cur_operate_parm["m_scale"],
              cur_operate_parm["m_xOffset"],
              cur_operate_parm["m_yOffset"],
              cur_operate_parm["m_scale_radius"],
              probe_angle,
              probe_inner_radius,
              depth,
              angle,
              512.f/506.f
            );
        return true;
    });

    cfg_ctrl["fpga_table"]["ARGS_B_FACTOR"].add_callback(
        [covert_prob_info_to_cfg_, c_name](configuru::Config &, const configuru::Config &b)->bool{
        auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
        auto cur_operate_parm = cfg_ctrl[c_name.c_str()]["curved_param"];
        float angle = int(cfg_ctrl["fpga_table"]["ARGS_LINEAR_DEFLECTION_ANGLE"]) - 16;
        float depth = float(b);
        float probe_angle = float(cfg_ctrl["dev_sync_tag"]["probe_angle"]);
        float probe_inner_radius = float(cfg_ctrl["dev_sync_tag"]["probe_inner_radius"]);
        covert_prob_info_to_cfg_(
              cur_operate_parm["m_cAngle"],
              cur_operate_parm["m_Rparer"],
              cur_operate_parm["m_translate"],
              cur_operate_parm["m_scale"],
              cur_operate_parm["m_xOffset"],
              cur_operate_parm["m_yOffset"],
              cur_operate_parm["m_scale_radius"],
              probe_angle,
              probe_inner_radius,
              depth,
              angle,
              512.f/506.f
            );
        return true;
    });
  }
  return true;
}

void TissueConvexArrayProbeRenderer::updateVBO() {
    float new_r = sqrt(abs(pow(m_Rparer, 2) + pow(1 - m_Rparer, 2) - 2 * (1 - m_Rparer) * m_Rparer * cos(PI - abs(m_deflection_angle_radius)/180.f * PI)));
    float r_2 = acos((pow(m_Rparer, 2) + pow(new_r, 2) - pow(1 - m_Rparer, 2))/(2 * m_Rparer * new_r) * 0.99999f);
    if (m_deflection_angle_radius < 0) r_2 *= -1.f;
    GLint iOffset = 0;
    GLint jOffset = 0;
    for(int i = 0; i <= nAngles; i++) {
      GLfloat fWeight = GLfloat(nAngles - i) / GLfloat(nAngles);
      GLfloat angle = m_cAngle * fWeight;
      if (i == 0 || i == nAngles) {
        vertices[iOffset++] = sin(angle - m_cAngle/2.0f + r_2) * new_r * m_scale_radius + m_xOffset;
        vertices[iOffset++] = cos(angle - m_cAngle/2.0f + r_2) * new_r * m_scale_radius + m_yOffset;
        vertices[iOffset++] = 0.0f;

        vertices[iOffset++] = (m_Rparer * sin(angle - m_cAngle/2.0f)) * m_scale_radius + m_xOffset;
        vertices[iOffset++] = (m_Rparer * cos(angle - m_cAngle/2.0f)) * m_scale_radius + m_yOffset;
        vertices[iOffset++] = 0.0f;
      } else {
        if (i % 2) {
          vertices[iOffset++] = sin(angle - m_cAngle/2.0f + r_2) * new_r * m_scale_radius + m_xOffset;
          vertices[iOffset++] = cos(angle - m_cAngle/2.0f + r_2) * new_r * m_scale_radius + m_yOffset;
          vertices[iOffset++] = 0.0f;
        } else {
          vertices[iOffset++] = (m_Rparer * sin(angle - m_cAngle/2.0f)) * m_scale_radius + m_xOffset;
          vertices[iOffset++] = (m_Rparer * cos(angle - m_cAngle/2.0f)) * m_scale_radius + m_yOffset;
          vertices[iOffset++] = 0.0f;
        }
      }
    }

    GLfloat fWeight = 0;
    GLfloat fWeightNext = 1 / GLfloat(nAngles) ;

    tcoords[jOffset++] = 1.0f;
    tcoords[jOffset++] = fWeightNext;
    tcoords[jOffset++] = 0.0f;

    tcoords[jOffset++] = 0.0f;
    tcoords[jOffset++] = fWeight;
    tcoords[jOffset++] = 0.0f;

    tcoords[jOffset++] = 1.0f;
    tcoords[jOffset++] = fWeight;
    tcoords[jOffset++] = 0.0f;


    for(int j = 1; j < nAngles; j++) {
      GLfloat fWeightLast = (j*3 - 1) / GLfloat(nAngles) ;
      GLfloat fWeight = j*3 / GLfloat(nAngles);
      GLfloat fWeightNext = (j*3 + 1) / GLfloat(nAngles) ;
      if (j % 2) {
        tcoords[jOffset++] = 0.0f;
        tcoords[jOffset++] = fWeightLast;
        tcoords[jOffset++] = 0.0f;

        tcoords[jOffset++] = 1.0f;
        tcoords[jOffset++] = fWeight;
        tcoords[jOffset++] = 0.0f;

        tcoords[jOffset++] = 0.0f;
        tcoords[jOffset++] = fWeightNext;
        tcoords[jOffset++] = 0.0f;
      } else {
        tcoords[jOffset++] = 1.0f;
        tcoords[jOffset++] = fWeightNext;
        tcoords[jOffset++] = 0.0f;

        tcoords[jOffset++] = 0.0f;
        tcoords[jOffset++] = fWeight;
        tcoords[jOffset++] = 0.0f;

        tcoords[jOffset++] = 1.0f;
        tcoords[jOffset++] = fWeightLast;
        tcoords[jOffset++] = 0.0f;
      }
    }

    GLfloat fWeightLast = (nAngles*3 - 1) / GLfloat(nAngles) ;
    fWeight = nAngles*3 / GLfloat(nAngles);
    fWeightNext = nAngles*3 / GLfloat(nAngles) ;

    if (nAngles % 2) {
      tcoords[jOffset++] = 0.0f;
      tcoords[jOffset++] = fWeightLast;
      tcoords[jOffset++] = 0.0f;

      tcoords[jOffset++] = 1.0f;
      tcoords[jOffset++] = fWeight;
      tcoords[jOffset++] = 0.0f;

      tcoords[jOffset++] = 0.0f;
      tcoords[jOffset++] = fWeightNext;
      tcoords[jOffset++] = 0.0f;
    } else {
      tcoords[jOffset++] = 1.0f;
      tcoords[jOffset++] = fWeightNext;
      tcoords[jOffset++] = 0.0f;

      tcoords[jOffset++] = 0.0f;
      tcoords[jOffset++] = fWeight;
      tcoords[jOffset++] = 0.0f;

      tcoords[jOffset++] = 1.0f;
      tcoords[jOffset++] = fWeightLast;
      tcoords[jOffset++] = 0.0f;
    }

    glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glBindBuffer(GL_ARRAY_BUFFER, m_VBOTexture);
    glBufferData(GL_ARRAY_BUFFER, sizeof(tcoords), tcoords, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    _updateVBOTag = false;
}

void TissueConvexArrayProbeRenderer::CreateVBO() {
  m_VBO = m_MainRenderer->CreateBufferObject();
  m_VBOTexture = m_MainRenderer->CreateBufferObject();
  updateVBO();
}

//void TissueConvexArrayProbeRenderer::InitVertexArray() {
//  glGenVertexArrays(1, &m_VA);
//  glBindVertexArray(m_VA);
//  glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
//  glVertexAttribPointer(POSITION, 3, GL_FLOAT, GL_FALSE, 0, 0);
//  glBindBuffer(GL_ARRAY_BUFFER, 0);

//  glBindBuffer(GL_ARRAY_BUFFER, m_VBOTexture);
//  glVertexAttribPointer(TEXCOORD, 3, GL_FLOAT, GL_FALSE, 0, 0);
//  glBindBuffer(GL_ARRAY_BUFFER, 0);

//  glEnableVertexAttribArray(POSITION);
//  glEnableVertexAttribArray(TEXCOORD);
//  glBindVertexArray(0);
//}
