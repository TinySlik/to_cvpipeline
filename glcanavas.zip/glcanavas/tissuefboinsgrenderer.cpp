/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include "tissuefboinsgrenderer.h"

#include <QtGui/QOpenGLFramebufferObject>

#include <QtQuick/QQuickWindow>
#include <qsgsimpletexturenode.h>

#define DEBUG_QT_LOGO_IN_RENDERER false

#if DEBUG_QT_LOGO_IN_RENDERER

#include "logorenderer.h"

#else

#include "tissuebaseultrasoundrenderer.h"
#include "tissuebaseultrasoundrendereres.h"

#endif

#if DEBUG_QT_LOGO_IN_RENDERER
class LogoInFboRenderer : public QQuickFramebufferObject::Renderer {

 public:
  LogoInFboRenderer()
  {
    logo.initialize();
  }

  void render() override {
    logo.render();
    update();
  }

  QOpenGLFramebufferObject *createFramebufferObject(const QSize &size) override {
    QOpenGLFramebufferObjectFormat format;
    format.setAttachment(QOpenGLFramebufferObject::CombinedDepthStencil);
    format.setSamples(4);
    return new QOpenGLFramebufferObject(size, format);
  }

  LogoRenderer logo;
};
#else
class GraphInFboTissueRenderer : public QQuickFramebufferObject::Renderer {

 public:
  GraphInFboTissueRenderer() {
    tex_content.initialize();
  }

  void render() override {
    tex_content.render();
    update();
  }

  QOpenGLFramebufferObject *createFramebufferObject(const QSize &size) override {
    QOpenGLFramebufferObjectFormat format;
    format.setAttachment(QOpenGLFramebufferObject::CombinedDepthStencil);
    format.setSamples(4);
    return new QOpenGLFramebufferObject(size, format);
  }

  TissueUltrasoundRenderer tex_content;
};

class GraphInFboTissueRendererES : public QQuickFramebufferObject::Renderer {

 public:
  GraphInFboTissueRendererES() {
    tex_content.initializeGL();
    tex_content.resizeGL(640,480);
  }

  void render() override {
    tex_content.paintGL();
    update();
  }

  QOpenGLFramebufferObject *createFramebufferObject(const QSize &size) override {
    QOpenGLFramebufferObjectFormat format;
    format.setAttachment(QOpenGLFramebufferObject::CombinedDepthStencil);
    format.setSamples(4);
    return new QOpenGLFramebufferObject(size, format);
  }

  TissueBaseUltrasoundRendererES tex_content;
};
#endif

QQuickFramebufferObject::Renderer *TissueFboInSGRenderer::createRenderer() const {
#if DEBUG_QT_LOGO_IN_RENDERER
  return new LogoInFboRenderer();
#else
  return new GraphInFboTissueRendererES();
#endif
}
