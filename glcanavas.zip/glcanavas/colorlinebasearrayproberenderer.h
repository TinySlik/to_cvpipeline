/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef COLORLINEBASEARRAYPROBERENDERER_H
#define COLORLINEBASEARRAYPROBERENDERER_H

#include "colorbasearrayproberenderer.h"

class ColorLineBaseArrayProbeRenderer :
    public ColorBaseArrayProbeRenderer,
    std::enable_shared_from_this<ColorLineBaseArrayProbeRenderer> {
 public:
  ColorLineBaseArrayProbeRenderer(ProberContinerProof *mainRender);
  virtual void CreateVBO() override;
  virtual void InitVertexArray() override;
  virtual bool initShaders() override;
  virtual void initParams() override;
  virtual void RenderImage() override;

 private:
  glm::mat4 TransformImage();
};

#endif // COLORLINEBASEARRAYPROBERENDERER_H
