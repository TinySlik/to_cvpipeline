#ifndef TISSUEBASEULTRASOUNDRENDERERES_H
#define TISSUEBASEULTRASOUNDRENDERERES_H

#include "geometryengine.h"

#include <QOpenGLWidget>
#include <QOpenGLFunctions>
#include <QMatrix4x4>
#include <QQuaternion>
#include <QVector2D>
#include <QBasicTimer>
#include <QOpenGLShaderProgram>
#include <QOpenGLTexture>

#include <QtGui/qvector3d.h>
#include <QtGui/qmatrix4x4.h>
#include <QtGui/qopenglshaderprogram.h>
#include <QtGui/qopenglfunctions.h>
#include <QtGui\QOpenGLFunctions_3_3_Compatibility>
#include <QtOpenGL\QGLWidget>
#include <QtOpenGL\QGLShaderProgram>
#include <mutex>
#include "glm\glm.hpp"
#include "glm\gtc\color_space.hpp"
#include "glm\gtc\type_ptr.hpp"
#include "glm\gtc\matrix_transform.hpp"
#include "pipelinerecvserv.h"
#include "lutmode.h"

#include <QTime>
#include <QVector>
#include <QOpenGLTexture>

class GeometryEngine;

class TissueBaseUltrasoundRendererES :
  protected QOpenGLFunctions {
public:
  TissueBaseUltrasoundRendererES();
  ~TissueBaseUltrasoundRendererES();

  void initializeGL();
  void resizeGL(int w, int h);
  void paintGL();

  void initShaders();
  void initTextures();

private:
  QBasicTimer timer;
  QOpenGLShaderProgram program;
  GeometryEngine *geometries;

  QOpenGLTexture *texture;

  QMatrix4x4 projection;

  QVector2D mousePressPosition;
  QVector3D rotationAxis;
  qreal angularSpeed;
  QQuaternion rotation;
};

#endif // TISSUEBASEULTRASOUNDRENDERERES_H
