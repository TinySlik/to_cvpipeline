/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include "pipelinerecvserv.h"
#define WIDTH_IN_DIM 0
#define HEIGHT_IN_DIM 1

static bool compare_pipeline_data_dimesion_info(uchar *src1, uchar *src2, size_t &size) {
  size = 0;
  if (src1) size = (size_t)(*src1)*4+1;
  if (src1 && src2 && *src1 == *src2) {
    for (size_t i = 0; i < (size_t)(*src1) + 1; i++) {
      if (*src1 ++ != *src2 ++) {
        return false;
      }
    }
  } else {
    return false;
  }
  return true;
}
static bool compare_pipeline_data_pixeal_info(uchar *src1, uchar *src2, size_t &size) {
  size = 0;
  if (src1) size = (size_t)(*src1)*4+1;
  if (src1 && src2 && *src1 == *src2) {
    for (size_t i = 0; i < (size_t)(*src1) + 1; i++) {
      if (*src1 ++ != *src2 ++) {
        return false;
      }
    }
  } else {
    return false;
  }
  return true;
}
static bool compare_pipeline_data_format(uchar *src1, uchar *src2) {
  size_t stepsize = 0;
  return compare_pipeline_data_dimesion_info(src1, src2, stepsize) &&
         compare_pipeline_data_pixeal_info(src1 + stepsize, src2 + stepsize, stepsize);
}

PipelineRecvServ::PipelineRecvServ() :
_data_enable(false) {
}
PipelineRecvServ::~PipelineRecvServ() {
}

void PipelineRecvServ::onDataHeadInfoChange(unsigned char *) {
  qDebug() << __FUNCTION__ << "no implimation";
}

bool PipelineRecvServ::judgeAndProcessData(std::shared_ptr<std::vector<std::uint8_t>> data) {
  static bool init_tag = false;
  if (!init_tag) {
//    _enable = true;
    init_tag = true;
    onDataHeadInfoChange(data->data());
  }
  if (!_data_enable) return false;
  onRecvPipelineData((char *)(data->data()));
  return true;
}
size_t PipelineRecvServ::getDim(size_t) {
  qDebug() << __FUNCTION__ << "no implimation";
  return 0;
}
size_t PipelineRecvServ::getWidth() {
  qDebug() << __FUNCTION__ << "no implimation";
  return 0;
}
size_t PipelineRecvServ::getHeight() {
  qDebug() << __FUNCTION__ << "no implimation";
  return 0;
}
size_t PipelineRecvServ::getBPP() {
  qDebug() << __FUNCTION__ << "no implimation";
  return 0;
}
uint64_t PipelineRecvServ::getCurrentTimeStamp(char *) {
  qDebug() << __FUNCTION__ << "no implimation";
  return 0;
}
uint64_t PipelineRecvServ::getCurrentDataStamp(char *) {
  qDebug() << __FUNCTION__ << "no implimation";
  return 0;
}
std::string PipelineRecvServ::getPixealFormat() {
  qDebug() << __FUNCTION__ << "no implimation";
  return "";
}


PipelineRawRecvServ::PipelineRawRecvServ() {
  // to do
}
PipelineRawRecvServ::~PipelineRawRecvServ() {
  //
}

void PipelineRawRecvServ::onDataHeadInfoChange(unsigned char *) {
  _data_enable = true;
}
std::string PipelineRawRecvServ::getPixealFormat() {
  return "unknow";
}


PipelineTissueRecvServ::~PipelineTissueRecvServ() {
  // todo
}

PipelineTissueRecvServ::PipelineTissueRecvServ() {
  _head_info.resize(getHeadSize());
  memset(_head_info.data(), 0, getHeadSize());
  m_PipelineDomSingleton = PipelineEngineSingleton::instance();
  m_PipelineDomSingleton->setRecvCallback([this](std::shared_ptr<std::vector<std::uint8_t>> data) {
    judgeAndProcessData(data);
  });
}

void PipelineTissueRecvServ::onDataHeadInfoChange(unsigned char *) {
  qDebug() << __FUNCTION__ << getWidth();
  qDebug() << __FUNCTION__ << getHeight();
  qDebug() << __FUNCTION__ << getBPP();
  qDebug() << __FUNCTION__ << getPixealFormat().c_str();
}

uint64_t PipelineTissueRecvServ::getCurrentTimeStamp(char *infoHead) {
  auto time_stamp_ptr = (uint64_t *)(infoHead + 8);
  return *time_stamp_ptr;
}
uint64_t PipelineTissueRecvServ::getCurrentDataStamp(char *infoHead) {
  auto data_stamp_ptr = (uint64_t *)(infoHead + 16);
  return *data_stamp_ptr;
}

size_t PipelineTissueRecvServ::getDim(size_t index) {
  if (*(_head_info.data()+24) > index) {
    auto cur = (uint32_t *)(_head_info.data() + 25 + index * 4);
    return *cur;
  }
  return 0;
}

size_t PipelineTissueRecvServ::getWidth() {
  return getDim(WIDTH_IN_DIM);
}

size_t PipelineTissueRecvServ::getHeight() {
  return getDim(HEIGHT_IN_DIM);
}

size_t PipelineTissueRecvServ::getBPP() {
  auto bpp = (char *)(_head_info.data() + 25 + (size_t)*(_head_info.data()+24) * 4);
  return (size_t)(*bpp);
}

std::string PipelineTissueRecvServ::getPixealFormat() {
  auto res = (char *)(_head_info.data() + 25 + (size_t)*(_head_info.data()+24) * 4 + 1);
  return std::string(res);
}

bool PipelineTissueRecvServ::judgeAndProcessData(std::shared_ptr<std::vector<std::uint8_t>> data) {
  bool info_change_tag = true;
  if (strncmp((char *)(_head_info.data()), (char *)(data->data()), 8) == 0 && compare_pipeline_data_format(_head_info.data()+24, data->data()+24)) {
    info_change_tag = false;
  } else {
    memcpy_s(_head_info.data(), getHeadSize(), data->data(), getHeadSize());
    if (strcmp((const char *)(_head_info.data()), getDecodeProof().c_str()) == 0) {
        qDebug() << "Data Info Decode Proof:" << getDecodeProof().c_str() << "matched";
        onDataHeadInfoChange(_head_info.data());
    }
  }
#if 0
  qDebug() << __FUNCTION__ << "data size: "<< data->size() << "bingo";

  auto cur_ptr = (char *)data->data();
  // 8 byte proff
  qDebug() << "PROOF: " << cur_ptr;
  cur_ptr += 8;
  // 8 byte timestamp
  auto time_ptr = (uint64_t *)cur_ptr;
  qDebug() << "time:" << *time_ptr;
  cur_ptr += 8;

  // 8 byte data index
  auto cur_uint64_t_val2_ptr = (uint64_t *)cur_ptr;
  qDebug() << "index:" << *cur_uint64_t_val2_ptr;
  cur_ptr += 8;

  // 1 byte dimesions size
  size_t  sz = *cur_ptr;
  qDebug() << "dim size:" << sz;
  cur_ptr++;

  // n dimesions size * 4 byte dimesions data
  for (size_t j=0; j< sz; j++) {
     auto cur_short_val = (uint32_t *)cur_ptr;
     qDebug() << "dim" << j  << ":"<< *cur_short_val;
     cur_ptr += 4;
  }

  // 1 byte bpp
  size_t bpp_sz = (size_t)(*cur_ptr);
  qDebug() << "bpp" << (size_t)(*cur_ptr);
  cur_ptr++;

  // bpp byte pixeal format
  for (size_t k=0; k< bpp_sz; k++) {
    qDebug() << *cur_ptr;
  }
#endif
  if (!_data_enable) return false;
  onRecvPipelineData((char *)(data->data() + getHeadSize()));
  return true;
}


PipelineColorRecvServ::PipelineColorRecvServ() {
  _head_info.resize(getHeadSize());
  memset(_head_info.data(), 0, getHeadSize());
  m_PipelineDomSingleton = PipelineEngineSingleton::instance();
  m_PipelineDomSingleton->setCRecvCallback([this](std::shared_ptr<std::vector<std::uint8_t>> data) {
    judgeAndProcessData(data);
  });
}
PipelineColorRecvServ::~PipelineColorRecvServ(){
  //
}
void PipelineColorRecvServ::onDataHeadInfoChange(unsigned char *data) {
  qDebug() << __FUNCTION__ << getWidth();
  qDebug() << __FUNCTION__ << getHeight();
  qDebug() << __FUNCTION__ << getBPP();
  qDebug() << __FUNCTION__ << getPixealFormat().c_str();
}
bool PipelineColorRecvServ::judgeAndProcessData(std::shared_ptr<std::vector<std::uint8_t>> data) {
  bool info_change_tag = true;
  if (strncmp((char *)(_head_info.data()), (char *)(data->data()), 8) == 0 && compare_pipeline_data_format(_head_info.data()+24, data->data()+24)) {
    info_change_tag = false;
  } else {
    memcpy_s(_head_info.data(), getHeadSize(), data->data(), getHeadSize());
    if (strcmp((const char *)(_head_info.data()), getDecodeProof().c_str()) == 0) {
        qDebug() << "Data Info Decode Proof:" << getDecodeProof().c_str() << "matched";
        onDataHeadInfoChange(_head_info.data());
    }
  }
#if 0
  qDebug() << __FUNCTION__ << "data size: "<< data->size() << "bingo";

  // 8 byte timestamp
  auto cur_ptr = (char *)data->data();

  qDebug() << "PROOF: " << cur_ptr;
  cur_ptr += 8;

  auto time_ptr = (uint64_t *)cur_ptr;
  qDebug() << "time:" << *time_ptr;
  cur_ptr += 8;

  // 8 byte data index
  auto cur_uint64_t_val2_ptr = (uint64_t *)cur_ptr;
  qDebug() << "index:" << *cur_uint64_t_val2_ptr;
  cur_ptr += 8;

  // 1 byte dimesions size
  size_t  sz = *cur_ptr;
  qDebug() << "dim size:" << sz;
  cur_ptr++;

  // n dimesions size * 4 byte dimesions data
  for (size_t j=0; j< sz; j++) {
     auto cur_short_val = (uint32_t *)cur_ptr;
     qDebug() << "dim" << j  << ":"<< *cur_short_val;
     cur_ptr += 4;
  }

  // 1 byte bpp
  size_t bpp_sz = (size_t)(*cur_ptr);
  qDebug() << "bpp" << (size_t)(*cur_ptr);
  cur_ptr++;

  // bpp byte pixeal format
  for (size_t k=0; k< bpp_sz; k++) {
    qDebug() << *cur_ptr;
  }
#endif
  if (!_data_enable) return false;
  onRecvPipelineData((char *)(data->data() + getHeadSize()));
  return true;
}
size_t PipelineColorRecvServ::getDim(size_t index) {
  if (*(_head_info.data()+24) > index) {
    auto cur = (uint32_t *)(_head_info.data() + 25 + index * 4);
    return *cur;
  }
  return 0;
}
size_t PipelineColorRecvServ::getWidth() {
  return getDim(WIDTH_IN_DIM);
}
size_t PipelineColorRecvServ::getHeight() {
  return getDim(HEIGHT_IN_DIM);
}
size_t PipelineColorRecvServ::getBPP() {
  auto bpp = (char *)(_head_info.data() + 25 + (size_t)*(_head_info.data()+24) * 4);
  return (size_t)(*bpp);
}
uint64_t PipelineColorRecvServ::getCurrentTimeStamp(char *infoHead) {
  auto time_stamp_ptr = (uint64_t *)(infoHead + 8);
  return *time_stamp_ptr;
}
uint64_t PipelineColorRecvServ::getCurrentDataStamp(char *infoHead) {
  auto data_stamp_ptr = (uint64_t *)(infoHead + 16);
  return *data_stamp_ptr;
}
std::string PipelineColorRecvServ::getPixealFormat() {
  auto res = (char *)(_head_info.data() + 25 + (size_t)*(_head_info.data()+24) * 4 + 1);
  return std::string(res);
}

PipelinePWRecvServ::PipelinePWRecvServ() {
  _head_info.resize(getHeadSize());
  memset(_head_info.data(), 0, getHeadSize());
  m_PipelineDomSingleton = PipelineEngineSingleton::instance();
  m_PipelineDomSingleton->setPWRecvCallback([this](std::shared_ptr<std::vector<std::uint8_t>> data) {
    judgeAndProcessData(data);
  });
}
PipelinePWRecvServ::~PipelinePWRecvServ() {}

void PipelinePWRecvServ::onDataHeadInfoChange(unsigned char *data) {
  qDebug() << __FUNCTION__ << getWidth();
  qDebug() << __FUNCTION__ << getHeight();
  qDebug() << __FUNCTION__ << getBPP();
  qDebug() << __FUNCTION__ << getPixealFormat().c_str();
}

bool PipelinePWRecvServ::judgeAndProcessData(std::shared_ptr<std::vector<std::uint8_t>> data) {
  bool info_change_tag = true;
  if (strncmp((char *)(_head_info.data()), (char *)(data->data()), 8) == 0 && compare_pipeline_data_format(_head_info.data()+24, data->data()+24)) {
    info_change_tag = false;
  } else {
    memcpy_s(_head_info.data(), getHeadSize(), data->data(), getHeadSize());
    if (strcmp((const char *)(_head_info.data()), getDecodeProof().c_str()) == 0) {
        qDebug() << "Data Info Decode Proof:" << getDecodeProof().c_str() << "matched";
        onDataHeadInfoChange(_head_info.data());
    }
  }
#if 0
  qDebug() << __FUNCTION__ << "data size: "<< data->size() << "bingo";

  // 8 byte timestamp
  auto cur_ptr = (char *)data->data();

  qDebug() << "PROOF: " << cur_ptr;
  cur_ptr += 8;

  auto time_ptr = (uint64_t *)cur_ptr;
  qDebug() << "time:" << *time_ptr;
  cur_ptr += 8;

  // 8 byte data index
  auto cur_uint64_t_val2_ptr = (uint64_t *)cur_ptr;
  qDebug() << "index:" << *cur_uint64_t_val2_ptr;
  cur_ptr += 8;

  // 1 byte dimesions size
  size_t  sz = *cur_ptr;
  qDebug() << "dim size:" << sz;
  cur_ptr++;

  // n dimesions size * 4 byte dimesions data
  for (size_t j=0; j< sz; j++) {
     auto cur_short_val = (uint32_t *)cur_ptr;
     qDebug() << "dim" << j  << ":"<< *cur_short_val;
     cur_ptr += 4;
  }

  // 1 byte bpp
  size_t bpp_sz = (size_t)(*cur_ptr);
  qDebug() << "bpp" << (size_t)(*cur_ptr);
  cur_ptr++;

  // bpp byte pixeal format
  for (size_t k=0; k< bpp_sz; k++) {
    qDebug() << *cur_ptr;
  }
#endif
  if (!_data_enable) return false;
  onRecvPipelineData((char *)(data->data() + getHeadSize()));
  return true;
}

size_t PipelinePWRecvServ::getDim(size_t index) {
  if (*(_head_info.data()+24) > index) {
    auto cur = (uint32_t *)(_head_info.data() + 25 + index * 4);
    return *cur;
  }
  return 0;
}
size_t PipelinePWRecvServ::getWidth() {
  return getDim(WIDTH_IN_DIM);
}
size_t PipelinePWRecvServ::getHeight() {
  return getDim(HEIGHT_IN_DIM);
}
size_t PipelinePWRecvServ::getBPP() {
  auto bpp = (char *)(_head_info.data() + 25 + (size_t)*(_head_info.data()+24) * 4);
  return (size_t)(*bpp);
}
uint64_t PipelinePWRecvServ::getCurrentTimeStamp(char *infoHead) {
  auto time_stamp_ptr = (uint64_t *)(infoHead + 8);
  return *time_stamp_ptr;
}
uint64_t PipelinePWRecvServ::getCurrentDataStamp(char *infoHead) {
  auto data_stamp_ptr = (uint64_t *)(infoHead + 16);
  return *data_stamp_ptr;
}
std::string PipelinePWRecvServ::getPixealFormat() {
  auto res = (char *)(_head_info.data() + 25 + (size_t)*(_head_info.data()+24) * 4 + 1);
  return std::string(res);
}
