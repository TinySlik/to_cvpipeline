/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef COLORCONVEXBASEARRAYPROBERENDERER_H
#define COLORCONVEXBASEARRAYPROBERENDERER_H

#include "colorbasearrayproberenderer.h"

class ColorConvexBaseArrayProbeRenderer :
    public ColorBaseArrayProbeRenderer,
    std::enable_shared_from_this<ColorConvexBaseArrayProbeRenderer> {
 public:
  ColorConvexBaseArrayProbeRenderer(ProberContinerProof *mainRender);
  virtual void CreateVBO() override;
  virtual void InitVertexArray() override;
  virtual bool initShaders() override;
  virtual void initParams() override;
  virtual void RenderImage() override;

 private:
  void updateVBO();
  glm::mat4 TransformImage();

  GLfloat m_xOffset;
  GLfloat m_yOffset;
  GLfloat m_Rparer;

  GLfloat m_scale_radius;
  GLfloat m_cAngle;
  GLfloat m_deflection_angle_radius;

  const static GLint nAngles = 1024;
  GLfloat vertices[3 * 2 * (nAngles + 1)];
  GLfloat tcoords[3 * (nAngles + 1) * 3];
  bool _updateVBOTag;
};

#endif // COLORCONVEXBASEARRAYPROBERENDERER_H
