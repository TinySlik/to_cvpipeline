/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef COLORBASEARRAYPROBERENDERER_H
#define COLORBASEARRAYPROBERENDERER_H

#include "basearrayproberenderer.h"

class ColorBaseArrayProbeRenderer : public BaseArrayProbeRenderer {
 public:
  ColorBaseArrayProbeRenderer(ProberContinerProof *mainRender);
  virtual ~ColorBaseArrayProbeRenderer();
  virtual bool Init() {
    bool b_success = initShaders();
    initParams();
    CreateVBO();
    InitVertexArray();
    return b_success;
  }
  virtual void Render() {
    RenderImage();
  }

  virtual void CreateVBO() = 0;
  virtual void InitVertexArray() = 0;
  virtual bool initShaders() = 0;
  virtual void initParams() = 0;
  virtual void RenderImage() = 0;
};

#endif // COLORBASEARRAYPROBERENDERER_H
