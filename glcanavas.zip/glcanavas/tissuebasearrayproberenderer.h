/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef TISSUEBASEARRAYPROBERENDERER_H
#define TISSUEBASEARRAYPROBERENDERER_H

#include <QtGui\QOpenGLFunctions_3_3_Compatibility>
#include <QtGui/qopenglshaderprogram.h>
#include "glm\glm.hpp"
#include "glm\gtc\color_space.hpp"
#include "glm\gtc\type_ptr.hpp"
#include "glm\gtc\matrix_transform.hpp"
#include "tissuebaseultrasoundrenderer.h"
#include <QOpenGLBuffer>

class TissueBaseArrayProbeRenderer : protected QOpenGLFunctions, std::enable_shared_from_this<TissueBaseArrayProbeRenderer> {
 public:
  TissueBaseArrayProbeRenderer(TissueUltrasoundRenderer * mainRenderer);
  virtual ~TissueBaseArrayProbeRenderer();
  void SetTexture2DWrapMode(GLint sWrap, GLint tWrap);

  inline bool Init(GLubyte* Tess, GLubyte* color) {
    bool b_success = initParams();
    b_success *= initRenderer();
//    b_success *= InitResources(Tess, color);
    return b_success;
  }

  inline void Render() {
    RenderImage();
  }

  virtual void CreateVBO() {}
  virtual void InitVertexArray() {}
  virtual bool initShadersTissue() {return false;}
  virtual bool initRenderer() {return false;}
  virtual bool initParams() {return false;}
  virtual void initProj() {
    m_Proj = glm::ortho(0.0, GLdouble(m_winWidth), 0.0, GLdouble(m_winHeight), -100.0, +100.0);
  }
  virtual void RenderImage() = 0;
  virtual bool InitResources(GLubyte* Tess, GLubyte* color) = 0;
  inline FrameData GetFrameData() const {
    return m_frameData;
  }
  virtual void setFrontColor(const uint32_t & color_in) {
    m_color = color_in;
  }
  virtual uint32_t getFrontColor() const {
    return m_color;
  }

 protected:
  QOpenGLShaderProgram *m_ProgramTissue;
  QOpenGLShaderProgram *m_ProgramColorVelocity;
  QOpenGLShaderProgram *m_ProgramColorEnergy;

  TissueUltrasoundRenderer *m_MainRenderer;
  FrameData m_frameData;

  GLuint               m_VBO;
  GLuint               m_VBOTexture;
  GLuint               m_VA;

  int                  _qgl_in_Tex_Position;
  int                  _qgl_in_Tex_TexcoordIn;

  QOpenGLBuffer       _arrayBuf;
  QOpenGLBuffer       _texCoordBuf;

  glm::mat4 m_Proj;

  float               m_winWidth;
  float               m_winHeight;
  uint32_t            m_color;
  glm::vec3 m_translate_;
  glm::vec3 m_rotate_;
  float m_skew_x_;
  float m_skew_y_;
  float m_angle_;
  glm::vec3 m_scale_;

  float m_blurRadius;
  float m_sampleNum;
  float m_bilateralThreshold;
  float m_filterAspectRatio;

  float m_minFilter;
  float m_magFilter;
};

#endif // TISSUEBASEARRAYPROBERENDERER_H
