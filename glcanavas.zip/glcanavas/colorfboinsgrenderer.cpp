/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include "colorfboinsgrenderer.h"

#include <QtGui/QOpenGLFramebufferObject>

#include <QtQuick/QQuickWindow>
#include <qsgsimpletexturenode.h>
#include <sstream>

#include "colorbaseultrasoundrenderer.h"

#include "ParameterServer/parameterserver.h"
#include "func/utils.h"
#define CLASS_NAME "ColorFboInSGRenderer"

class GraphInFboColorRenderer : public QQuickFramebufferObject::Renderer {
 public:
  GraphInFboColorRenderer(const std::string &child_name) {
    render_index_ = child_name;
    tex_content.initialize(render_index_);
  }

  void render() override {
    tex_content.render();
    update();
  }

  QOpenGLFramebufferObject *createFramebufferObject(const QSize &size) override {
    QOpenGLFramebufferObjectFormat format;
    format.setAttachment(QOpenGLFramebufferObject::CombinedDepthStencil);
    format.setSamples(4);
    return new QOpenGLFramebufferObject(size, format);
  }

  ColorUltrasoundRenderer tex_content;
  std::string render_index_;
};

QQuickFramebufferObject::Renderer *ColorFboInSGRenderer::createRenderer() const {
  auto render = new GraphInFboColorRenderer(getClassIndex());
  QFile file_color_cfg(g_pipeline_cfg_path() + "c_mode/color_cfg.json");
  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = getClassIndex();
  QFile file_color_map_cfg(g_pipeline_cfg_path() + "old_funny_map.json");
  if (file_color_cfg.exists()) {
    qDebug() << __FUNCTION__ << "load config success!";
    cfg_ctrl[c_name.c_str()] << configuru::parse_file(g_pipeline_cfg_path().toStdString() + "c_mode/color_cfg.json", configuru::JSON);
  }

  if (file_color_map_cfg.exists()) {
    qDebug() << __FUNCTION__ << "load colormap success!";
    cfg_ctrl[c_name.c_str()]["render"]["lut"]["local_colormaplist_index"] = 0;
    cfg_ctrl[c_name.c_str()]["render"]["lut"]["local_colormaplist_index"].add_callback([c_name](configuru::Config &, const configuru::Config &b)->bool{
      auto color_map = configuru::parse_file(g_pipeline_cfg_path().toStdString() + "old_funny_map.json", configuru::JSON);
      auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
      size_t idx = (int)b;
      cfg_ctrl[c_name.c_str()]["render"]["lut"]["color_list_v"] << (color_map["old_funny_map_colormaplist"][idx]);
      return true;
    });
    cfg_ctrl[c_name.c_str()]["render"]["lut"]["local_pdimaplist_index"] = 1;
    cfg_ctrl[c_name.c_str()]["render"]["lut"]["local_pdimaplist_index"].add_callback([c_name](configuru::Config &, const configuru::Config &b)->bool{
      auto color_map = configuru::parse_file(g_pipeline_cfg_path().toStdString() + "old_funny_map.json", configuru::JSON);
      auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
      size_t idx = (int)b;
      cfg_ctrl[c_name.c_str()]["render"]["lut"]["color_list_e"] << (color_map["old_funny_map_pdimaplist"][idx]);
      return true;
    });
    auto color_map = configuru::parse_file(g_pipeline_cfg_path().toStdString() + "old_funny_map.json", configuru::JSON);
    cfg_ctrl[c_name.c_str()]["render"]["lut"]["color_list_v"] << color_map["old_funny_map_colormaplist"][0];
    cfg_ctrl[c_name.c_str()]["render"]["lut"]["color_list_e"] << color_map["old_funny_map_pdimaplist"][1];
    cfg_ctrl[c_name.c_str()]["render"]["lut"]["color_list_v"].set_hiden(true);
    cfg_ctrl[c_name.c_str()]["render"]["lut"]["color_list_e"].set_hiden(true);

    if(!cfg_ctrl["dev_sync_tag"].has_key("color_map_static_index")) {
      cfg_ctrl["dev_sync_tag"]["color_map_static_index"] = 0;
    }
    if(!cfg_ctrl["dev_sync_tag"].has_key("pdi_map_static_index")) {
      cfg_ctrl["dev_sync_tag"]["pdi_map_static_index"] = 1;
    }
    cfg_ctrl["dev_sync_tag"]["color_map_static_index"].add_callback([c_name](configuru::Config &, const configuru::Config &b)->bool{
      auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
      auto index_n = (int)b;
      cfg_ctrl[c_name.c_str()]["render"]["lut"]["local_colormaplist_index"] << index_n;
      return true;
    });
    cfg_ctrl["dev_sync_tag"]["pdi_map_static_index"].add_callback([c_name](configuru::Config &, const configuru::Config &b)->bool{
      auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
      auto index_n = (int)b;
      cfg_ctrl[c_name.c_str()]["render"]["lut"]["local_pdimaplist_index"] << index_n;
      return true;
    });
  } else {
    cfg_ctrl[c_name.c_str()]["render"]["lut"]["color_list_v"].set_hiden(false);
    cfg_ctrl[c_name.c_str()]["render"]["lut"]["color_list_e"].set_hiden(false);
  }

  return render;
}

std::string ColorFboInSGRenderer::getClassIndex() const {
  std::ostringstream tp_name;
  tp_name << CLASS_NAME << this;
  return tp_name.str();
}

ColorFboInSGRenderer::ColorFboInSGRenderer() {
  setVisible(false);
  initParams();
}

void ColorFboInSGRenderer::initParams() {
  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = getClassIndex();
  cfg_ctrl.judge_with_create_key(c_name)["visible"] = isVisible();
  cfg_ctrl[c_name.c_str()]["visible"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool {
    setVisible(bool(b));
    return true;
  });
}
