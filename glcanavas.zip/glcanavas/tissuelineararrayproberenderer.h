/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef LINEARARRAYPROBERENDERER_H
#define LINEARARRAYPROBERENDERER_H

#include "tissuebasearrayproberenderer.h"

class TissueLinearArrayProbeRenderer : public TissueBaseArrayProbeRenderer, std::enable_shared_from_this<TissueLinearArrayProbeRenderer> {
 public:
  TissueLinearArrayProbeRenderer(TissueUltrasoundRenderer * mainRenderer) :
    TissueBaseArrayProbeRenderer(mainRenderer) {
    m_ProgramTissue = &mainRenderer->m_ProgramLinedTissue;
    m_ProgramColorVelocity = &mainRenderer->m_ProgramColorLinedVelocity;
    m_ProgramColorEnergy = &mainRenderer->m_ProgramColorLinedEnergy;
  }

  virtual bool initShadersTissue() override;
  virtual void RenderImage() override;
  virtual void CreateVBO() override;
//  virtual void InitVertexArray() override;

  virtual bool initRenderer() override;

  virtual bool InitResources(GLubyte* Tess, GLubyte* color) override;
  bool initParams() override;
};


#endif // LINEARARRAYPROBERENDERER_H
