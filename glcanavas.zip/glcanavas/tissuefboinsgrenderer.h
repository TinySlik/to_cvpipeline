/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef FBOINSGTISSUERENDERER_H
#define FBOINSGTISSUERENDERER_H

#include <QtQuick/QQuickFramebufferObject>

class TissueFboInSGRenderer : public QQuickFramebufferObject {
  Q_OBJECT
 public:
  Renderer *createRenderer() const;
};

#endif // FBOINSGTISSUERENDERER_H
