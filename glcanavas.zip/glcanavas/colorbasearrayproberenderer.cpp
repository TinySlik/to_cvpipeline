/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include "colorbasearrayproberenderer.h"

ColorBaseArrayProbeRenderer::ColorBaseArrayProbeRenderer(ProberContinerProof *mainRender) :
  BaseArrayProbeRenderer(mainRender) {
}


ColorBaseArrayProbeRenderer::~ColorBaseArrayProbeRenderer() {
  //
}
