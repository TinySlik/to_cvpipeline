/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef PWULTRASOUNDRENDERER_H
#define PWULTRASOUNDRENDERER_H

#include <QtGui/qvector3d.h>
#include <QtGui/qmatrix4x4.h>
#include <QtGui/qopenglshaderprogram.h>
#include <QtGui/qopenglfunctions.h>
#include <QtGui\QOpenGLFunctions_3_3_Compatibility>
#include <QtOpenGL\QGLWidget>
#include <QtOpenGL\QGLShaderProgram>
#include <mutex>
#include "glm\glm.hpp"
#include "glm\gtc\color_space.hpp"
#include "glm\gtc\type_ptr.hpp"
#include "glm\gtc\matrix_transform.hpp"
#include "pipelinerecvserv.h"

#include <QTime>
#include <QVector>

#define PW_LINE_LENGTH 32;

class PWUltrasoundRenderer : public PipelinePWRecvServ,
    protected QOpenGLFunctions_3_3_Compatibility {
public:
 PWUltrasoundRenderer();
 ~PWUltrasoundRenderer();
 void render();
 void initialize();
 void initParams();
public slots:
 void UpdateDisplay();
 bool onRecvPipelineData(char *data) override;
 void onDataHeadInfoChange(unsigned char *data) override;
public:
 virtual void paintGL();
 virtual void resizeGL(int nwidth, int nheight);

 std::string getClassIndex();
public:

 bool                 m_bInitialized;
private:
 std::vector<unsigned char> _data;
 std::mutex           m_mtxPaint;
 //Geometry
 glm::mat4            m_Proj;
 int                  m_backGroundColor;
};

#endif // PWULTRASOUNDRENDERER_H
