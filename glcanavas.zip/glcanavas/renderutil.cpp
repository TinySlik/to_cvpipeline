/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include "renderutil.h"

int str_to_hex(char *string, unsigned char *cbuf, int len) {
  unsigned char high, low;
  int idx, ii=0;
  for (idx=0; idx<len/2; idx+=2) {
    unsigned char  tmp_high = string[idx];
    unsigned char  tmp_low = string[idx+1];
    string[idx] = string[8 - 2 - idx];
    string[idx+1] = string[8 - 2 - idx + 1];
    string[8 - 2 - idx] = tmp_high;
    string[8 - 2 - idx + 1] = tmp_low;
  }
  for (idx=0; idx<len; idx+=2) {
    high = string[idx];
    low = string[idx+1];

    if(high>='0' && high<='9')
      high = high-'0';
    else if(high>='A' && high<='F')
      high = high - 'A' + 10;
    else if(high>='a' && high<='f')
      high = high - 'a' + 10;
    else
      return -1;

    if(low>='0' && low<='9')
      low = low-'0';
    else if(low>='A' && low<='F')
      low = low - 'A' + 10;
    else if(low>='a' && low<='f')
      low = low - 'a' + 10;
    else
      return -1;
    cbuf[ii++] = high<<4 | low;
  }
  return 0;
}

void hex_to_str(char *ptr,unsigned char *buf,int len) {
  for(int i = len-1; i >= 0; i--) {
    sprintf(ptr, "%02x",buf[i]);
    ptr += 2;
  }
}

std::string color_format_int_to_string(const uint32_t &color) {
  std::string res = "#";
  char color_str[16];
  hex_to_str(color_str, (unsigned char*)(&color), 4);
  res += color_str;
  return res;
}

uint32_t color_format_string_to_int(const std::string &color) {
  uint32_t res = 0xffffffff;
  auto hd = (char *)strstr(color.c_str(),"#");
  if (hd) {
    if (color.length() == 9) {
      if (str_to_hex(hd+1,(unsigned char *)&res, 8) >= 0) {
        return res;
      }
    } else if (color.length() == 7){
      auto color_tmp = color + "ff";
      hd = (char *)strstr(color_tmp.c_str(),"#");
      if (str_to_hex(hd+1,(unsigned char *)&res, 8) >= 0) {
        return res;
      }
    }
  }
  return 0xffffffff;
}


//glm part~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

glm::vec4 color_format_int_to_glm(const uint32_t &color) {
  return {(float)((color >> 24)&(0x000000ff)) / 255.0,
          (float)((color >> 16)&(0x000000ff)) / 255.0,
          (float)((color >> 8) &(0x000000ff)) / 255.0,
          (float)((color)      &(0x000000ff)) / 255.0};
}
uint32_t color_format_glm_to_int(const glm::vec4 &color) {
  return  (uint32_t)((uint8_t)(color.r * 255.0) << 24) +
          (uint32_t)((uint8_t)(color.g * 255.0) << 16) +
          (uint32_t)((uint8_t)(color.b * 255.0) << 8) +
          (uint32_t)((uint8_t)(color.a * 255.0));
}

glm::vec4 color_format_string_to_glm(const std::string &color) {
  glm::vec4 res = {0, 0, 0, 0};
  uint32_t temp = 0xffffffff;
  auto hd = (char *)strstr(color.c_str(),"#");
  if (hd) {
    if (color.length() == 9) {
    } else if (color.length() == 7){
      auto color_tmp = color + "ff";
      hd = (char *)strstr(color_tmp.c_str(),"#");
    } else {
      return {0, 0, 0, 0};
    }
    if (str_to_hex(hd+1,(unsigned char *)&temp, 8) >= 0) {
        res = color_format_int_to_glm(temp);
    }
  }
  return res;
}

std::string color_format_glm_to_string(const glm::vec4 &color) {
  uint32_t temp = color_format_glm_to_int(color);
  return color_format_int_to_string(temp);
}



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
