/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef LUTMODE_H
#define LUTMODE_H

typedef enum lut_mode {
  LUT_COLOR_E,
  LUT_COLOR_V,
  LUT_GRAY,
  LUT_OFF,
  LUT_LAST
} LUT_MODE;

#endif // LUTMODE_H
