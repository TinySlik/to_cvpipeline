/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/


#include "colorlinebasearrayproberenderer.h"
#include "ParameterServer/parameterserver.h"
#include "func/utils.h"
#include "glm/gtx/transform2.hpp"

const int POSITION = 0;
const int TEXCOORD = 4;

ColorLineBaseArrayProbeRenderer::ColorLineBaseArrayProbeRenderer(ProberContinerProof *mainRender) :
ColorBaseArrayProbeRenderer(mainRender) {
}

void ColorLineBaseArrayProbeRenderer::CreateVBO() {
  m_VBO = _mainRender->CreateBufferObject();
  m_VBOTexture = _mainRender->CreateBufferObject();
  GLfloat vertices[] = { 0.0f, 1.0f, 0.0f,
      0.0f, 0.0f, 0.0f,
      1.0f, 0.0f, 0.0f,
      1.0f, 1.0f, 0.0f };

  GLfloat tcoords[] = {
      1.0f, 1.0f, 0.0f,
      0.0f, 1.0f, 0.0f,
      0.0f, 0.0f, 0.0f,
      1.0f, 0.0f, 0.0f };

  int nsize = sizeof(vertices);
  nsize = sizeof(tcoords);
  glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
  glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  glBindBuffer(GL_ARRAY_BUFFER, m_VBOTexture);
  glBufferData(GL_ARRAY_BUFFER, sizeof(tcoords), tcoords, GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, 0);
}
void ColorLineBaseArrayProbeRenderer::InitVertexArray() {
  glGenVertexArrays(1, &m_VA);
  glBindVertexArray(m_VA);
  glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
  glVertexAttribPointer(POSITION, 3, GL_FLOAT, GL_FALSE, 0, 0);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  glBindBuffer(GL_ARRAY_BUFFER, m_VBOTexture);
  glVertexAttribPointer(TEXCOORD, 3, GL_FLOAT, GL_FALSE, 0, 0);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  glEnableVertexAttribArray(POSITION);
  glEnableVertexAttribArray(TEXCOORD);
  glBindVertexArray(0);
}
bool ColorLineBaseArrayProbeRenderer::initShaders() {
  QFile inputFile(g_backendResource_path() + "glshader/Texture.vs");
  bool bSuccess = inputFile.open(QIODevice::ReadOnly);

  QTextStream tStream(&inputFile);
  QString vsCode = tStream.readAll();
  inputFile.close();

  QFile inputFile2(g_backendResource_path() + "glshader/ColorImage.fs");
  bSuccess &= inputFile2.open(QIODevice::ReadOnly);

  QTextStream tStream2(&inputFile2);
  QString fsCode = tStream2.readAll();
  inputFile2.close();

  _mainRender->getProgramColorLinedEnergy()->addCacheableShaderFromSourceCode(QOpenGLShader::Vertex, vsCode);
  _mainRender->getProgramColorLinedEnergy()->addCacheableShaderFromSourceCode(QOpenGLShader::Fragment, fsCode);
  bSuccess &= _mainRender->getProgramColorLinedEnergy()->link();
  return bSuccess;
}
void ColorLineBaseArrayProbeRenderer::initParams() {
  m_translate_.x = 640;
  m_translate_.y = 0;

  m_scale_.x = 640.0;
  m_scale_.y = 480.0;

  m_rotate_.x = 0;
  m_rotate_.y = 1;
  m_angle_ = 3.14159;
  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = _mainRender->getClassIndex();
  cfg_ctrl.judge_with_create_key(c_name).judge_with_create_key("render").judge_with_create_key("lined_param") = {
    {
      "m_skew_x", m_skew_x_
    },
    {
      "m_skew_y", m_skew_y_
    },
    {
      "m_translate", {
         {"x", m_translate_.x},
         {"y", m_translate_.y},
         {"z", m_translate_.z},
      }
    },
    {
      "m_rotate", {
         {"x", m_rotate_.x},
         {"y", m_rotate_.y},
         {"z", m_rotate_.z},
      }
    },
    {"m_angle",  m_angle_},
    {"blurRadius", m_blurRadius},
    {"sampleNum", m_sampleNum},
    {"bilateral_threshold", m_bilateralThreshold},
    {
      "m_scale", {
         {"x", m_scale_.x},
         {"y", m_scale_.y},
         {"z", m_scale_.z},
      }
    },
  };
  configuru::Config& ctrl_render_lined = cfg_ctrl[c_name.c_str()]["render"]["lined_param"];

  ctrl_render_lined["bilateral_threshold"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_bilateralThreshold = (float)src;
     return true;
  });

  ctrl_render_lined["blurRadius"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_blurRadius = (float)src;
     return true;
  });

  ctrl_render_lined["sampleNum"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_sampleNum = (float)src;
     return true;
  });

  ctrl_render_lined["m_skew_x"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_skew_x_ = (float)src;
     return true;
  });
  ctrl_render_lined["m_skew_y"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_skew_y_ = (float)src;
     return true;
  });
  ctrl_render_lined["m_translate"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_translate_.x = (float)src["x"];
     m_translate_.y = (float)src["y"];
     m_translate_.z = (float)src["z"];
     return true;
  });
  ctrl_render_lined["m_rotate"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_rotate_.x = (float)src["x"];
     m_rotate_.y = (float)src["y"];
     m_rotate_.z = (float)src["z"];
     return true;
  });
  ctrl_render_lined["m_angle"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_angle_ = (float)src;
     return true;
  });
  ctrl_render_lined["m_scale"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_scale_.x = (float)src["x"];
     m_scale_.y = (float)src["y"];
     m_scale_.z = (float)src["z"];
     return true;
  });
  m_winWidth = _mainRender->getWinWidth();
  m_winHeight = _mainRender->getWinHeight();
  initProj();

  cfg_ctrl.judge_with_create_key("fpga_table")["ARGS_B_FACTOR"].add_callback(
      [c_name](configuru::Config &, const configuru::Config &b)->bool{
      auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
      float angle = int(cfg_ctrl["fpga_table"]["ARGS_LINEAR_DEFLECTION_ANGLE"]) - 16;
      float depth = float(b);
      float scale_y = 480.f*(512.f/506.f) * cos(angle / 180.f * 3.14159);
      float scale_x = 480.f*(3.84f / depth);
      configuru::Config tmp_scale = configuru::Config::object({
               {"x", scale_x},
               {"y", scale_y},
               {"z", 0},
            });
      cfg_ctrl[c_name.c_str()]["render"]["lined_param"]["m_scale"] << tmp_scale;
      configuru::Config tmp_translate = configuru::Config::object({
               {"x", (640.f + scale_x)/2.f},
               {"y", 0},
               {"z", 0}
            });
      cfg_ctrl[c_name.c_str()]["render"]["lined_param"]["m_translate"] << tmp_translate;
      return true;
  });

  cfg_ctrl.judge_with_create_key("fpga_table")["ARGS_LINEAR_DEFLECTION_ANGLE"].add_callback(
      [this, c_name](configuru::Config &, const configuru::Config &b)->bool{
      auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
      float angle = int(b) - 16;
      auto depth = (float)(cfg_ctrl["fpga_table"]["ARGS_B_FACTOR"]);
      float scale_y = 480.f*(512.f/506.f) * cos(angle / 180.f * 3.14159);
      float scale_x = 480.f*(3.84f / depth);
      cfg_ctrl[c_name.c_str()]["render"]["lined_param"]["m_skew_y"] << 0.f - (angle/180.f) * 3.14159 * (m_scale_.y/m_scale_.x);
      configuru::Config tmp_scale = configuru::Config::object({
         {"x", scale_x},
         {"y", scale_y},
         {"z", 0},
      });
      cfg_ctrl[c_name.c_str()]["render"]["lined_param"]["m_scale"] << tmp_scale;
      return true;
  });
}
void ColorLineBaseArrayProbeRenderer::RenderImage() {
  auto program = _mainRender->getProgramColorLinedEnergy();
  if (!program->bind())
    return;
  GLuint ProgramName = program->programId();

  glEnable(GL_MULTISAMPLE);
  glEnable(GL_TEXTURE_2D);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, _mainRender->getTextureGLIndex());
  glUniform1i(glGetUniformLocation(ProgramName, "uImage"), 0);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

  glEnable(GL_TEXTURE_1D);
  glActiveTexture(GL_TEXTURE1);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glBindTexture(GL_TEXTURE_1D, _mainRender->getLUTTextureGLIndex());
  glUniform1i(glGetUniformLocation(ProgramName, "imageLUT"), 1);

  program->setUniformValue("minThreshold", _mainRender->getTexMinFilter());
  program->setUniformValue("maxThreshold", _mainRender->getTexMaxFilter());
  program->setUniformValue("mode_pdi", _mainRender->getTexModeDpi());
  program->setUniformValue("mode_reverse", _mainRender->getTexModeRevese());
  program->setUniformValue("blurRadius", m_blurRadius);
  program->setUniformValue("sampleNum", m_sampleNum);
  program->setUniformValue("bilateral_thre", m_bilateralThreshold);

  glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
  glDepthFunc(GL_ALWAYS);

  glm::mat4 mv = TransformImage();
  glm::mat4 mvp = m_Proj*mv;
  mvp = glm::translate(mvp, m_translate_);
  mvp = glm::rotate(mvp, m_angle_, m_rotate_);
  mvp = glm::scale(mvp, m_scale_);
  mvp = glm::shearX3D(mvp, m_skew_x_, 0.f);
  mvp = glm::shearY3D(mvp, m_skew_y_, 0.f);
  const GLfloat* pMVP = glm::value_ptr(mvp);

  GLint UniformMVP = glGetUniformLocation(ProgramName, "MVPMatrix");
  glUniformMatrix4fv(UniformMVP, 1, GL_FALSE, pMVP);

  glBindVertexArray(m_VA);
  glDrawArrays(GL_POLYGON, 0, 4);
  glBindVertexArray(0);

  glActiveTexture(GL_TEXTURE0);
  glDisable(GL_TEXTURE_2D);
  glBindTexture(GL_TEXTURE_2D, 0);
  glDisable(GL_MULTISAMPLE);
  glUseProgram(0);
}

glm::mat4 ColorLineBaseArrayProbeRenderer::TransformImage(){
  glm::mat4 View = glm::translate(glm::mat4(1.0f),glm::vec3(0.0f, 0.0f, 0.0f));
  glm::mat4 Modelscale = glm::scale(glm::mat4(1.0f),	glm::vec3(1.0f, 1.0f, 1.0f));
  Modelscale = glm::scale(Modelscale,	glm::vec3(1.f, 1.f, 1.0f));
  glm::mat4 Model = glm::translate(Modelscale,glm::vec3(0.0f, 0.0f, 0.0f));
  glm::mat4 VM = View * Model;
  return VM;
}
