/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include "tissuelineararrayproberenderer.h"

#include <QGLFunctions>
#include <QtOpenGL>
#include <QGLShaderProgram>
#include <QGLShader>
#include <QVector2D>
#include <QVector3D>
#include "tissuebasearrayproberenderer.h"
#include "ParameterServer/parameterserver.h"
#include "renderutil.h"
#include "func/utils.h"
#include "glm/gtx/transform2.hpp"

const int POSITION = 0;
const int TEXCOORD = 4;

bool TissueLinearArrayProbeRenderer::initShadersTissue() {
  QFile inputFile(g_backendResource_path() + "glshader/Texture.vs");
  bool bSuccess = inputFile.open(QIODevice::ReadOnly);

  QTextStream tStream(&inputFile);
  QString vsCode = tStream.readAll();
  inputFile.close();

  QFile inputFile2(g_backendResource_path() + "glshader/TissueImage.fs");
  bSuccess &= inputFile2.open(QIODevice::ReadOnly);

  QTextStream tStream2(&inputFile2);
  QString fsCode = tStream2.readAll();
  inputFile2.close();

  m_ProgramTissue->addCacheableShaderFromSourceCode(QOpenGLShader::Vertex, vsCode);
  m_ProgramTissue->addCacheableShaderFromSourceCode(QOpenGLShader::Fragment, fsCode);
  bSuccess &= m_ProgramTissue->link();
  return bSuccess;
}

bool TissueLinearArrayProbeRenderer::initRenderer() {
  QFile inputFile(g_backendResource_path() + "glshader/Texture.vs");
  bool bSuccess = inputFile.open(QIODevice::ReadOnly);

  QTextStream tStream(&inputFile);
  QString vsCode = tStream.readAll();
  inputFile.close();

  QFile inputFile2(g_backendResource_path() + "glshader/TissueImage.fs");
  bSuccess &= inputFile2.open(QIODevice::ReadOnly);

  QTextStream tStream2(&inputFile2);
  QString fsCode = tStream2.readAll();
  inputFile2.close();

  m_ProgramTissue->addCacheableShaderFromSourceCode(QOpenGLShader::Vertex, vsCode);
  m_ProgramTissue->addCacheableShaderFromSourceCode(QOpenGLShader::Fragment, fsCode);
  bSuccess &= m_ProgramTissue->link();

  if (!bSuccess)
    return bSuccess;

  CreateVBO();

  _arrayBuf.bind();
  _qgl_in_Tex_Position = m_ProgramTissue->attributeLocation("Position");
  m_ProgramTissue->enableAttributeArray(_qgl_in_Tex_Position);
  m_ProgramTissue->setAttributeBuffer(_qgl_in_Tex_Position, GL_FLOAT, 0, 3, sizeof(QVector3D));
  m_ProgramTissue->disableAttributeArray(_qgl_in_Tex_Position);

  _texCoordBuf.bind();
  _qgl_in_Tex_TexcoordIn = m_ProgramTissue->attributeLocation("TexcoordIn");
  m_ProgramTissue->enableAttributeArray(_qgl_in_Tex_TexcoordIn);
  m_ProgramTissue->setAttributeBuffer(_qgl_in_Tex_TexcoordIn, GL_FLOAT, 0, 3,sizeof (QVector3D));
  m_ProgramTissue->disableAttributeArray(_qgl_in_Tex_TexcoordIn);

  return bSuccess;
}

void TissueLinearArrayProbeRenderer::CreateVBO() {
  _arrayBuf.create();
  _texCoordBuf.create();
//  m_VBO = m_MainRenderer->CreateBufferObject();
//  m_VBOTexture = m_MainRenderer->CreateBufferObject();
  QVector3D vertices[] = {
    QVector3D(0.0f, 1.0f, 0.0f),
    QVector3D(0.0f, 0.0f, 0.0f),
    QVector3D(1.0f, 0.0f, 0.0f),
    QVector3D(1.0f, 1.0f, 0.0f)
  };

//  GLfloat vertices[] = { 0.0f, 1.0f, 0.0f,
//      0.0f, 0.0f, 0.0f,
//      1.0f, 0.0f, 0.0f,
//      1.0f, 1.0f, 0.0f };

  GLfloat tcoords[] = {
      1.0f, 1.0f, 0.0f,
      0.0f, 1.0f, 0.0f,
      0.0f, 0.0f, 0.0f,
      1.0f, 0.0f, 0.0f };

  _arrayBuf.bind();
  _arrayBuf.allocate(vertices, 4 * sizeof(QVector3D));

  _texCoordBuf.bind();
  _texCoordBuf.allocate(tcoords, sizeof(tcoords));

//  glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
//  glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
//  glBindBuffer(GL_ARRAY_BUFFER, 0);

//  glBindBuffer(GL_ARRAY_BUFFER, m_VBOTexture);
//  glBufferData(GL_ARRAY_BUFFER, sizeof(tcoords), tcoords, GL_STATIC_DRAW);
//  glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void TissueLinearArrayProbeRenderer::RenderImage() {
//  glPushAttrib(GL_CURRENT_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, m_MainRenderer->m_TextureTissue);

  SetTexture2DWrapMode(GL_CLAMP, GL_CLAMP);

//  glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

  // Enable depth buffer
  glEnable(GL_DEPTH_TEST);

  glCullFace(GL_FRONT_AND_BACK);

  glDepthFunc(GL_ALWAYS);
  glEnable(GL_MULTISAMPLE);
  GLuint ProgramName = m_ProgramTissue->programId();
  if (!m_ProgramTissue->bind())
    return;
  glm::mat4 mv = m_MainRenderer->TransformImage();
  glm::mat4 mvp = m_MainRenderer->m_Proj*mv;

  mvp = glm::translate(mvp, m_translate_);
  mvp = glm::rotate(mvp, m_angle_, m_rotate_);
  mvp = glm::scale(mvp, m_scale_);
  mvp = glm::shearX3D(mvp, m_skew_x_, 0.f);
  mvp = glm::shearY3D(mvp, m_skew_y_, 0.f);

  const GLfloat* pMVP = glm::value_ptr(mvp);

  m_ProgramTissue->setUniformValue("uImage", 0);
  glEnable(GL_TEXTURE_1D);
  glActiveTexture(GL_TEXTURE1);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glBindTexture(GL_TEXTURE_1D, m_MainRenderer->m_TextureLUT);
  glUniform1i(glGetUniformLocation(ProgramName, "imageLUT"), 1);

  auto color = color_format_int_to_glm(m_color);
  m_ProgramTissue->setUniformValue("color_front",
                                   (GLfloat)(color.r),
                                   (GLfloat)(color.g),
                                   (GLfloat)(color.b),
                                   (GLfloat)(color.a));

  m_ProgramTissue->setUniformValue("blurRadius", m_blurRadius);
  m_ProgramTissue->setUniformValue("sampleNum", m_sampleNum);
  m_ProgramTissue->setUniformValue("bilateral_thre", m_bilateralThreshold);
  m_ProgramTissue->setUniformValue("aspect_ratio", m_filterAspectRatio);
  m_ProgramTissue->setUniformValue("minThreshold", m_minFilter);
  m_ProgramTissue->setUniformValue("maxThreshold", m_magFilter);

  GLint UniformMVP = glGetUniformLocation(ProgramName, "MVPMatrix");
  glUniformMatrix4fv(UniformMVP, 1, GL_FALSE, pMVP);

  m_ProgramTissue->enableAttributeArray(_qgl_in_Tex_Position);
  m_ProgramTissue->enableAttributeArray(_qgl_in_Tex_TexcoordIn);
  glDrawArrays(GL_POLYGON, 0, 4);
  m_ProgramTissue->disableAttributeArray(_qgl_in_Tex_Position);
  m_ProgramTissue->disableAttributeArray(_qgl_in_Tex_TexcoordIn);

  glActiveTexture(GL_TEXTURE0);
  glDisable(GL_TEXTURE_2D);
  glBindTexture(GL_TEXTURE_2D, 0);
  glDisable(GL_MULTISAMPLE);

  m_ProgramTissue->release();

//  glPopAttrib();
}

bool TissueLinearArrayProbeRenderer::initParams() {
  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = m_MainRenderer->getClassIndex();
  m_translate_.x = 640;
  m_translate_.y = 0;
  m_rotate_.x = 0;
  m_rotate_.y = 1.f;
  m_angle_ = 3.14159;
  m_scale_.x = 640.f;
  m_scale_.y = 480.f;

  cfg_ctrl.judge_with_create_key(c_name).judge_with_create_key("lined_param") = {
    {
      "m_translate", {
         {"x", m_translate_.x},
         {"y", m_translate_.y},
         {"z", m_translate_.z},
      }
    },
    {
      "m_skew_x", m_skew_x_
    },
    {
      "m_skew_y", m_skew_y_
    },
    {
      "m_rotate", {
         {"x", m_rotate_.x},
         {"y", m_rotate_.y},
         {"z", m_rotate_.z},
      }
    },
    {"m_angle",  m_angle_},
    {
      "m_scale", {
         {"x", m_scale_.x},
         {"y", m_scale_.y},
         {"z", m_scale_.z},
      }
    },
    {"blurRadius", m_blurRadius},
    {"sampleNum", m_sampleNum},
    {"bilateral_threshold", m_bilateralThreshold},
    {"filter_aspect_ratio", m_filterAspectRatio},
    {"mini_filter", m_minFilter},
    {"max_filter", m_magFilter}
  };

  cfg_ctrl[c_name.c_str()]["lined_param"]["filter_aspect_ratio"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_filterAspectRatio = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["lined_param"]["mini_filter"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_minFilter = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["lined_param"]["max_filter"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_magFilter = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["lined_param"]["bilateral_threshold"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_bilateralThreshold = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["lined_param"]["blurRadius"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_blurRadius = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["lined_param"]["sampleNum"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_sampleNum = (float)src;
     return true;
  });

  cfg_ctrl[c_name.c_str()]["lined_param"]["m_skew_x"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_skew_x_ = (float)src;
     return true;
  });
  cfg_ctrl[c_name.c_str()]["lined_param"]["m_skew_y"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_skew_y_ = (float)src;
     return true;
  });
  cfg_ctrl[c_name.c_str()]["lined_param"]["m_translate"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_translate_.x = (float)src["x"];
     m_translate_.y = (float)src["y"];
     m_translate_.z = (float)src["z"];
     return true;
  });
  cfg_ctrl[c_name.c_str()]["lined_param"]["m_rotate"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_rotate_.x = (float)src["x"];
     m_rotate_.y = (float)src["y"];
     m_rotate_.z = (float)src["z"];
     return true;
  });
  cfg_ctrl[c_name.c_str()]["lined_param"]["m_angle"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_angle_ = (float)src;
     return true;
  });
  cfg_ctrl[c_name.c_str()]["lined_param"]["m_scale"].add_callback([this](configuru::Config &, const configuru::Config &src)->bool {
     m_scale_.x = (float)src["x"];
     m_scale_.y = (float)src["y"];
     m_scale_.z = (float)src["z"];
     return true;
  });

  cfg_ctrl.judge_with_create_key("fpga_table")["ARGS_B_FACTOR"].add_callback(
      [c_name](configuru::Config &, const configuru::Config &b)->bool{
      auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
      float angle = int(cfg_ctrl["fpga_table"]["ARGS_LINEAR_DEFLECTION_ANGLE"]) - 16;
      float depth = float(b);
      float scale_y = 480.f*(512.f/506.f) * cos(angle / 180.f * 3.14159);
      float scale_x = 480.f*(3.84f / depth);
      cfg_ctrl[c_name.c_str()]["lined_param"]["m_skew_y"] << 0.f - (angle/180.f) * 3.14159 * (scale_y/scale_x);
      configuru::Config tmp_scale = configuru::Config::object({
               {"x", scale_x},
               {"y", scale_y},
               {"z", 0},
            });
      cfg_ctrl[c_name.c_str()]["lined_param"]["m_scale"] << tmp_scale;
      configuru::Config tmp_translate = configuru::Config::object({
               {"x", (640.f + scale_x)/2.f},
               {"y", 0},
               {"z", 0}
            });
      cfg_ctrl[c_name.c_str()]["lined_param"]["m_translate"] << tmp_translate;
      return true;
  });

  cfg_ctrl.judge_with_create_key("fpga_table")["ARGS_LINEAR_DEFLECTION_ANGLE"].add_callback(
      [this, c_name](configuru::Config &, const configuru::Config &b)->bool{
      auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
      float angle = int(b) - 16;

#if 1 // tinyoh add for utrolsound device c mode logic bug. 20-11-2
      auto mode = (int)(cfg_ctrl["fpga_table"]["ARGS_C"]);
      if (mode == 1) {
        angle = 0;
      }
#endif

      auto depth = (float)(cfg_ctrl["fpga_table"]["ARGS_B_FACTOR"]);
      float scale_y = 480.f*(512.f/506.f) * cos(angle / 180.f * 3.14159);
      float scale_x = 480.f*(3.84f / depth);
      cfg_ctrl[c_name.c_str()]["lined_param"]["m_skew_y"] << 0.f - (angle/180.f) * 3.14159 * (m_scale_.y/m_scale_.x);
      configuru::Config tmp_scale = configuru::Config::object({
         {"x", scale_x},
         {"y", scale_y},
         {"z", 0},
      });
      cfg_ctrl[c_name.c_str()]["lined_param"]["m_scale"] << tmp_scale;
      return true;
  });

  return true;
}

bool TissueLinearArrayProbeRenderer::InitResources(GLubyte* Tess, GLubyte* color) {
  bool bSuccess = true;
  m_frameData.NumDisplayCols_Tissue = 256; //real cols in frame data
  m_frameData.NumDisplayRows_Tissue = 512; //real rows in frame data
  m_frameData.ImageWidth_Tissue = 800;   //Image width for display
  m_frameData.ImageHeight_Tissue = 800; //Image height for display

  m_frameData.NumDisplayCols_Color = 192;
  m_frameData.NumDisplayRows_Color = 724;
  m_frameData.ImageWidth_Color = 724;
  m_frameData.ImageHeight_Color = 192;

  m_frameData.Max_display_cols = 512;       //max cols in frame data
  m_frameData.Max_display_rows = 1024;       //max row in frame data

  //Curve probe
  m_frameData.Radius = 1.0;
  m_frameData.EndDepth_Tissue = 0.15f;    //ABUS-->End depth; Others--> Start depth
  m_frameData.ArcAngle_Tissue = 3.14f;    //Field angle
  m_frameData.ArcLength_Tissue = 120.f;
  m_frameData.ScanDepth_Tissue = 120.f;

  m_frameData.EndDepth_Color = 0;
  m_frameData.ArcAngle_Color = 0;
  m_frameData.ImageOffsetX_Color = 0;
  m_frameData.ImageOffsetY_Color = 0;
  m_frameData.NumReceiveBeams_Color = 0;
  m_frameData.NumReconRows_Color = 0;
  //Frame data
  m_frameData.ImageFrame_Tissue = (GLubyte*)Tess;
  m_frameData.ImageFrame_ColorV = (GLubyte*)color;
  m_frameData.ImageFrame_ColorE = (GLubyte*)color;

  // Tissue display
  {
    const float maxWidth = (float)(m_MainRenderer->m_iWidth - 100);
    const float maxHeight = (float)(m_MainRenderer->m_iHeight - 100);

    m_MainRenderer->m_fWidthImageB = GLfloat(m_frameData.ImageWidth_Tissue);
    m_MainRenderer->m_fHeightImageB = GLfloat(m_frameData.ImageHeight_Tissue);

    float fScaleX = maxWidth / m_MainRenderer->m_fWidthImageB;
    float fScaleY = maxHeight / m_MainRenderer->m_fHeightImageB;
    m_MainRenderer->m_fScale = qMin(fScaleX, fScaleY) * 1.0f;
    m_MainRenderer->m_fTransY = GLfloat(m_MainRenderer->m_iHeight) - m_MainRenderer->m_fHeightImageB*m_MainRenderer->m_fScale - m_MainRenderer->m_fMarginTop;

    int nWidth = m_frameData.Max_display_cols;
    int nHeight = m_frameData.Max_display_rows;
    m_MainRenderer->m_PBOUS = m_MainRenderer->CreateBufferObject();
    glBindBuffer(GL_PIXEL_PACK_BUFFER, m_MainRenderer->m_PBOUS);
    glBufferData(GL_PIXEL_PACK_BUFFER, nWidth*nHeight * sizeof(GLubyte), 0,GL_DYNAMIC_COPY);
    glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
    m_MainRenderer->m_TextureTissue = m_MainRenderer->CreateTextureObject2D();
    bSuccess &= m_MainRenderer->InitTextureUI(m_frameData.NumDisplayRows_Tissue, m_frameData.NumDisplayCols_Tissue);
  }

  m_MainRenderer->m_bInitialized = true;
  m_MainRenderer->m_bVelocityMode = true;
  return bSuccess;
}

