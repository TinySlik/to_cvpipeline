/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include <QGLFunctions>
#include <QtOpenGL>
#include <QGLShaderProgram>
#include <QGLShader>
#include <QtGui>
#include <QTimer>
#include <fstream>
#include <iostream>
#include <mutex>
#include <sstream>
#include "colorbaseultrasoundrenderer.h"
#include "func/utils.h"
#include "ParameterServer/parameterserver.h"
#include "renderutil.h"
#include "colorbasearrayproberenderer.h"
#include "colorconvexbasearrayproberenderer.h"
#include "colorlinebasearrayproberenderer.h"

const int POSITION = 0;
const int TEXCOORD = 4;
const float DEFAULT_MIN_FILTER = 5.f;
const float DEFAULT_MAX_FILTER = 255.f;

ColorUltrasoundRenderer::ColorUltrasoundRenderer():
_enable_render(false),
m_ProgramColorCorvedEnergy(NULL),
m_ProgramColorLinedEnergy(NULL),
m_bInitialized(false),
m_minFilter(DEFAULT_MIN_FILTER),
m_magFilter(DEFAULT_MAX_FILTER),
m_mode_dpi(false),
m_mode_reverse(false),
_updateLUTtag(false),
m_lut_mode(LUT_COLOR_V),
_hiden_lut(true),
m_backGroundColor(0x00000000),
m_ConvexArrayProbeRenderer(std::make_shared<ColorConvexBaseArrayProbeRenderer>(this)),
m_LinearArrayProbeRenderer(std::make_shared<ColorLineBaseArrayProbeRenderer>(this)),
m_CurrentArrayProbeRenderer(m_ConvexArrayProbeRenderer) {}

ColorUltrasoundRenderer::~ColorUltrasoundRenderer() {}

void ColorUltrasoundRenderer::render() {
  if ((!_data_enable) || (!_enable_render)) return;
  glClearColor((float)((m_backGroundColor >> 24)&(0x000000ff)) / 255.0,
               (float)((m_backGroundColor >> 16)&(0x000000ff)) / 255.0,
               (float)((m_backGroundColor >> 8) &(0x000000ff)) / 255.0,
               (float)((m_backGroundColor)      &(0x000000ff)) / 255.0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  paintGL();
}

std::string ColorUltrasoundRenderer::getClassIndex() {
  return class_index_name_;
}

void ColorUltrasoundRenderer::initParams() {
  m_iTexWidth = 256;
  m_iTexHeight = 512;
  m_iWidth = 640;
  m_iHeight = 480;

  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = getClassIndex();
  cfg_ctrl.judge_with_create_key(c_name)["render"] = {
    {"background", color_format_int_to_string(m_backGroundColor).c_str()},
    {"mini_filter", m_minFilter},
    {"max_filter", m_magFilter},
    {"mode_pdi", bool(m_mode_dpi)},
    {"mode_reverse", bool(m_mode_reverse)},
    {"lut", {
        {"hiden_lut", _hiden_lut},
        {"mode", "v"},
        {"color_list_v",  configuru::Config::array({
                                              color_format_int_to_string(0x3cffff00 + int(0.00f*(255))).c_str(),
                                              color_format_int_to_string(0x00ffff00 + int(0.45f*(255))).c_str(),
                                              color_format_int_to_string(0x00ff0000 + int(0.495f*(255))).c_str(),
                                              color_format_int_to_string(0xf0ff0000 + int(0.505f*(255))).c_str(),
                                              color_format_int_to_string(0xf0ffff00 + int(0.55f*(255))).c_str(),
                                              color_format_int_to_string(0xb4ffff00 + int(1.00f*(255))).c_str()
                                            })},
        {"color_list_e",  configuru::Config::array({
                                              color_format_int_to_string(0x02ff5000 + int(0.00f*(255))).c_str(),
                                              color_format_int_to_string(0x0dffb200 + int(0.09f*(255))).c_str(),
                                              color_format_int_to_string(0x15ffde00 + int(0.18f*(255))).c_str(),
                                              color_format_int_to_string(0x1efff100 + int(0.27f*(255))).c_str(),
                                              color_format_int_to_string(0x25fff200 + int(0.36f*(255))).c_str(),
                                              color_format_int_to_string(0x2bffff00 + int(0.45f*(255))).c_str(),
                                              color_format_int_to_string(0x2fffff00 + int(0.54f*(255))).c_str(),
                                              color_format_int_to_string(0x34ffff00 + int(0.63f*(255))).c_str(),
                                              color_format_int_to_string(0x37ffff00 + int(0.72f*(255))).c_str(),
                                              color_format_int_to_string(0x38ffff00 + int(0.81f*(255))).c_str(),
                                              color_format_int_to_string(0x3affff00 + int(0.90f*(255))).c_str(),
                                              color_format_int_to_string(0x3cffff00 + int(1.f  *(255))).c_str(),
                                          })}
      }
    },
    {"static_img_debug", "null"}
  };
  configuru::Config &render_cfg = cfg_ctrl[c_name.c_str()]["render"];
  render_cfg["mode_pdi"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    m_mode_dpi = bool(b);
    return true;
  });
  render_cfg["mode_reverse"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    m_mode_reverse = bool(b);
    return true;
  });
  render_cfg["mini_filter"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    m_minFilter = float(b);
    return true;
  });
  render_cfg["max_filter"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    m_magFilter = float(b);
    return true;
  });
  render_cfg["background"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    if (!b.is_string()) return false;
    std::string color_string = (std::string)b;
    m_backGroundColor = color_format_string_to_int(color_string);
    return true;
  });

  render_cfg["lut"]["hiden_lut"].set_hiden(true);
  render_cfg["lut"]["hiden_lut"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    _hiden_lut = (bool)b;
    return true;
  });

  render_cfg["lut"]["mode"].add_callback([this](configuru::Config &a, const configuru::Config &b)->bool{
    if (!b.is_string()) return false;
    auto str = (std::string)b;
    if (str == "v") {
      m_lut_mode = LUT_COLOR_V;
      _updateLUTtag = true;
      return true;
    } else if (str == "e") {
      m_lut_mode = LUT_COLOR_E;
      _updateLUTtag = true;
      return true;
    } else {
      m_lut_mode = LUT_OFF;
      a = "off";
      return false;
    }
    return true;
  });

  auto covert_color_to_list_ = [](const configuru::Config &in, QList<QColor> &color_list) -> bool {
      if(!in.is_array()) return false;
      color_list.clear();
      for (size_t i = 0; i< in.array_size();i++) {
        if(in[i].is_string()) {
          std::string color_string = (std::string)in[i];
          auto color = color_format_string_to_glm(color_string);
          color_list << QColor::fromRgb(color.r * 255, color.g * 255, color.b * 255, color.a * 255);
        } else if(in[i].is_array()) {
          if (in[i].array_size() == 3 && in.array_size() == 256) {
            color_list << QColor::fromRgb((int)(in[i][0]), (int)(in[i][1]), (int)(in[i][2]), i);
          } else if (in[i].array_size() == 4) {
            color_list << QColor::fromRgb((int)(in[i][0]), (int)(in[i][1]), (int)(in[i][2]), (int)(in[i][3]));
          } else {
            return false;
          }
        } else {
          return false;
        }
      }
      return true;
    };
  covert_color_to_list_(render_cfg["lut"]["color_list_v"], m_colorListV);
  covert_color_to_list_(render_cfg["lut"]["color_list_e"], m_colorListE);
  render_cfg["lut"]["color_list_v"].add_callback(
      [this, covert_color_to_list_](configuru::Config &, const configuru::Config &b)->bool {
    bool res = covert_color_to_list_(b, m_colorListV);
    if (res)
      _updateLUTtag = true;
    return res;
  });
  render_cfg["lut"]["color_list_e"].add_callback(
      [this, covert_color_to_list_](configuru::Config &, const configuru::Config &b)->bool{
    bool res = covert_color_to_list_(b, m_colorListE);

    if (res)
      _updateLUTtag = true;
    return res;
  });

  if (m_CurrentArrayProbeRenderer == m_ConvexArrayProbeRenderer) {
    cfg_ctrl[c_name.c_str()]["probe"] = "curved";
  } else {
    cfg_ctrl[c_name.c_str()]["probe"] = "lined";
  }
  cfg_ctrl[c_name.c_str()]["probe"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    if (b == "lined") {
      m_CurrentArrayProbeRenderer = m_LinearArrayProbeRenderer;
      return true;
    } else if (b == "curved") {
      m_CurrentArrayProbeRenderer = m_ConvexArrayProbeRenderer;
      return true;
    }
    return false;
  });
  if (!cfg_ctrl.judge_with_create_key("dev_sync_tag").has_key("dev_probe")) {
    cfg_ctrl["dev_sync_tag"]["dev_probe"] = 1;
  }
  cfg_ctrl["dev_sync_tag"]["dev_probe"].add_callback(
      [c_name](configuru::Config &, const configuru::Config &b)->bool{
    auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
    if ((int)b == 1) {
      cfg_ctrl[c_name.c_str()]["probe"] << "lined";
    } else if ((int)b == 2) {
      cfg_ctrl[c_name.c_str()]["probe"] << "curved";
    } else {
      std::cout << "probe type " << b << " has not been defined." << std::endl;
      std::cout.flush();
    }
    return true;
  });

  if (cfg_ctrl[c_name.c_str()].has_key("visible")) {
    cfg_ctrl[c_name.c_str()]["visible"].add_callback(
        [this](configuru::Config &, const configuru::Config &b)->bool{
        _enable_render = (bool)b;
      return true;
    });
  }
  cfg_ctrl["fpga_table"]["ARGS_C"].add_callback(
        [this](configuru::Config &, const configuru::Config &b)->bool{
        auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
        auto c_name = getClassIndex();
        if(int(b) == 1) {
          cfg_ctrl[c_name.c_str()]["visible"] << true;
        } else if (int(b) == 0){
          cfg_ctrl[c_name.c_str()]["visible"] << false;
        } else {
          return false;
        }
        return true;
    });

  render_cfg["static_img_debug"].set_hiden(true);
  render_cfg["static_img_debug"].add_callback([this, c_name](configuru::Config &, const configuru::Config &b)->bool{
    if (!b.is_string()) return false;
    auto str_path = (std::string)b;

    std::ifstream fRec;
    fRec.open(str_path, std::ofstream::binary | std::ios::in);
    std::cout << "debug_bin_path:" << str_path << std::endl;
    if (!fRec) {
      std::cout << "open failed!" << std::endl;
      _enable_render = false;
      _data_enable = false;
      return false;
    }
    std::cout << "open success!"
              << std::endl
              << "read: "
              << m_iTexWidth
              << " * "
              << m_iTexHeight
              << " * "
              << 1
              << " data."
              << std::endl;
    std::cout.flush();
    m_mtxPaint.lock();
    qDebug() <<  "local buf size: "<< _data.size();
    fRec.read((char *)(_data.data()), m_iTexWidth * m_iTexHeight * 1);
#if 1
    uchar * cur = (uchar *)_data.data();
    for(size_t i = 0; i < 256; i++) {
      memset(cur + 506, 0, 6);
      cur += 512;
    }
#endif
    fRec.close();
    m_mtxPaint.unlock();
    _enable_render = true;
    _data_enable = true;
    auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
    configuru::Config &render_cfg = cfg_ctrl[c_name.c_str()]["render"];
    render_cfg["lut"]["hiden_lut"] << false;
    return true;
  });
}

void ColorUltrasoundRenderer::initialize(const std::string &class_index_) {
  class_index_name_ = class_index_;
  initParams();
  initializeOpenGLFunctions();
  bool bSuccess = initLUT();

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );

  m_mtxPaint.lock();
  _data.clear();
  _data.resize(m_iTexWidth * m_iTexHeight * 1);
  memset(_data.data(), 0, m_iTexWidth * m_iTexHeight * 1);
  m_mtxPaint.unlock();
  resizeGL(m_iWidth, m_iHeight);
  bSuccess &= m_ConvexArrayProbeRenderer->Init();
  bSuccess &= m_LinearArrayProbeRenderer->Init();
  glEnable(GL_TEXTURE_2D);
  glGenTextures(1, &m_Texture);
  bSuccess &= InitTextureUI(m_iTexHeight, m_iTexWidth);

  m_bInitialized = bSuccess;
  if (m_bInitialized) {
    qDebug() << __FUNCTION__ << "InitResources success";
  }
}

void ColorUltrasoundRenderer::paintGL() {
  if (!m_bInitialized)
    return;
  if (_updateLUTtag)
      updateTextureColorLUT(256);
  UpdateDisplay();

  glEnable(GL_DEPTH_TEST);
  if (m_CurrentArrayProbeRenderer)
      m_CurrentArrayProbeRenderer->Render();
  switch (m_lut_mode) {
    case LUT_COLOR_E:
    case LUT_COLOR_V:
      RenderColorLUT();
      break;
    case LUT_GRAY:
    case LUT_OFF:
    case LUT_LAST:
    default:
      break;
  }
}

void ColorUltrasoundRenderer::resizeGL(int nwidth, int nheight) {
  m_iHeight = nheight;
  m_iWidth = nwidth;
  // orthographic view
  m_ProjLUT = glm::ortho(0.0, GLdouble(nwidth), 0.0, GLdouble(nheight), -100.0, +100.0);

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(0.0, GLdouble(nwidth), 0.0, GLdouble(nheight), -100.0, +100.0);
}

bool ColorUltrasoundRenderer::onRecvPipelineData(char *data) {
  bool bSuccess = true;
  m_mtxPaint.lock();
#if 0
  qDebug() << __FUNCTION__ << getWidth();
  qDebug() << __FUNCTION__ << getHeight();
  qDebug() << __FUNCTION__ << getBPP();
  qDebug() << __FUNCTION__ << getPixealFormat().c_str();
  qDebug() << __FUNCTION__ << getCurrentTimeStamp(data - getHeadSize());
#endif
  char *current_dst = (char *)_data.data();
  char *current_src = data;
  for(size_t i = 0; i < m_iTexWidth; i++) {
    memcpy(current_dst, current_src, 506);
    current_dst += m_iTexHeight;
    current_src += 506;
  }

  m_mtxPaint.unlock();
  QTime current_time =QTime::currentTime();
  static int second = current_time.second();
  static int fps = 0;
  static int fps_a = 0;
  fps_a++;
  if (current_time.second() != second) {
    fps = fps_a;
    fps_a = 0;
    auto cfg = ParameterServer::instance()->GetCfgRoot();
    cfg.judge_with_create_key("dev_status")["c_mode_fps"] = fps;
  }
  second = current_time.second();
  return bSuccess;
}

void ColorUltrasoundRenderer::onDataHeadInfoChange(unsigned char *) {
  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = getClassIndex();
  cfg_ctrl[c_name.c_str()]["width"] = getWidth();
  cfg_ctrl[c_name.c_str()]["height"] = getHeight();
  cfg_ctrl[c_name.c_str()]["bpp"] = getBPP();
  cfg_ctrl[c_name.c_str()]["format"] = getPixealFormat().c_str();
#if 1
  m_mtxPaint.lock();
  _data.clear();
  _data.resize((256/2) * 512 * 1);
  m_iTexWidth = (256/2);
  m_iTexHeight = 512;
  m_mtxPaint.unlock();
#endif
  _data_enable = (getWidth() == 256 && getHeight() == 506);
}

bool ColorUltrasoundRenderer::InitTextureUI(const int& nWidth, const int& nHeight) {
  bool bSuccess = true;
  glBindTexture(GL_TEXTURE_2D, m_Texture);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
  glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
  glTexImage2D(GL_TEXTURE_2D,
      0,                        // GLint  	   level
      GL_R8UI,                  // internal    format
      nWidth,                   // GLsizei  	width,
      nHeight,                  // GLsizei  	height,
      0,                        // GLint  	   border,
      GL_RED_INTEGER,           // GLenum  	   format,
      GL_UNSIGNED_BYTE,        // data type
      (const GLvoid*)_data.data());       // texels
  if (glGetError() == GL_INVALID_ENUM ||
      glGetError() == GL_INVALID_VALUE ||
      glGetError() == GL_INVALID_OPERATION)
      bSuccess = false;

  glBindTexture(GL_TEXTURE_2D, 0);
  return bSuccess;
}

GLuint ColorUltrasoundRenderer::CreateBufferObject() {
  GLuint uiBufferObject = 0;
  glGenBuffers(1, &uiBufferObject);
  return uiBufferObject;
}

void ColorUltrasoundRenderer::UpdateDisplay() {
  glBindTexture(GL_TEXTURE_2D, m_Texture);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
  m_mtxPaint.lock();
  glTexImage2D(GL_TEXTURE_2D,
      0,
      GL_R8UI,
      m_iTexHeight,
      m_iTexWidth,
      0,
      GL_RED_INTEGER,
      GL_UNSIGNED_BYTE,
      (const GLvoid*)_data.data());
  glBindTexture(GL_TEXTURE_2D, 0);
  m_mtxPaint.unlock();
  return;
}

void ColorUltrasoundRenderer::createVBOLUT() {
  m_VBO_LUT = CreateBufferObject();
  m_VBOTextureLUT = CreateBufferObject();
  GLfloat vertices[] = { 0.0f, 1.0f, 0.0f,
      0.0f, 0.0f, 0.0f,
      1.0f, 0.0f, 0.0f,
      1.0f, 1.0f, 0.0f };

  GLfloat tcoords[] = { 0.0f, 1.0f, 0.0f,
      0.0f, 0.0f, 0.0f,
      1.0f, 0.0f, 0.0f,
      1.0f, 1.0f, 0.0f };

  int nsize = sizeof(vertices);
  nsize = sizeof(tcoords);
  glBindBuffer(GL_ARRAY_BUFFER, m_VBO_LUT);
  glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  glBindBuffer(GL_ARRAY_BUFFER, m_VBOTextureLUT);
  glBufferData(GL_ARRAY_BUFFER, sizeof(tcoords), tcoords, GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void ColorUltrasoundRenderer::initVAOLUT() {
  glGenVertexArrays(1, &m_VA_LUT);
  glBindVertexArray(m_VA_LUT);
  glBindBuffer(GL_ARRAY_BUFFER, m_VBO_LUT);
  glVertexAttribPointer(POSITION, 3, GL_FLOAT, GL_FALSE, 0, 0);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  glBindBuffer(GL_ARRAY_BUFFER, m_VBOTextureLUT);
  glVertexAttribPointer(TEXCOORD, 3, GL_FLOAT, GL_FALSE, 0, 0);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  glEnableVertexAttribArray(POSITION);
  glEnableVertexAttribArray(TEXCOORD);
  glBindVertexArray(0);
}

bool ColorUltrasoundRenderer::initShadersLUT() {
  QFile inputFile(g_backendResource_path() + "glshader/ColorLUT2D.vs");
  bool bSuccess = inputFile.open(QIODevice::ReadOnly);

  QTextStream tStream(&inputFile);
  QString vsCode = tStream.readAll();
  inputFile.close();

  QFile inputFile2(g_backendResource_path() + "glshader/ColorLUT2D.fs");
  bSuccess &= inputFile2.open(QIODevice::ReadOnly);

  QTextStream tStream2(&inputFile2);
  QString fsCode = tStream2.readAll();
  inputFile2.close();

  m_ProgramLUT.addCacheableShaderFromSourceCode(QOpenGLShader::Vertex, vsCode);
  m_ProgramLUT.addCacheableShaderFromSourceCode(QOpenGLShader::Fragment, fsCode);
  bSuccess &= m_ProgramLUT.link();

  return bSuccess;
}

bool ColorUltrasoundRenderer::fillTextureColorLUT(GLuint texture, const GLubyte* pData, const GLint& nElement) {
  bool bSuccess = true;

  glEnable(GL_TEXTURE_1D);
  glBindTexture(GL_TEXTURE_1D, texture);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexImage1D(GL_TEXTURE_1D,
      0,                    // GLint  	   level
      GL_RGB8,              // internal    format
      nElement,             // GLsizei  	number of texels,
      0,                    // GLint  	   border,
      GL_RGB,               // GLenum  	   format,
      GL_UNSIGNED_BYTE,     // data type
      pData);               // texels

  if (glGetError() == GL_INVALID_ENUM ||
      glGetError() == GL_INVALID_VALUE ||
      glGetError() == GL_INVALID_OPERATION)
      bSuccess = false;

  glDisable(GL_TEXTURE_1D);
  glBindTexture(GL_TEXTURE_1D, 0);
  return bSuccess;
}

void ColorUltrasoundRenderer::interpolate(GLubyte* pMap,const QList<QColor>& cList) {
  for (int k = 0; k < cList.count() - 1; k++) {
    QColor c1 = cList[k];
    QColor c2 = cList[k + 1];
    int iBegin = c1.alpha();
    int iEnd = c2.alpha();
    float interpolator = 1.0f / GLfloat(iEnd - iBegin);
    glm::ivec3 temp = glm::ivec3(0);
    for (int i = iBegin; i <= iEnd; i++) {
#if 0 // HSVmode
      temp[0] = GLint((c2.hue() - c1.hue())*GLfloat(i - iBegin)*interpolator + c1.hue());
      temp[1] = GLint((c2.saturation() - c1.saturation())*GLfloat(i - iBegin)*interpolator + c1.saturation());
      temp[2] = GLint((c2.value() - c1.value())*GLfloat(i - iBegin)*interpolator + c1.value());
      QColor c = QColor::fromHsv(temp[0], temp[1], temp[2]);
#else // RGBmode
      temp[0] = GLint((c2.red() - c1.red())*GLfloat(i - iBegin)*interpolator + c1.red());
      temp[1] = GLint((c2.green() - c1.green())*GLfloat(i - iBegin)*interpolator + c1.green());
      temp[2] = GLint((c2.blue() - c1.blue())*GLfloat(i - iBegin)*interpolator + c1.blue());
      QColor c = QColor::fromRgb(temp[0], temp[1], temp[2]);
#endif
      pMap[i * 3 + 0] = GLubyte(c.red());
      pMap[i * 3 + 1] = GLubyte(c.green());
      pMap[i * 3 + 2] = GLubyte(c.blue());
    }
  }
}

bool ColorUltrasoundRenderer::updateTextureColorLUT(const int& nElement) {
  bool bSuccess = true;
  GLubyte* pColorMap = new GLubyte[3 * nElement];
  switch (m_lut_mode) {
    case LUT_COLOR_E:
      interpolate(pColorMap, m_colorListE);
      bSuccess = fillTextureColorLUT(m_TextureLUT, pColorMap, nElement);
      break;
    case LUT_COLOR_V:
      interpolate(pColorMap, m_colorListV);
      bSuccess = fillTextureColorLUT(m_TextureLUT, pColorMap, nElement);
      break;
    case LUT_GRAY:
    case LUT_OFF:
    case LUT_LAST:
    default:
      break;
  }

  delete[] pColorMap;
  _updateLUTtag = false;
  return bSuccess;
}

glm::mat4 ColorUltrasoundRenderer::TransformColorLUT() {
  GLfloat legendWidth = 20.0f;
  GLfloat legendHeight = m_iHeight - 2 * 10.0f;
  //GLfloat offsetX = GLfloat(m_iWidth) - legendWidth - 50.0f;
  GLfloat offsetX = GLfloat(m_iWidth) - legendWidth - 10.0f;
  GLfloat offsetY = (GLfloat(m_iHeight) - legendHeight) / 2.0f;
  glm::mat4 View = glm::translate(glm::mat4(1.0f), glm::vec3(offsetX, offsetY, 0.0f));
  glm::mat4 Model = glm::scale(glm::mat4(1.0f), glm::vec3(legendWidth, legendHeight, 1.0f));

  glm::mat4 VM = View * Model;
  return VM;
}

void ColorUltrasoundRenderer::RenderColorLUT() {
  if (!m_ProgramLUT.bind())
      return;

  glm::mat4 mv = TransformColorLUT();
  glm::mat4 mvp = m_ProjLUT*mv;
  const GLfloat* pMVP = glm::value_ptr(mvp);

  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_1D, m_TextureLUT);
  m_ProgramLUT.setUniformValue("colorLUT", 0);
  GLuint ProgramName = m_ProgramLUT.programId();
  GLint UniformMVP = glGetUniformLocation(ProgramName, "MVPMatrix");
  glUniformMatrix4fv(UniformMVP, 1, GL_FALSE, pMVP);

  glBindVertexArray(m_VA_LUT);
  if (!_hiden_lut) {
    glDrawArrays(GL_POLYGON, 0, 4);
  }
  glBindVertexArray(0);

  glDisable(GL_TEXTURE_1D);
  glBindTexture(GL_TEXTURE_1D, 0);

  glUseProgram(0);
}

bool ColorUltrasoundRenderer::initLUT() {
  initShadersLUT();
  createVBOLUT();
  initVAOLUT();
  glEnable(GL_TEXTURE_1D);
  glGenTextures(1, &m_TextureLUT);
  return updateTextureColorLUT(256);
}
