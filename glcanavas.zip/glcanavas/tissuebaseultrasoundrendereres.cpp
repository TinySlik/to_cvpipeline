#include "tissuebaseultrasoundrendereres.h"
#include "func/utils.h"

TissueBaseUltrasoundRendererES::TissueBaseUltrasoundRendererES():
  geometries(0),
  texture(0),
  angularSpeed(0)
{

}

TissueBaseUltrasoundRendererES::~TissueBaseUltrasoundRendererES()
{
    delete texture;
    delete geometries;
}


void TissueBaseUltrasoundRendererES::initializeGL()
{
    initializeOpenGLFunctions();

    glClearColor(0, 0, 0, 1);

    initShaders();
    initTextures();

//! [2]
    // Enable depth buffer
    glEnable(GL_DEPTH_TEST);

    // Enable back face culling
    glEnable(GL_CULL_FACE);
//! [2]

    geometries = new GeometryEngine;
}

//! [3]
void TissueBaseUltrasoundRendererES::initShaders()
{
  QFile inputFile(g_pipeline_cfg_path() + "glshader/vshader.glsl");
  bool bSuccess = inputFile.open(QIODevice::ReadOnly);

  QTextStream tStream(&inputFile);
  QString vsCode = tStream.readAll();
  inputFile.close();

  QFile inputFile2(g_pipeline_cfg_path() + "glshader/fshader.glsl");
  bSuccess &= inputFile2.open(QIODevice::ReadOnly);

  QTextStream tStream2(&inputFile2);
  QString fsCode = tStream2.readAll();
  inputFile2.close();

  program.addCacheableShaderFromSourceCode(QOpenGLShader::Vertex, vsCode);
  program.addCacheableShaderFromSourceCode(QOpenGLShader::Fragment, fsCode);
  bSuccess &= program.link();
//    // Compile vertex shader
//    if (!program.addShaderFromSourceFile(QOpenGLShader::Vertex, g_pipeline_cfg_path() + "glshader/vshader.glsl"))
//        return;

//    // Compile fragment shader
//    if (!program.addShaderFromSourceFile(QOpenGLShader::Fragment, g_pipeline_cfg_path() + "glshader/fshader.glsl"))
//        return;

//    // Link shader pipeline
//    if (!program.link())
//        return;

    // Bind shader pipeline for use
    if (!program.bind())
        return;
}
//! [3]

//! [4]
void TissueBaseUltrasoundRendererES::initTextures()
{
    // Load cube.png image
    texture = new QOpenGLTexture(QImage(g_pipeline_cfg_path() + "cube.png").mirrored());

    // Set nearest filtering mode for texture minification
    texture->setMinificationFilter(QOpenGLTexture::Nearest);

    // Set bilinear filtering mode for texture magnification
    texture->setMagnificationFilter(QOpenGLTexture::Linear);

    // Wrap texture coordinates by repeating
    // f.ex. texture coordinate (1.1, 1.2) is same as (0.1, 0.2)
    texture->setWrapMode(QOpenGLTexture::Repeat);
}
//! [4]

//! [5]
void TissueBaseUltrasoundRendererES::resizeGL(int w, int h)
{
    // Calculate aspect ratio
    qreal aspect = qreal(w) / qreal(h ? h : 1);

    // Set near plane to 3.0, far plane to 7.0, field of view 45 degrees
    const qreal zNear = 3.0, zFar = 7.0, fov = 45.0;

    // Reset projection
    projection.setToIdentity();

    // Set perspective projection
    projection.perspective(fov, aspect, zNear, zFar);
//    projection.ortho(0.0, GLdouble(w), 0.0, GLdouble(h), -100.0, +100.0);
}
//! [5]

void TissueBaseUltrasoundRendererES::paintGL()
{
    // Clear color and depth buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    texture->bind();

//! [6]
    // Calculate model view transformation
    QMatrix4x4 matrix;
    matrix.translate(0.0, 0.0, -5.0);
    matrix.rotate(rotation);

    // Set modelview-projection matrix
    program.setUniformValue("mvp_matrix", projection * matrix);
//! [6]

    // Use texture unit 0 which contains cube.png
    program.setUniformValue("texture", 0);

    // Draw cube geometry
    geometries->drawCubeGeometry(&program);
}
