/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef PIPELINERECVSERV_H
#define PIPELINERECVSERV_H
#include "ParameterServer/pipelinedomsingleton.h"
#define PIPELINE_RECV_DEFAULT_HEAD_SIZE (256)

class PipelineRecvServ {
 public:
  virtual const std::string getDecodeProof() = 0;
  PipelineRecvServ();
  virtual ~PipelineRecvServ();
  virtual bool onRecvPipelineData(char *data) = 0;
  virtual void onDataHeadInfoChange(unsigned char *data);
  virtual bool judgeAndProcessData(std::shared_ptr<std::vector<std::uint8_t>> data);
  virtual size_t getHeadSize() {return PIPELINE_RECV_DEFAULT_HEAD_SIZE;};
  virtual size_t getDim(size_t);
  virtual size_t getWidth();
  virtual size_t getHeight();
  virtual size_t getBPP();
  virtual uint64_t getCurrentTimeStamp(char *infoHead);
  virtual uint64_t getCurrentDataStamp(char *infoHead);
  virtual std::string getPixealFormat();

 protected:
  std::shared_ptr<std::vector<std::uint8_t>> _data;
  std::vector<unsigned char> _head_info;
  bool _data_enable;
  PipelineEngineSingleton *m_PipelineDomSingleton;
};

class PipelineRawRecvServ: public PipelineRecvServ {
 public:
  virtual const std::string getDecodeProof() {
    return "RRS";
  }
  PipelineRawRecvServ();
  virtual ~PipelineRawRecvServ();
  virtual bool onRecvPipelineData(char *data) = 0;
  virtual void onDataHeadInfoChange(unsigned char *);
  virtual std::string getPixealFormat();
};

class PipelineTissueRecvServ: public PipelineRecvServ {
 public:
  virtual const std::string getDecodeProof() {
    return "PTRS";
  }
  PipelineTissueRecvServ();
  virtual ~PipelineTissueRecvServ();
  virtual bool onRecvPipelineData(char *data) = 0;
  virtual void onDataHeadInfoChange(unsigned char *data);
  virtual bool judgeAndProcessData(std::shared_ptr<std::vector<std::uint8_t>> data);
  virtual size_t getDim(size_t index);
  virtual size_t getWidth();
  virtual size_t getHeight();
  virtual size_t getBPP();
  virtual uint64_t getCurrentTimeStamp(char *infoHead);
  virtual uint64_t getCurrentDataStamp(char *infoHead);
  virtual std::string getPixealFormat();
};

class PipelineColorRecvServ: public PipelineRecvServ {
 public:
  virtual const std::string getDecodeProof() {
    return "PCRS";
  }
  PipelineColorRecvServ();
  virtual ~PipelineColorRecvServ();
  virtual bool onRecvPipelineData(char *data) = 0;
  virtual void onDataHeadInfoChange(unsigned char *data);
  virtual bool judgeAndProcessData(std::shared_ptr<std::vector<std::uint8_t>> data);
  virtual size_t getDim(size_t index);
  virtual size_t getWidth();
  virtual size_t getHeight();
  virtual size_t getBPP();
  virtual uint64_t getCurrentTimeStamp(char *infoHead);
  virtual uint64_t getCurrentDataStamp(char *infoHead);
  virtual std::string getPixealFormat();
};

class PipelinePWRecvServ: public PipelineRecvServ {
 public:
  virtual const std::string getDecodeProof() {
    return "PPWRS";
  }
  PipelinePWRecvServ();
  virtual ~PipelinePWRecvServ();
  virtual bool onRecvPipelineData(char *data) = 0;
  virtual void onDataHeadInfoChange(unsigned char *data);
  virtual bool judgeAndProcessData(std::shared_ptr<std::vector<std::uint8_t>> data);
  virtual size_t getDim(size_t index);
  virtual size_t getWidth();
  virtual size_t getHeight();
  virtual size_t getBPP();
  virtual uint64_t getCurrentTimeStamp(char *infoHead);
  virtual uint64_t getCurrentDataStamp(char *infoHead);
  virtual std::string getPixealFormat();
};

#endif // PIPELINERECVSERV_H
