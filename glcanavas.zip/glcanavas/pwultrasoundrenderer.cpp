/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include "pwultrasoundrenderer.h"
#include <QGLFunctions>
#include <QtOpenGL>
#include <QGLShaderProgram>
#include <QGLShader>
#include <QtGui>
#include <QTimer>
#include <fstream>
#include <iostream>
#include <mutex>
#include <sstream>
#include "colorbaseultrasoundrenderer.h"
#include "tissuelineararrayproberenderer.h"
#include "tissueconvexarrayproberenderer.h"
#include "func/utils.h"
#include "ParameterServer/parameterserver.h"
#include "renderutil.h"

#define CLASS_NAME "UltrasoundPWDataRenderer"
#define DEFAULT_RING_DATA_SIZE (256)

PWUltrasoundRenderer::PWUltrasoundRenderer() :
m_backGroundColor(0x00000000) {
}

PWUltrasoundRenderer::~PWUltrasoundRenderer() {
}

void PWUltrasoundRenderer::render() {
  if (!_data_enable) return;
  glClearColor((float)((m_backGroundColor >> 24)&(0x000000ff)) / 255.0,
               (float)((m_backGroundColor >> 16)&(0x000000ff)) / 255.0,
               (float)((m_backGroundColor >> 8) &(0x000000ff)) / 255.0,
               (float)((m_backGroundColor)      &(0x000000ff)) / 255.0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  paintGL();
}
void PWUltrasoundRenderer::initialize() {
  initParams();
  initializeOpenGLFunctions();
  resizeGL(600, 120);
  bool b_success = true;

  if (b_success) {
    qDebug() << __FUNCTION__ << "InitResources success";
  }
}
void PWUltrasoundRenderer::initParams() {
  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = getClassIndex();
  cfg_ctrl.judge_with_create_key(c_name)= {
    {"ring_size", 0},
    {"enable", _data_enable},
    {
      "background", color_format_int_to_string(m_backGroundColor).c_str()
    }
  };
  cfg_ctrl[c_name.c_str()]["ring_size"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    _data.clear();
    auto sz = (size_t)b;
    _data.resize(sz);
    return true;
  });
  m_mtxPaint.lock();
  cfg_ctrl.judge_with_create_key(c_name)["ring_size"] << DEFAULT_RING_DATA_SIZE;
  m_mtxPaint.unlock();
  cfg_ctrl[c_name.c_str()]["enable"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    _data_enable = bool(b);
    return true;
  });
  cfg_ctrl[c_name.c_str()]["background"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    if (!b.is_string()) return false;
    std::string color_string = (std::string)b;
    m_backGroundColor = color_format_string_to_int(color_string);
    return true;
  });

  cfg_ctrl[c_name.c_str()].set_hiden(true);
}

void PWUltrasoundRenderer::UpdateDisplay() {}
bool PWUltrasoundRenderer::onRecvPipelineData(char *data) {
  bool bSuccess = true;
//  m_mtxPaint.lock();
#if 0
  qDebug() << __FUNCTION__ << getWidth();
  qDebug() << __FUNCTION__ << getHeight();
  qDebug() << __FUNCTION__ << getBPP();
  qDebug() << __FUNCTION__ << getPixealFormat().c_str();
  qDebug() << __FUNCTION__ << getCurrentTimeStamp(data - getHeadSize());
#endif
//  char *current_dst = TissueData;
//  char *current_src = data;
//  for(size_t i = 0; i < 256; i++) {
//    memcpy(current_dst, current_src, 506);
//    current_dst += 512;
//    current_src += 506;
//  }

//  m_mtxPaint.unlock();
  QTime current_time =QTime::currentTime();
  static int second = current_time.second();
  static int fps = 0;
  static int fps_a = 0;
  fps_a++;
  if (current_time.second() != second) {
      fps = fps_a;
      fps_a = 0;
  }
  second = current_time.second();
  auto cfg = ParameterServer::instance()->GetCfgRoot();
  cfg.judge_or_create_key("dev_status");
  cfg["dev_status"]["pw_mode_fps"] = fps;

  return bSuccess;
};
void PWUltrasoundRenderer::onDataHeadInfoChange(unsigned char *data) {
  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = getClassIndex();
  m_mtxPaint.lock();
  cfg_ctrl.judge_with_create_key(c_name)["ring_size"] << DEFAULT_RING_DATA_SIZE;
  m_mtxPaint.unlock();
  cfg_ctrl.judge_with_create_key(c_name)["enable"] << true;
};

void PWUltrasoundRenderer::paintGL() {}
void PWUltrasoundRenderer::resizeGL(int nwidth, int nheight) {
  // orthographic view
  m_Proj = glm::ortho(0.0, GLdouble(nwidth), 0.0, GLdouble(nheight), -100.0, +100.0);

//  m_iHeight = nheight;
//  m_iWidth = nwidth;

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(0.0, GLdouble(nwidth), 0.0, GLdouble(nheight), -100.0, +100.0);
}

std::string PWUltrasoundRenderer::getClassIndex() {
  std::ostringstream tp_name;
  tp_name << CLASS_NAME << this;
  return tp_name.str();
}

