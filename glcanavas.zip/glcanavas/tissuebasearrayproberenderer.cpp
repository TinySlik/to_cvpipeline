/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include <QGLFunctions>
#include <QtOpenGL>
#include <QGLShaderProgram>
#include <QGLShader>
#include "tissuebasearrayproberenderer.h"
#include "func/utils.h"

TissueBaseArrayProbeRenderer::TissueBaseArrayProbeRenderer(TissueUltrasoundRenderer * mainRenderer) :
m_ProgramTissue(NULL),
m_ProgramColorVelocity(NULL),
m_ProgramColorEnergy(NULL),
m_MainRenderer(mainRenderer),
m_color(0xffffffff),
m_translate_(0.f, 0.f, 0.f),
m_rotate_(1.f, 0.f, 0.f),
m_skew_x_(0.f),
m_skew_y_(0.f),
m_angle_(0.f),
m_scale_(1.f, 1.f, 1.f),
m_blurRadius(0.f),
m_sampleNum(0.f),
m_bilateralThreshold(10.f),
m_filterAspectRatio(1.f),
m_minFilter(0.f),
m_magFilter(255.f) {
  initializeOpenGLFunctions();
}

TissueBaseArrayProbeRenderer::~TissueBaseArrayProbeRenderer() {
  //todo
}

void TissueBaseArrayProbeRenderer::SetTexture2DWrapMode(GLint sWrap, GLint tWrap) {
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, sWrap);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, tWrap);
}
