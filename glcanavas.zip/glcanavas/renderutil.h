/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef RENDERUTIL_H
#define RENDERUTIL_H
#include <iostream>
#include <string>


int str_to_hex(char *string, unsigned char *cbuf, int len);
void hex_to_str(char *ptr,unsigned char *buf,int len);
std::string color_format_int_to_string(const uint32_t &color);
uint32_t color_format_string_to_int(const std::string &color);

//glm part~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#include "glm\glm.hpp"
glm::vec4 color_format_string_to_glm(const std::string &color);
std::string color_format_glm_to_string(const glm::vec4 &color);

glm::vec4 color_format_int_to_glm(const uint32_t &color);
uint32_t color_format_glm_to_int(const glm::vec4 &color);
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#endif // RENDERUTIL_H
