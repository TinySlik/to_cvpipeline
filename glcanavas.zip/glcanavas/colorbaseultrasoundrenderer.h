/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef BASE_COLORULTRASOUND_RENDERER_H
#define BASE_COLORULTRASOUND_RENDERER_H

#include <QtGui/qvector3d.h>
#include <QtGui/qmatrix4x4.h>
#include <QtGui/qopenglshaderprogram.h>
#include <QtGui/qopenglfunctions.h>
#include <QtGui\QOpenGLFunctions_3_3_Compatibility>
#include <QtOpenGL\QGLWidget>
#include <QtOpenGL\QGLShaderProgram>
#include <mutex>
#include "glm\glm.hpp"
#include "glm\gtc\color_space.hpp"
#include "glm\gtc\type_ptr.hpp"
#include "glm\gtc\matrix_transform.hpp"
#include "pipelinerecvserv.h"
#include "lutmode.h"

#include <QTime>
#include <QVector>


class ColorConvexBaseArrayProbeRenderer;
class ColorLineBaseArrayProbeRenderer;
class BaseArrayProbeRenderer;

class ProberContinerProof {
 public:
  virtual std::string getClassIndex() = 0;
  virtual QOpenGLShaderProgram *getProgramColorCorvedEnergy() = 0;
  virtual QOpenGLShaderProgram *getProgramColorLinedEnergy() = 0;
  virtual GLuint getTextureGLIndex() const = 0;
  virtual GLuint getLUTTextureGLIndex() const = 0;
  virtual size_t getWinWidth() const = 0;
  virtual size_t getWinHeight() const = 0;
  virtual size_t getTexWidth() const = 0;
  virtual size_t getTexHeight() const = 0;
  virtual GLuint CreateBufferObject() = 0;
  virtual GLfloat getTexMinFilter() const = 0;
  virtual GLfloat getTexMaxFilter() const = 0;
  virtual GLboolean getTexModeDpi() const = 0;
  virtual GLboolean getTexModeRevese() const = 0;
};

class ColorUltrasoundRenderer :
    public ProberContinerProof,
    public PipelineColorRecvServ,
    protected QOpenGLFunctions_3_3_Compatibility {
 public:
  ColorUltrasoundRenderer();
  ~ColorUltrasoundRenderer();
  void render();
  void initialize(const std::string &class_index_);
  void initParams();
  QOpenGLShaderProgram *getProgramColorCorvedEnergy() override {return &m_ProgramColorCorvedEnergy;}
  QOpenGLShaderProgram *getProgramColorLinedEnergy() override {return &m_ProgramColorLinedEnergy;}
  GLuint getTextureGLIndex() const override {return m_Texture;}
  GLuint getLUTTextureGLIndex() const override {return m_TextureLUT;}
  size_t getWinWidth() const override {return m_iWidth;}
  size_t getWinHeight() const override {return m_iHeight;}
  size_t getTexWidth() const override {return m_iTexWidth;}
  size_t getTexHeight() const override {return m_iTexHeight;}
  GLfloat getTexMinFilter() const override {return m_minFilter;}
  GLfloat getTexMaxFilter() const override {return m_magFilter;}
  GLboolean getTexModeDpi() const override {return m_mode_dpi;}
  GLboolean getTexModeRevese() const override {return m_mode_reverse;}
  GLuint CreateBufferObject() override;
  std::string getClassIndex() override;
 public slots:
  void UpdateDisplay();
  bool onRecvPipelineData(char *data) override;
  void onDataHeadInfoChange(unsigned char *data) override;

 private:
  virtual void resizeGL(int nwidth, int nheight);
  virtual void paintGL();
  bool InitTextureUI(const int& nWidth, const int& nHeight);
  bool                 _enable_render;

  QOpenGLShaderProgram m_ProgramColorCorvedEnergy;
  QOpenGLShaderProgram m_ProgramColorLinedEnergy;
  bool                 m_bInitialized;
  std::mutex           m_mtxPaint;
  std::vector<unsigned char>  _data;
  GLuint               m_Texture;
  GLfloat              m_minFilter;
  GLfloat              m_magFilter;
  GLboolean            m_mode_dpi;
  GLboolean            m_mode_reverse;

  //LUT
  bool                 _updateLUTtag;
  QOpenGLShaderProgram m_ProgramLUT;
  GLuint               m_TextureLUT;
  GLuint               m_VBO_LUT;
  GLuint               m_VBOTextureLUT;
  GLuint               m_VA_LUT;
  glm::mat4            m_ProjLUT;
  LUT_MODE             m_lut_mode;
  bool                 _hiden_lut;
  void createVBOLUT();
  void initVAOLUT();
  bool initShadersLUT();
  bool fillTextureColorLUT(GLuint texture, const GLubyte* pData, const GLint& nElement);
  void interpolate(GLubyte* pMap,const QList<QColor>& cList);
  bool updateTextureColorLUT(const int& nElement);
  void RenderColorLUT();
  glm::mat4 TransformColorLUT();
  bool initLUT();

  QList<QColor> m_colorListE;
  QList<QColor> m_colorListV;

  size_t               m_iWidth;
  size_t               m_iHeight;
  size_t               m_iTexWidth;
  size_t               m_iTexHeight;
  int                  m_backGroundColor;

  // probe implemations
  std::shared_ptr<ColorConvexBaseArrayProbeRenderer> m_ConvexArrayProbeRenderer;
  std::shared_ptr<ColorLineBaseArrayProbeRenderer> m_LinearArrayProbeRenderer;
  std::shared_ptr<BaseArrayProbeRenderer> m_CurrentArrayProbeRenderer;
  std::string class_index_name_;
};



#endif // BASE_COLORULTRASOUND_RENDERER_H
