/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include <QGLFunctions>
#include <QtOpenGL>
#include <QGLShaderProgram>
#include <QGLShader>
#include <QtGui>
#include <QTimer>
#include <fstream>
#include <iostream>
#include <mutex>
#include <sstream>
#include "tissuebaseultrasoundrenderer.h"
#include "tissuelineararrayproberenderer.h"
#include "tissueconvexarrayproberenderer.h"
#include "func/utils.h"
#include "ParameterServer/parameterserver.h"
#include "renderutil.h"

#ifdef WIN32
#include <windows.h>
#include <process.h>
#else
#include <unistd.h>
#include <sys/time.h>
#include <netinet/in.h>
#endif

uint64_t get_micro_second() {
  uint64_t current_time;
#ifdef WIN32
  current_time = GetTickCount64();
#else
  struct timeval current;
  gettimeofdat(&current, NULL);
  current_time = current.tv_sec * 1000 + current.tv_usec/1000;
#endif
  return current_time;
}

#define CLASS_NAME "UltrasoundTissueDataRenderer"

TissueUltrasoundRenderer::TissueUltrasoundRenderer():
m_ColorBlack(QColor::fromRgb(0, 0, 0)),
m_fMarginTop(10.0f),
m_ProgramLinedTissue(NULL),
m_ProgramCurvedTissue(NULL),
m_ProgramColorCorvedVelocity(NULL),
m_ProgramColorCorvedEnergy(NULL),
m_ProgramColorLinedVelocity(NULL),
m_ProgramColorLinedEnergy(NULL),
m_ProgramLUT(NULL),
m_dWindow(1.0),
m_dLevel(0.0),
m_lut_mode(LUT_GRAY),
_hiden_lut(true),
m_bInitialized(false),
m_backGroundColor(0x00000000),
_updateLUTtag(false),
m_ConvexArrayProbeRenderer(std::make_shared<TissueConvexArrayProbeRenderer>(this)),
m_LinearArrayProbeRenderer(std::make_shared<TissueLinearArrayProbeRenderer>(this)),
m_CurrentArrayProbeRenderer(m_LinearArrayProbeRenderer) {}

TissueUltrasoundRenderer::~TissueUltrasoundRenderer() {}

void TissueUltrasoundRenderer::render() {
  static bool _params_debug = ParameterServer::instance()->is_debug();
  if (!_data_enable) {
    if (_params_debug) RenderLoadingPage();
    return;
  }
  glClearColor((float)((m_backGroundColor >> 24)&(0x000000ff)) / 255.0,
               (float)((m_backGroundColor >> 16)&(0x000000ff)) / 255.0,
               (float)((m_backGroundColor >> 8) &(0x000000ff)) / 255.0,
               (float)((m_backGroundColor)      &(0x000000ff)) / 255.0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  paintGL();
}

std::string TissueUltrasoundRenderer::getClassIndex() {
  std::ostringstream tp_name;
  tp_name << CLASS_NAME << this;
  return tp_name.str();
}

bool TissueUltrasoundRenderer::initLUT() {
  QFile inputFile(g_backendResource_path() + "glshader/ColorLUT2D.vs");
  bool bSuccess = inputFile.open(QIODevice::ReadOnly);

  QTextStream tStream(&inputFile);
  QString vsCode = tStream.readAll();
  inputFile.close();

  QFile inputFile2(g_backendResource_path() + "glshader/ColorLUT2D.fs");
  bSuccess &= inputFile2.open(QIODevice::ReadOnly);

  QTextStream tStream2(&inputFile2);
  QString fsCode = tStream2.readAll();
  inputFile2.close();

  m_ProgramLUT.addCacheableShaderFromSourceCode(QOpenGLShader::Vertex, vsCode);
  m_ProgramLUT.addCacheableShaderFromSourceCode(QOpenGLShader::Fragment, fsCode);
  bSuccess &= m_ProgramLUT.link();

  if (!bSuccess) return false;

  CreateVBOLocal(m_VBOLocal, m_VBOTextureLocal);

  _qgl_in_lut_Position = m_ProgramLUT.attributeLocation("Position");
  m_ProgramLUT.enableAttributeArray(_qgl_in_lut_Position);
  glBindBuffer(GL_ARRAY_BUFFER, m_VBOLocal);
  glVertexAttribPointer(_qgl_in_lut_Position, 3, GL_FLOAT, GL_FALSE, 0, 0);
  m_ProgramLUT.disableAttributeArray(_qgl_in_lut_Position);

  _qgl_in_lut_TexcoordIn = m_ProgramLUT.attributeLocation("TexcoordIn");
  m_ProgramLUT.enableAttributeArray(_qgl_in_lut_TexcoordIn);
  glBindBuffer(GL_ARRAY_BUFFER, m_VBOTextureLocal);
  glVertexAttribPointer(_qgl_in_lut_TexcoordIn, 3, GL_FLOAT, GL_FALSE, 0, 0);
  m_ProgramLUT.disableAttributeArray(_qgl_in_lut_TexcoordIn);

  return bSuccess;
}

void TissueUltrasoundRenderer::initialize() {
  initializeOpenGLFunctions();
  auto bsuccess = InitLoadingPage();
  initParams();
  /* exp read */
  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = getClassIndex();

  bsuccess &= initLUT();

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );

  m_mtxPaint.lock();
  _data.clear();
  _data.resize(m_iTexWidth * m_iTexHeight * 1);
  memset(_data.data(), 0, m_iTexWidth * m_iTexHeight * 1);
  m_mtxPaint.unlock();

  resizeGL(640, 480);

  glEnable(GL_TEXTURE_2D);
  glGenTextures(1, &m_TextureTissue);
  bsuccess &= InitTextureUI(m_iTexHeight, m_iTexWidth);

//  bool b_success = m_ConvexArrayProbeRenderer->Init((GLubyte*)TissueData, (GLubyte*)ColorData);
//  b_success *= m_LinearArrayProbeRenderer->Init((GLubyte*)TissueData, (GLubyte*)ColorData);
  m_LinearArrayProbeRenderer->Init((GLubyte*)TissueData, (GLubyte*)ColorData);
  bsuccess *= updateTextureLUT(256);

  QFile file_tissue_cfg(g_pipeline_cfg_path() + "b_mode/tissue_cfg.json");
  if (file_tissue_cfg.exists()) {
    qDebug() << __FUNCTION__ << "load config success!";
    cfg_ctrl[c_name.c_str()] << configuru::parse_file(g_pipeline_cfg_path().toStdString() + "b_mode/tissue_cfg.json", configuru::JSON);
  }
  QFile file_color_map_cfg(g_pipeline_cfg_path() + "old_funny_map.json");
  if (file_color_map_cfg.exists()) {
    qDebug() << __FUNCTION__ << "load graymap success!";
    cfg_ctrl[c_name.c_str()]["lut"]["local_grapmaplist_index"] = 0;
    cfg_ctrl[c_name.c_str()]["lut"]["local_grapmaplist_index"].add_callback([c_name](configuru::Config &, const configuru::Config &b)->bool{
      auto color_map = configuru::parse_file(g_pipeline_cfg_path().toStdString() + "old_funny_map.json", configuru::JSON);
      auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
      size_t idx = (int)b;
      cfg_ctrl[c_name.c_str()]["lut"]["color_list_gray"] << color_map["old_funny_map_grapmaplist"][idx];
      return true;
    });

    auto color_map = configuru::parse_file(g_pipeline_cfg_path().toStdString() + "old_funny_map.json", configuru::JSON);
    cfg_ctrl[c_name.c_str()]["lut"]["color_list_gray"] << color_map["old_funny_map_grapmaplist"][0];
    cfg_ctrl[c_name.c_str()]["lut"]["color_list_gray"].set_hiden(true);

    if(!cfg_ctrl["dev_sync_tag"].has_key("gray_map_static_index")) {
      cfg_ctrl["dev_sync_tag"]["gray_map_static_index"] = 0;
    }
    cfg_ctrl["dev_sync_tag"]["gray_map_static_index"].add_callback([c_name](configuru::Config &, const configuru::Config &b)->bool{
      auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
      auto index_n = (int)b;
      cfg_ctrl[c_name.c_str()]["lut"]["local_grapmaplist_index"] << index_n;
      return true;
    });

  } else {
    cfg_ctrl[c_name.c_str()]["lut"]["color_list_gray"].set_hiden(false);
  }

  if (bsuccess) {
    qDebug() << __FUNCTION__ << "InitResources success";
  }
}

void TissueUltrasoundRenderer::initParams() {
  m_iTexWidth = 256;
  m_iTexHeight = 512;

  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = getClassIndex();
  cfg_ctrl.judge_with_create_key(c_name.c_str())= {
      {"probe", m_CurrentArrayProbeRenderer == m_ConvexArrayProbeRenderer ? "curved" : "lined"},
      {"enable", _data_enable},
      {"background", color_format_int_to_string(m_backGroundColor).c_str()},
      {"front", color_format_int_to_string(m_CurrentArrayProbeRenderer->getFrontColor()).c_str()},
      {"lut", {
        {"hiden_lut", _hiden_lut},
        {"color_list_gray",  configuru::Config::array({
                                              color_format_int_to_string(0x00000000).c_str(),
                                              color_format_int_to_string(0x80808080).c_str(),
                                              color_format_int_to_string(0xffffffff).c_str(),
                                            })}
      }},
      {"static_img_debug", "null"}
  };

  auto covert_color_to_list_ = [](const configuru::Config &in, QList<QColor> &color_list) -> bool {
    if(!in.is_array()) return false;
    color_list.clear();
    for (size_t i = 0; i< in.array_size();i++) {
      if(in[i].is_string()) {
        std::string color_string = (std::string)in[i];
        auto color = color_format_string_to_glm(color_string);
        color_list << QColor::fromRgb(color.r * 255, color.g * 255, color.b * 255, color.a * 255);
      } else if(in[i].is_array()) {
        if (in[i].array_size() == 3 && in.array_size() == 256) {
          color_list << QColor::fromRgb((int)(in[i][0]), (int)(in[i][1]), (int)(in[i][2]), i);
        } else if (in[i].array_size() == 4) {
          color_list << QColor::fromRgb((int)(in[i][0]), (int)(in[i][1]), (int)(in[i][2]), (int)(in[i][3]));
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
    return true;
  };
  covert_color_to_list_(cfg_ctrl[c_name.c_str()]["lut"]["color_list_gray"], m_colorListGray);
  cfg_ctrl[c_name.c_str()]["lut"]["color_list_gray"].add_callback(
      [this, covert_color_to_list_](configuru::Config &, const configuru::Config &b)->bool{
    bool res = covert_color_to_list_(b, m_colorListGray);
    if (res)
      _updateLUTtag = true;
    return res;
  });

  cfg_ctrl[c_name.c_str()]["lut"]["hiden_lut"].set_hiden(true);
  cfg_ctrl[c_name.c_str()]["lut"]["hiden_lut"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    _hiden_lut = (bool)b;
    return true;
  });

  cfg_ctrl[c_name.c_str()]["enable"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    _data_enable = bool(b);
    return true;
  });
  cfg_ctrl[c_name.c_str()]["background"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    if (!b.is_string()) return false;
    std::string color_string = (std::string)b;
    m_backGroundColor = color_format_string_to_int(color_string);
    return true;
  });
  cfg_ctrl[c_name.c_str()]["front"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    if (!b.is_string()) return false;
    uint32_t color = color_format_string_to_int((std::string)b);
    m_ConvexArrayProbeRenderer->setFrontColor(color);
    m_LinearArrayProbeRenderer->setFrontColor(color);
    return true;
  });

  cfg_ctrl[c_name.c_str()]["probe"].add_callback([this](configuru::Config &, const configuru::Config &b)->bool{
    if (b == "lined") {
      m_CurrentArrayProbeRenderer = m_LinearArrayProbeRenderer;
      return true;
    } else if (b == "curved") {
      m_CurrentArrayProbeRenderer = m_ConvexArrayProbeRenderer;
      return true;
    }
    return false;
  });
  if (!cfg_ctrl.judge_with_create_key("dev_sync_tag").has_key("dev_probe")) {
    cfg_ctrl["dev_sync_tag"]["dev_probe"] = 1;
  }
  cfg_ctrl["dev_sync_tag"]["dev_probe"].add_callback([c_name](configuru::Config &, const configuru::Config &b)->bool{
    auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
    if ((int)b == 1) {
      cfg_ctrl[c_name.c_str()]["probe"] << "lined";
    } else if ((int)b == 2) {
      cfg_ctrl[c_name.c_str()]["probe"] << "curved";
    } else {
      std::cout << "probe type " << b << " has not been defined." << std::endl;
      std::cout.flush();
    }
    return true;
  });

  cfg_ctrl[c_name.c_str()]["static_img_debug"].set_hiden(true);
  cfg_ctrl[c_name.c_str()]["static_img_debug"].add_callback([this, c_name](configuru::Config &, const configuru::Config &b)->bool{
    if (!b.is_string()) return false;
    auto str_path = (std::string)b;

    std::ifstream fRec;
    fRec.open(str_path, std::ofstream::binary | std::ios::in);
    std::cout << "debug_bin_path:" << str_path << std::endl;
    if (!fRec) {
      std::cout << "open failed!" << std::endl;
      _data_enable = false;
      return false;
    }
    std::cout << "open success!"
              << std::endl
              << "read: "
              << 256
              << " * "
              << 512
              << " * "
              << 1
              << " data."
              << std::endl;
    std::cout.flush();
    m_mtxPaint.lock();
    qDebug() <<  "local buf size: "<< _data.size();
    fRec.read((char *)(_data.data()), m_iTexWidth * m_iTexHeight * 1);
#if 1
    uchar * cur = (uchar *)_data.data();
    for(size_t i = 0; i < 256; i++) {
      memset(cur + 506, 0, 6);
      cur += 512;
    }
#endif
    fRec.close();
    m_mtxPaint.unlock();
    _data_enable = true;
    _hiden_lut = false;
    return true;
  });
}

void TissueUltrasoundRenderer::paintGL() {
  RenderRegular();
}

void TissueUltrasoundRenderer::resizeGL(int nwidth, int nheight) {
//  // orthographic view
//  m_Proj = glm::ortho(0.0, GLdouble(nwidth), 0.0, GLdouble(nheight), -100.0, +100.0);
//  m_ProjGraph = glm::ortho(0.0, GLdouble(nwidth), 0.0, GLdouble(nheight), -100.0, +100.0);

//  m_iHeight = nheight;
//  m_iWidth = nwidth;

//  glMatrixMode(GL_PROJECTION);
//  glLoadIdentity();
//  glOrtho(0.0, GLdouble(nwidth), 0.0, GLdouble(nheight), -100.0, +100.0);
  // Calculate aspect ratio
//  qreal aspect = qreal(nwidth) / qreal(nheight ? nheight : 1);

//  // Set near plane to 3.0, far plane to 7.0, field of view 45 degrees
//  const qreal zNear = 3.0, zFar = 7.0, fov = 45.0;

//  // Reset projection
//  projection.setToIdentity();

//  // Set perspective projection
//  projection.perspective(fov, aspect, zNear, zFar);
}

bool TissueUltrasoundRenderer::onRecvPipelineData(char *data) {
  bool bSuccess = true;
  m_mtxPaint.lock();
#if 0
  qDebug() << __FUNCTION__ << getWidth();
  qDebug() << __FUNCTION__ << getHeight();
  qDebug() << __FUNCTION__ << getBPP();
  qDebug() << __FUNCTION__ << getPixealFormat().c_str();
  qDebug() << __FUNCTION__ << getCurrentTimeStamp(data - getHeadSize());
#endif
  char *current_dst = (char *)_data.data();
  char *current_src = data;
  for(size_t i = 0; i < 256; i++) {
    memcpy(current_dst, current_src, 506);
    current_dst += 512;
    current_src += 506;
  }

  m_mtxPaint.unlock();
  QTime current_time =QTime::currentTime();
  static int second = current_time.second();
  static int fps = 0;
  static int fps_a = 0;
  fps_a++;
  if (current_time.second() != second) {
      fps = fps_a;
      fps_a = 0;
      auto cfg = ParameterServer::instance()->GetCfgRoot();
      cfg.judge_with_create_key("dev_status")["b_mode_fps"] = fps;
  }
  second = current_time.second();
  return bSuccess;
}

void TissueUltrasoundRenderer::RenderRegular() {
  if (_updateLUTtag)
      updateTextureLUT(256);
  UpdateDisplay();
  glDisable(GL_DEPTH_TEST);
  if (m_CurrentArrayProbeRenderer)
      m_CurrentArrayProbeRenderer->Render();

  if (!_hiden_lut) {
    RenderLUT();
  }
}

void TissueUltrasoundRenderer::onDataHeadInfoChange(unsigned char *) {
  auto cfg_ctrl = ParameterServer::instance()->GetCfgCtrlRoot();
  auto c_name = getClassIndex();
  cfg_ctrl[c_name.c_str()]["width"] = getWidth();
  cfg_ctrl[c_name.c_str()]["height"] = getHeight();
  cfg_ctrl[c_name.c_str()]["bpp"] = getBPP();
  cfg_ctrl[c_name.c_str()]["format"] = getPixealFormat().c_str();
  cfg_ctrl[c_name.c_str()]["width"].add_callback([](configuru::Config &, const configuru::Config &)->bool{
      return false;
    });
  cfg_ctrl[c_name.c_str()]["height"].add_callback([](configuru::Config &, const configuru::Config &)->bool{
      return false;
    });
  cfg_ctrl[c_name.c_str()]["bpp"].add_callback([](configuru::Config &, const configuru::Config &)->bool{
      return false;
    });
  cfg_ctrl[c_name.c_str()]["format"].add_callback([](configuru::Config &, const configuru::Config &)->bool{
      return false;
    });

  cfg_ctrl[c_name.c_str()]["enable"] << (getWidth() == 256 && getHeight() == 506);
}

//bool TissueUltrasoundRenderer::InitTextureUI(const int& nWidth, const int& nHeight) {
//  bool bSuccess = true;
//  glBindTexture(GL_TEXTURE_2D, m_TextureTissue);
//  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
//  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
////  glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
////  glPushClientAttrib(GL_CLIENT_PIXEL_STORE_BIT);
//  glPixelStorei(GL_UNPACK_ROW_LENGTH, nWidth);
//  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);   // 2 for 16 bit, 1 for 8 bit
////  glPopClientAttrib();
//  glTexImage2D(GL_TEXTURE_2D,
//      0,                        // GLint  	   level
//      GL_R8UI,                  // internal    format
//      nWidth,                   // GLsizei  	width,
//      nHeight,                  // GLsizei  	height,
//      0,                        // GLint  	   border,
//      GL_RED_INTEGER,           // GLenum  	   format,
//      GL_UNSIGNED_BYTE,        // data type
//      (const GLvoid*)0);       // texels
//  if (glGetError() == GL_INVALID_ENUM ||
//      glGetError() == GL_INVALID_VALUE ||
//      glGetError() == GL_INVALID_OPERATION)
//      bSuccess = false;

//  glBindTexture(GL_TEXTURE_2D, 0);
//  return bSuccess;
//}

bool TissueUltrasoundRenderer::InitTextureUI(const int& nWidth, const int& nHeight) {
  bool bSuccess = true;
  glBindTexture(GL_TEXTURE_2D, m_TextureTissue);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
  glTexImage2D(GL_TEXTURE_2D,
      0,                        // GLint  	   level
      GL_R8UI,                  // internal    format
      nWidth,                   // GLsizei  	width,
      nHeight,                  // GLsizei  	height,
      0,                        // GLint  	   border,
      GL_RED_INTEGER,           // GLenum  	   format,
      GL_UNSIGNED_BYTE,        // data type
      (const GLvoid*)_data.data());       // texels
  if (glGetError() == GL_INVALID_ENUM ||
      glGetError() == GL_INVALID_VALUE ||
      glGetError() == GL_INVALID_OPERATION)
      bSuccess = false;

  glBindTexture(GL_TEXTURE_2D, 0);
  return bSuccess;
}

void TissueUltrasoundRenderer::RenderLoadingPage() {
  glClearColor(0, 0, 0, 0);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  if (!m_ProgramLoading.bind())
      return;

  uint64_t time = get_micro_second();
  float time_gl = time/1000.f;
  m_ProgramLoading.setUniformValue("time", time_gl);
  m_ProgramLoading.setUniformValue("resolution", 640.f, 480.f);

  m_ProgramLoading.enableAttributeArray(_qgl_in_LoaingPage_Position);
  m_ProgramLoading.setAttributeArray(_qgl_in_LoaingPage_Position, _qgl_LoaingPage_Position_Vert.constData());
  glDrawArrays(GL_POLYGON, 0, _qgl_LoaingPage_Position_Vert.size());
  m_ProgramLoading.disableAttributeArray(_qgl_in_LoaingPage_Position);

  m_ProgramLoading.release();
}


void TissueUltrasoundRenderer::RenderLUT() {
  if (!m_ProgramLUT.bind())
      return;

  glm::mat4 mv = this->TransformLUT();
  glm::mat4 mvp = m_ProjGraph * mv;
  const GLfloat* pMVP = glm::value_ptr(mvp);

  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_1D, m_TextureLUT);

  m_ProgramLUT.setUniformValue("colorLUT", 0);
  GLuint ProgramName = m_ProgramLUT.programId();
  GLint UniformMVP = glGetUniformLocation(ProgramName, "MVPMatrix");
  glUniformMatrix4fv(UniformMVP, 1, GL_FALSE, pMVP);

  m_ProgramLUT.enableAttributeArray(_qgl_in_lut_Position);
  m_ProgramLUT.enableAttributeArray(_qgl_in_lut_TexcoordIn);
  glDrawArrays(GL_POLYGON, 0, 4);
  m_ProgramLUT.disableAttributeArray(_qgl_in_lut_Position);
  m_ProgramLUT.disableAttributeArray(_qgl_in_lut_TexcoordIn);

  glActiveTexture(GL_TEXTURE0);
  glDisable(GL_TEXTURE_1D);
  glBindTexture(GL_TEXTURE_1D, 0);

  m_ProgramLUT.release();
}

void TissueUltrasoundRenderer::UpdateDisplay() {
//  m_mtxPaint.lock();
//  GLubyte* pFrameData = m_CurrentArrayProbeRenderer->GetFrameData().ImageFrame_Tissue;
//  GLint DSPWidth     = m_CurrentArrayProbeRenderer->GetFrameData().NumDisplayRows_Tissue;
//  GLint DSPHeight    = m_CurrentArrayProbeRenderer->GetFrameData().NumDisplayCols_Tissue;
//  UnpackPBOTexture2D( m_PBOUS, m_TextureTissue, pFrameData, DSPWidth, DSPHeight,0, 0, GL_RED_INTEGER);
//  m_mtxPaint.unlock();

////  glPushClientAttrib(GL_CLIENT_PIXEL_STORE_BIT);
//  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
////  glPopClientAttrib();
  glBindTexture(GL_TEXTURE_2D, m_TextureTissue);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
  m_mtxPaint.lock();
  glTexImage2D(GL_TEXTURE_2D,
      0,
      GL_R8UI,
      m_iTexHeight,
      m_iTexWidth,
      0,
      GL_RED_INTEGER,
      GL_UNSIGNED_BYTE,
      (const GLvoid*)_data.data());
  glBindTexture(GL_TEXTURE_2D, 0);
  m_mtxPaint.unlock();
  return;
}

GLuint TissueUltrasoundRenderer::CreateBufferObject() {
  GLuint uiBufferObject = 0;
  glGenBuffers(1, &uiBufferObject);
  return uiBufferObject;
}
void TissueUltrasoundRenderer::SetTexture2DWrapMode(GLint sWrap, GLint tWrap) {
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, sWrap);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, tWrap);
}

glm::mat4 TissueUltrasoundRenderer::TransformLUT() {
  GLfloat legendWidth = 20.0f;
  GLfloat legendHeight = m_iHeight - 2*10.0f;
  GLfloat offsetX = GLfloat(m_iWidth) - legendWidth - 10.0f;
  GLfloat offsetY = (GLfloat(m_iHeight) - legendHeight) / 2.0f;
  glm::mat4 View = glm::translate(glm::mat4(1.0f),glm::vec3(offsetX, offsetY, 0.0f));

  glm::mat4 Model = glm::scale(glm::mat4(1.0f),glm::vec3(legendWidth, legendHeight, 1.0f));

  glm::mat4 VM = View * Model;
  return VM;
}

glm::mat4 TissueUltrasoundRenderer::TransformColorLUT() {
  GLfloat legendWidth = 20.0f;
  GLfloat legendHeight = m_iHeight - 2 * 10.0f;
  //GLfloat offsetX = GLfloat(m_iWidth) - legendWidth - 50.0f;
  GLfloat offsetX = GLfloat(m_iWidth) - legendWidth - 10.0f;
  GLfloat offsetY = (GLfloat(m_iHeight) - legendHeight) / 2.0f;
  glm::mat4 View = glm::translate(glm::mat4(1.0f), glm::vec3(offsetX, offsetY, 0.0f));

  glm::mat4 Model = glm::scale(glm::mat4(1.0f), glm::vec3(legendWidth, legendHeight, 1.0f));

  glm::mat4 VM = View * Model;
  return VM;
}

glm::mat4 TissueUltrasoundRenderer::TransformColorCurved() {
  GLfloat Radius = m_CurrentArrayProbeRenderer->GetFrameData().Radius;
  GLfloat fHeightC = Radius - m_OffsetC.y;
  glm::mat4 View = glm::translate(glm::mat4(1.0f),glm::vec3(0.0f, GLfloat(m_iHeight) - fHeightC*m_fScale - m_fMarginTop, 0.0f));

  glm::mat4 Model = glm::scale(glm::mat4(1.0f),
  glm::vec3(m_fScale, m_fScale, 1.0f));

  glm::mat4 VM = View * Model;
  return VM;
}

glm::mat4 TissueUltrasoundRenderer::TransformCurvedProbe() {
  glm::mat4 View = glm::translate(glm::mat4(1.0f),glm::vec3(0.0f, m_fTransY, 0.0f));

  glm::mat4 Model = glm::scale(glm::mat4(1.0f),glm::vec3(m_fScale, m_fScale, 1.0f));

  glm::mat4 VM = View * Model;
  return VM;
}

glm::mat4 TissueUltrasoundRenderer::TransformImage() {
  glm::mat4 View = glm::translate(glm::mat4(1.0f),glm::vec3(0.0f, 0.0f, 0.0f));
  glm::mat4 Modelscale = glm::scale(glm::mat4(1.0f),	glm::vec3(1.0f, 1.0f, 1.0f));
  Modelscale = glm::scale(Modelscale,	glm::vec3(1.f, 1.f, 1.0f));
  glm::mat4 Model = glm::translate(Modelscale,glm::vec3(0.0f, 0.0f, 0.0f));
  glm::mat4 VM = View * Model;
  return VM;
}

glm::mat4 TissueUltrasoundRenderer::TransformColor() {
  glm::mat4 View = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, GLfloat(m_iHeight) - m_fMarginTop - m_fTransYImageC, 0.1f));

  glm::mat4 Model = glm::scale(glm::mat4(1.0f), glm::vec3(m_fScale));

  Model = glm::scale(Model,glm::vec3(m_CurrentArrayProbeRenderer->GetFrameData().ImageWidth_Color,m_CurrentArrayProbeRenderer->GetFrameData().ImageHeight_Color,1.0f));

  Model = glm::translate(Model,glm::vec3(-0.5f, 0.0f, 0.0f));

  glm::mat4 VM = View * Model;
  return VM;
}

bool TissueUltrasoundRenderer::UnpackPBOTexture2D(GLuint pbo,
                                    GLuint textureObj,
                                    GLubyte* pTexel,
                                    GLint iWidth, GLint iHeight,
                                    GLint iOffsetX, GLint iOffsetY,
                                    GLenum) {
  if (iWidth*iHeight <= 0)
      return false;
  glBindBuffer(GL_PIXEL_PACK_BUFFER, pbo);
  glBufferSubData(GL_PIXEL_PACK_BUFFER, iOffsetX,iWidth*iHeight * sizeof(GLubyte), pTexel);
  glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);

  glBindBuffer(GL_PIXEL_UNPACK_BUFFER, pbo);
  glBindTexture(GL_TEXTURE_2D, textureObj);
//  glPushClientAttrib(GL_CLIENT_PIXEL_STORE_BIT);
  glPixelStorei(GL_PACK_ALIGNMENT, 1);
  glPixelStorei(GL_UNPACK_ROW_LENGTH, iWidth);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);   // 2 for 16 bit, 1 for 8 bit
//  glPopClientAttrib();
  glTexSubImage2D(GL_TEXTURE_2D,       // target
                      0,                  // GLint  	   level
                      iOffsetX,           // offset x
                      iOffsetY,           // offset y
                      iWidth,             // GLsizei  	width,
                      iHeight,            // GLsizei  	height,
                      GL_RED_INTEGER,    //format,             // GLenum  	   format,
                      GL_UNSIGNED_BYTE,  // data type
                      0);                 // texels
  glBindTexture(GL_TEXTURE_2D, 0);
  glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);

  if (glGetError() == GL_INVALID_ENUM ||
      glGetError() == GL_INVALID_VALUE ||
      glGetError() == GL_INVALID_OPERATION)
    return false;

  return true;
}

bool TissueUltrasoundRenderer::UnpackPBOTexture2D(GLuint pbo,
                                GLuint textureObj,
                                GLubyte* pTexel,
                                GLint iWidth, GLint iHeight) {
  glBindBuffer(GL_PIXEL_PACK_BUFFER, pbo);
  glBufferData(GL_PIXEL_PACK_BUFFER, iWidth*iHeight * sizeof(GLubyte), pTexel,GL_DYNAMIC_COPY);
  glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);

//  glPushAttrib(GL_PIXEL_MODE_BIT);
  glBindBuffer(GL_PIXEL_UNPACK_BUFFER, pbo);
  glBindTexture(GL_TEXTURE_2D, textureObj);
//  glPushClientAttrib(GL_CLIENT_PIXEL_STORE_BIT);
  glPixelStorei(GL_UNPACK_ROW_LENGTH, iWidth);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);   // 2 for 16 bit, 1 for 8 bit
//  glPopClientAttrib();

  glTexSubImage2D(GL_TEXTURE_2D,      // target
      0,                  // GLint  	   level
      0,                  // offset x
      0,                  // offset y
      iWidth,             // GLsizei  	width,
      iHeight,            // GLsizei  	height,
      GL_RED_INTEGER,             // GLenum  	   format,
      GL_UNSIGNED_BYTE,   // data type
      0);            // texels

  glBindTexture(GL_TEXTURE_2D, 0);
  glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
//  glPopAttrib();

  if (glGetError() == GL_INVALID_ENUM ||
      glGetError() == GL_INVALID_VALUE ||
      glGetError() == GL_INVALID_OPERATION)
      return false;
  return true;
}

GLuint TissueUltrasoundRenderer::CreateTextureObject1D() {
  return CreateTextureObject(GL_TEXTURE_1D);
}


GLuint TissueUltrasoundRenderer::CreateTextureObject2D() {
  return CreateTextureObject(GL_TEXTURE_2D);
}

GLuint TissueUltrasoundRenderer::CreateTextureObject3D() {
  return CreateTextureObject(GL_TEXTURE_3D);
}

GLuint TissueUltrasoundRenderer::CreateTextureObject(GLenum pname) {
  glEnable(pname);
  GLuint textureName;
  glGenTextures(1, &textureName);
  return textureName;
}

GLuint TissueUltrasoundRenderer::CreateTextureObject(GLenum pname,GLuint textureName) {
  glEnable(pname);
  GLuint pTexture[] = { textureName };
  glGenTextures(1, pTexture);
  return pTexture[0];
}

bool TissueUltrasoundRenderer::InitTextureLUT(const int& nElement) {
  m_colorListGray << QColor::fromRgb(0, 0, 0, int(0.00f*(nElement - 1)))
                  << QColor::fromRgb(255, 255, 255, int(1.00f*(nElement - 1)));

  GLubyte* pColorMap = new GLubyte[3 * nElement];
  Interpolate(pColorMap, m_colorListGray);
  bool bSuccess = FillTextureColorLUT(m_TextureLUT, pColorMap, nElement);

  delete[] pColorMap;
  return bSuccess;
}

bool TissueUltrasoundRenderer::updateTextureLUT(const int& nElement) {
  bool bSuccess = true;
  auto color_map = std::vector<unsigned char>(3 * nElement);
  switch (m_lut_mode) {
    case LUT_COLOR_E:
    case LUT_COLOR_V:
      break;
    case LUT_GRAY:
      Interpolate(color_map.data(), m_colorListGray);
      bSuccess = FillTextureColorLUT(m_TextureLUT, color_map.data(), nElement);
      break;
    case LUT_OFF:
    case LUT_LAST:
    default:
      break;
  }
  _updateLUTtag = false;
  return bSuccess;
}

bool TissueUltrasoundRenderer::InitTextureColorLUT(const int&) {
  return false;
}

void TissueUltrasoundRenderer::CreateVBOLocal(GLuint &VBO, GLuint &VBOTexture) {
  VBO = CreateBufferObject();
  VBOTexture = CreateBufferObject();
  GLfloat vertices[] = { 0.0f, 1.0f, 0.0f,
      0.0f, 0.0f, 0.0f,
      1.0f, 0.0f, 0.0f,
      1.0f, 1.0f, 0.0f };

  GLfloat tcoords[] = { 0.0f, 1.0f, 0.0f,
      0.0f, 0.0f, 0.0f,
      1.0f, 0.0f, 0.0f,
      1.0f, 1.0f, 0.0f };

  int nsize = sizeof(vertices);
  nsize = sizeof(tcoords);
  glBindBuffer(GL_ARRAY_BUFFER, VBO);
  glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  glBindBuffer(GL_ARRAY_BUFFER, VBOTexture);
  glBufferData(GL_ARRAY_BUFFER, sizeof(tcoords), tcoords, GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, 0);
}

bool TissueUltrasoundRenderer::InitLoadingPage() {
  QFile inputFile(g_backendResource_path() + "glshader/Loading.vs");
  bool bSuccess = inputFile.open(QIODevice::ReadOnly);

  QTextStream tStream(&inputFile);
  QString vsCode = tStream.readAll();
  inputFile.close();

  QFile inputFile2(g_backendResource_path() + "glshader/Loading.fs");
  bSuccess &= inputFile2.open(QIODevice::ReadOnly);

  QTextStream tStream2(&inputFile2);
  QString fsCode = tStream2.readAll();
  inputFile2.close();

  m_ProgramLoading.addCacheableShaderFromSourceCode(QOpenGLShader::Vertex, vsCode);
  m_ProgramLoading.addCacheableShaderFromSourceCode(QOpenGLShader::Fragment, fsCode);
  bSuccess &= m_ProgramLoading.link();

  if (!bSuccess) return false;

  _qgl_in_LoaingPage_Position = m_ProgramLoading.attributeLocation("Position");
  m_ProgramLoading.enableAttributeArray(_qgl_in_LoaingPage_Position);

  _qgl_LoaingPage_Position_Vert.clear();
  _qgl_LoaingPage_Position_Vert << QVector3D(-1.0f, 1.0f, 0.0f);
  _qgl_LoaingPage_Position_Vert << QVector3D(-1.0f, -1.0f, 0.0f);
  _qgl_LoaingPage_Position_Vert << QVector3D(1.0f, -1.0f, 0.0f);
  _qgl_LoaingPage_Position_Vert << QVector3D(1.0f, 1.0f, 0.0f);

  m_ProgramLoading.setAttributeArray(_qgl_in_LoaingPage_Position, _qgl_LoaingPage_Position_Vert.constData());
  m_ProgramLoading.disableAttributeArray(_qgl_in_LoaingPage_Position);

  return bSuccess;
}

bool TissueUltrasoundRenderer::FillTextureColorLUT(GLuint texture, const GLubyte* pData, const GLint& nElement) {
  bool bSuccess = true;

  glEnable(GL_TEXTURE_1D);
  glBindTexture(GL_TEXTURE_1D, texture);
  SetTextureFilter(GL_TEXTURE_1D, GL_LINEAR);
  SetTexture1DWrapMode(GL_CLAMP_TO_EDGE);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1); // 2 for 16 bit, 1 for 8 bit
  glTexImage2D (GL_TEXTURE_1D,
                0,
                GL_RGB8,
                nElement,
                1,
                0,
                GL_RGB,
                GL_UNSIGNED_BYTE,
                pData);

  if (glGetError() == GL_INVALID_ENUM ||
      glGetError() == GL_INVALID_VALUE ||
      glGetError() == GL_INVALID_OPERATION)
      bSuccess = false;

  glDisable(GL_TEXTURE_1D);
  glBindTexture(GL_TEXTURE_1D, 0);
  return bSuccess;
}

void TissueUltrasoundRenderer::Interpolate(GLubyte* pMap,const QList<QColor>& cList) {
  for (int k = 0; k < cList.count() - 1; k++) {
    QColor c1 = cList[k];
    QColor c2 = cList[k + 1];
    int iBegin = c1.alpha();
    int iEnd = c2.alpha();
    float interpolator = 1.0f / GLfloat(iEnd - iBegin);
    glm::ivec3 temp = glm::ivec3(0);
    for (int i = iBegin; i <= iEnd; i++) {
#if 0
      temp[0] = GLint((c2.hue() - c1.hue())*GLfloat(i - iBegin)*interpolator + c1.hue());
      temp[1] = GLint((c2.saturation() - c1.saturation())*GLfloat(i - iBegin)*interpolator + c1.saturation());
      temp[2] = GLint((c2.value() - c1.value())*GLfloat(i - iBegin)*interpolator + c1.value());
      QColor c = QColor::fromHsv(temp[0], temp[1], temp[2]);
#else
      temp[0] = GLint((c2.red() - c1.red())*GLfloat(i - iBegin)*interpolator + c1.red());
      temp[1] = GLint((c2.green() - c1.green())*GLfloat(i - iBegin)*interpolator + c1.green());
      temp[2] = GLint((c2.blue() - c1.blue())*GLfloat(i - iBegin)*interpolator + c1.blue());
      QColor c = QColor::fromRgb(temp[0], temp[1], temp[2]);
#endif
      pMap[i * 3 + 0] = GLubyte(c.red());
      pMap[i * 3 + 1] = GLubyte(c.green());
      pMap[i * 3 + 2] = GLubyte(c.blue());
    }
  }
}

void TissueUltrasoundRenderer::SetTextureFilter(GLenum target, GLint iPara) {
  glTexParameteri(target, GL_TEXTURE_MAG_FILTER, iPara);
  glTexParameteri(target, GL_TEXTURE_MIN_FILTER, iPara);
}

void TissueUltrasoundRenderer::SetTexture1DWrapMode(GLint sWrap) {
  glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, sWrap);
}
