/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef CONVEXARRAYPROBERENDERER_H
#define CONVEXARRAYPROBERENDERER_H

#include "tissuebasearrayproberenderer.h"

class TissueConvexArrayProbeRenderer : public TissueBaseArrayProbeRenderer, std::enable_shared_from_this<TissueConvexArrayProbeRenderer> {
 public:
  TissueConvexArrayProbeRenderer(TissueUltrasoundRenderer * mainRenderer) :
    TissueBaseArrayProbeRenderer(mainRenderer),
    _updateVBOTag(false) {
    m_ProgramTissue = &mainRenderer->m_ProgramCurvedTissue;
    m_ProgramColorVelocity = &mainRenderer->m_ProgramColorCorvedVelocity;
    m_ProgramColorEnergy = &mainRenderer->m_ProgramColorCorvedEnergy;
  }
  virtual bool initShadersTissue() override;
  virtual void RenderImage() override;
  virtual void CreateVBO() override;
  bool initParams() override;
//  virtual void InitVertexArray() override;
  virtual bool InitResources(GLubyte* Tess, GLubyte* color) override;
  virtual bool initRenderer() override;
 private:
  void updateVBO();
  glm::mat4 TransformImage();

  GLfloat m_xOffset;
  GLfloat m_yOffset;
  GLfloat m_Rparer;

  GLfloat m_scale_radius;
  GLfloat m_cAngle;
  GLfloat m_deflection_angle_radius;

  const static GLint nAngles = 1024;
  GLfloat vertices[3 * 2 * (nAngles + 1)];
  GLfloat tcoords[3 * (nAngles + 1) * 3];
  bool _updateVBOTag;
};

#endif // CONVEXARRAYPROBERENDERER_H
