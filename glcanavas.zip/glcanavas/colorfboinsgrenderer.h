/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef COLORFBOINSGRENDERER_H
#define COLORFBOINSGRENDERER_H

#include <QtQuick/QQuickFramebufferObject>

class ColorFboInSGRenderer : public QQuickFramebufferObject {
  Q_OBJECT
 public:
  ColorFboInSGRenderer();
  Renderer *createRenderer() const;
  std::string getClassIndex() const;
 private:
  void initParams();
};

#endif // COLORFBOINSGRENDERER_H
