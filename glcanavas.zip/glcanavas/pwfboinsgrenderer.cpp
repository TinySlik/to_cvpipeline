/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#include "pwfboinsgrenderer.h"
#include <QtGui/QOpenGLFramebufferObject>

#include <QtQuick/QQuickWindow>
#include <qsgsimpletexturenode.h>
#include "pwultrasoundrenderer.h"

class GraphInFboPWRenderer : public QQuickFramebufferObject::Renderer {

 public:
  GraphInFboPWRenderer() {
    tex_content.initialize();
  }

  void render() override {
    tex_content.render();
    update();
  }

  QOpenGLFramebufferObject *createFramebufferObject(const QSize &size) override {
    QOpenGLFramebufferObjectFormat format;
    format.setAttachment(QOpenGLFramebufferObject::CombinedDepthStencil);
    format.setSamples(4);
    return new QOpenGLFramebufferObject(size, format);
  }

  PWUltrasoundRenderer tex_content;
};

QQuickFramebufferObject::Renderer *PWFboInSGRenderer::createRenderer() const {
  return new GraphInFboPWRenderer();
}
