/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef BASEARRAYPROBERENDERER_H
#define BASEARRAYPROBERENDERER_H

#include <QtGui\QOpenGLFunctions_3_3_Compatibility>
#include <QtGui/qopenglshaderprogram.h>
#include "glm\glm.hpp"
#include "glm\gtc\color_space.hpp"
#include "glm\gtc\type_ptr.hpp"
#include "glm\gtc\matrix_transform.hpp"
#include "colorbaseultrasoundrenderer.h"

class BaseArrayProbeRenderer : protected QOpenGLFunctions_3_3_Compatibility, std::enable_shared_from_this<BaseArrayProbeRenderer> {
 public:
  BaseArrayProbeRenderer(ProberContinerProof *mainRender) :
  m_translate_(0.f, 0.f, 0.f),
  m_rotate_(1.f, 0.f, 0.f),
  m_angle_(0.f),
  m_scale_(1.f, 1.f, 1.f),
  m_skew_x_(0.f),
  m_skew_y_(0.f),
  _mainRender(mainRender),
  m_blurRadius(0.f),
  m_sampleNum(0.f),
  m_bilateralThreshold(10.f) {
    initializeOpenGLFunctions();
  };
  virtual ~BaseArrayProbeRenderer(){};

  virtual bool Init() = 0;
  virtual void Render() = 0;
  virtual void initProj() {
    m_Proj = glm::ortho(0.0, GLdouble(m_winWidth), 0.0, GLdouble(m_winHeight), -100.0, +100.0);
  }

 protected:
  GLuint               m_VBO;
  GLuint               m_VBOTexture;
  GLuint               m_VA;

  glm::mat4 m_Proj;

  float               m_winWidth;
  float               m_winHeight;
  glm::vec3 m_translate_;
  glm::vec3 m_rotate_;
  float m_angle_;
  glm::vec3 m_scale_;
  float m_skew_x_;
  float m_skew_y_;
  ProberContinerProof *_mainRender;
  float m_blurRadius;
  float m_sampleNum;

  float m_bilateralThreshold;
};

#endif // BASEARRAYPROBERENDERER_H
