#ifndef PWFBOINSGRENDERER_H
#define PWFBOINSGRENDERER_H

#include <QtQuick/QQuickFramebufferObject>

class PWFboInSGRenderer : public QQuickFramebufferObject {
  Q_OBJECT
 public:
  Renderer *createRenderer() const;
};

#endif // PWFBOINSGRENDERER_H
