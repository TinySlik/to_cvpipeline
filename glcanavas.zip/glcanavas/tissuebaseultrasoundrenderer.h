/****************************************************************************
**
** Copyright (C) 2020 The ZHIZUO Company Ltd.
**
** This file is part of the ZHIZUO Ultrasound SDK.
**
** Private License
** All right include copy change are reserved.
**
****************************************************************************/

#ifndef BASE_TISSUEULTRASOUND_RENDERER_H
#define BASE_TISSUEULTRASOUND_RENDERER_H

#include <QtGui/qvector3d.h>
#include <QtGui/qmatrix4x4.h>
#include <QtGui/qopenglshaderprogram.h>
#include <QtGui/qopenglfunctions.h>
#include <QtGui\QOpenGLFunctions_3_3_Compatibility>
#include <QtOpenGL\QGLWidget>
#include <QtOpenGL\QGLShaderProgram>
#include <mutex>
#include "glm\glm.hpp"
#include "glm\gtc\color_space.hpp"
#include "glm\gtc\type_ptr.hpp"
#include "glm\gtc\matrix_transform.hpp"
#include "pipelinerecvserv.h"
#include "lutmode.h"

#include <QTime>
#include <QVector>
#include <QOpenGLTexture>

class TissueConvexArrayProbeRenderer;
class TissueLinearArrayProbeRenderer;
class TissueBaseArrayProbeRenderer;

typedef struct FrameData_s {
  //Display info
  GLint NumDisplayCols_Tissue;         //real cols in frame data
  GLint NumDisplayRows_Tissue;         //real rows in frame data
  GLint NumDisplayCols_Color;
  GLint NumDisplayRows_Color;
  //Curve probe
  GLfloat Radius;
  int Max_display_cols;       //max cols in frame data
  int Max_display_rows;       //max row in frame data
  //Tissue information
  GLfloat EndDepth_Tissue;    //ABUS-->End depth; Others--> Start depth
  GLfloat ArcAngle_Tissue;    //Field angle
  GLfloat ArcLength_Tissue;
  GLfloat ScanDepth_Tissue;
  GLint ImageWidth_Tissue;   //Image width for display
  GLint ImageHeight_Tissue;  //Image height for display
  //Color information
  GLfloat EndDepth_Color;
  GLfloat ArcAngle_Color;
  GLfloat ImageOffsetX_Color;
  GLfloat ImageOffsetY_Color;
  GLint NumReceiveBeams_Color;
  GLint NumReconRows_Color;
  GLint ImageWidth_Color;
  GLint ImageHeight_Color;
  //Frame data
  GLubyte* ImageFrame_Tissue;
  GLubyte* ImageFrame_ColorV;
  GLubyte* ImageFrame_ColorE;
}FrameData;

class TissueUltrasoundRenderer : public PipelineTissueRecvServ,
    protected QOpenGLFunctions {
 public:
  TissueUltrasoundRenderer();
  ~TissueUltrasoundRenderer();
  void render();
  void initialize();
 public slots:
  void UpdateDisplay();
  bool onRecvPipelineData(char *data) override;
  void onDataHeadInfoChange(unsigned char *data) override;
 public:
  virtual void paintGL();
  virtual void resizeGL(int nwidth, int nheight);

  glm::mat4 TransformColorCurved();
  glm::mat4 TransformCurvedProbe();

  bool InitTextureUI(const int& nWidth, const int& nHeight);

  bool InitTextureLUT(const int& nElement);
  bool InitTextureColorLUT(const int& nElement);
  bool FillTextureColorLUT(GLuint texture, const GLubyte* pData, const GLint& nElement);

  void SetTextureFilter(GLenum target, GLint iPara);
  void SetTexture1DWrapMode(GLint sWrap);

  GLuint CreateBufferObject();
  glm::mat4 TransformLUT();
  glm::mat4 TransformColorLUT();

  glm::mat4 TransformImage();
  glm::mat4 TransformColor();
  bool UnpackPBOTexture2D(GLuint pbo,
                          GLuint textureObj,
                          GLubyte* pTexel,
                          GLint iWidth, GLint iHeight,
                          GLint iOffsetX, GLint iOffsetY,
                          GLenum format);
  bool UnpackPBOTexture2D(GLuint pbo,
      GLuint textureObj,
      GLubyte* pTexel,
      GLint iWidth, GLint iHeight);
  GLuint CreateTextureObject1D();
  GLuint CreateTextureObject2D();
  GLuint CreateTextureObject3D();
  GLuint CreateTextureObject(GLenum pname);
  GLuint CreateTextureObject(GLenum pname, GLuint textureName);

  void RenderRegular();

  void SetTexture2DWrapMode(GLint sWrap, GLint tWrap);
  std::string getClassIndex();
  void initParams();

 public:

  const QColor         m_ColorBlack;
  const GLfloat        m_fMarginTop;
  bool	               m_bVelocityMode;     //Velocity or Energy mode

  //Image display
  QOpenGLShaderProgram m_ProgramLinedTissue;
  QOpenGLShaderProgram m_ProgramCurvedTissue;
  QOpenGLShaderProgram m_ProgramColorCorvedVelocity;
  QOpenGLShaderProgram m_ProgramColorCorvedEnergy;
  QOpenGLShaderProgram m_ProgramColorLinedVelocity;
  QOpenGLShaderProgram m_ProgramColorLinedEnergy;
  QOpenGLShaderProgram m_ProgramLUT;
  QOpenGLShaderProgram m_ProgramLoading;

  //Texture
  GLuint               m_TextureTissue;
  GLuint               m_TextureColorVelocity;
  GLuint               m_TextureColorEnergy;

  //Texture for table
  GLuint               m_TextureLUT;
  GLuint               m_TextureEColorLUT;
  GLuint               m_TextureVColorLUT;

  GLuint               m_VBOLocal;
  GLuint               m_VBOTextureLocal;

  GLuint               m_VA;
  GLuint               m_LoadingPageVAO;

  //Geometry
  glm::mat4            m_Proj;
  glm::mat4            m_ProjGraph;
  glm::vec2            m_Offset;         // left bottom of curved frame

  GLfloat              m_fWidthImageB;
  GLfloat              m_fHeightImageB;
  GLfloat              m_fTransYImageC;

  GLfloat              m_fThresholdMin;
  GLfloat              m_fBThresholdMax;

  //Tissue Display
  GLfloat              m_fInnerRadius;
  GLfloat              m_fOffsetOrient;
  GLfloat              m_fImageHeight;
  GLfloat              m_fImageWidth;
  GLint                m_nGridT;
  GLint                m_nGridR;
  GLfloat              m_ArcAngle;
  GLfloat              m_fMaxCut;

  // Color Display
  GLfloat              m_fInnerRadiusC;
  GLfloat              m_fOffsetOrientC;
  glm::vec2            m_OffsetC;
  GLfloat              m_fImageHeightC;
  GLfloat              m_fImageWidthC;
  GLfloat              m_ArcAngleC;

  GLint                m_iWidth;
  GLint                m_iHeight;

  GLdouble             m_dWindow;
  GLdouble             m_dLevel;
  GLfloat              m_fScale;
  GLfloat              m_fTransY;

  GLuint               m_PBOUS;
  GLuint               m_PBOColor;
  LUT_MODE             m_lut_mode;
  bool                 _hiden_lut;

  bool                 m_bInitialized;
  std::mutex           m_mtxPaint;
  char TissueData[256 * 512];
  char ColorData[724 * 192];

  std::vector<unsigned char>  _data;

  size_t               m_iTexWidth;
  size_t               m_iTexHeight;

//loading page
  int                  _qgl_in_LoaingPage_Position;
  QVector<QVector3D>   _qgl_LoaingPage_Position_Vert;
  void RenderLoadingPage();
  bool InitLoadingPage();

//lut
  bool initLUT();
  void RenderLUT();
  void CreateVBOLocal(GLuint &VBO, GLuint &VBOTexture);
  void Interpolate(GLubyte* pMap, const QList<QColor>& cList);
  bool updateTextureLUT(const int& nElement);
  int                  _qgl_in_lut_Position;
//  QVector<QVector3D>   _qgl_lut_Position_Vert;
  int                  _qgl_in_lut_TexcoordIn;
//  QVector<QVector3D>   _qgl_lut_TexcoordIn_Data;

  QOpenGLTexture *texture;

  QMatrix4x4 projection;

  QVector2D mousePressPosition;
  QVector3D rotationAxis;
  qreal angularSpeed;
  QQuaternion rotation;

 private:
  uint32_t             m_backGroundColor;
  QList<QColor>        m_colorListGray;
  bool                 _updateLUTtag;
  std::shared_ptr<TissueConvexArrayProbeRenderer> m_ConvexArrayProbeRenderer;
  std::shared_ptr<TissueLinearArrayProbeRenderer> m_LinearArrayProbeRenderer;
  std::shared_ptr<TissueBaseArrayProbeRenderer> m_CurrentArrayProbeRenderer;
};



#endif // BASE_TISSUEULTRASOUND_RENDERER_H
